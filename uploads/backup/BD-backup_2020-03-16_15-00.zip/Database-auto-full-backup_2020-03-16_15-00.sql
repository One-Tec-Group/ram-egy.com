#
# TABLE STRUCTURE FOR: installer
#

DROP TABLE IF EXISTS `installer`;

CREATE TABLE `installer` (
  `id` int(1) NOT NULL,
  `installer_flag` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_account_details
#

DROP TABLE IF EXISTS `tbl_account_details`;

CREATE TABLE `tbl_account_details` (
  `account_details_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `fullname` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employment_id` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(100) COLLATE utf8_unicode_ci DEFAULT 'en_US',
  `address` varchar(64) COLLATE utf8_unicode_ci DEFAULT '-',
  `phone` varchar(32) COLLATE utf8_unicode_ci DEFAULT '-',
  `mobile` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `skype` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `language` varchar(40) COLLATE utf8_unicode_ci DEFAULT 'english',
  `designations_id` int(11) DEFAULT '0',
  `avatar` varchar(200) COLLATE utf8_unicode_ci DEFAULT 'uploads/default_avatar.jpg',
  `joining_date` date DEFAULT NULL,
  `present_address` text COLLATE utf8_unicode_ci,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maratial_status` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direction` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`account_details_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('9', 7, 'MR. Amr Attaalla (CEO)', '', '0', NULL, NULL, 'ar_EG', '-', '01068888391', '01226487462', '', 'english', 2, 'uploads/1fc43868-996e-4825-8eec-a8097d6622c5.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('11', 10, 'Muhammad Tharwat Abdul Aziz', '', '0', NULL, NULL, 'ar_EG', '-', '01066006126', '01148183187', '', 'english', 7, 'uploads/default_avatar.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('12', 11, 'Ahmed Almaz ( Managing Director )', '', '0', NULL, NULL, 'ar_EG', '-', '01068888393', '01060363606', '', 'english', 2, 'uploads/IMG-20200122-WA0000.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('75', 74, 'uAiMhYKoFwtmc', NULL, '81', NULL, NULL, 'en_US', '-', '-', '', '', 'english', 0, 'uploads/default_avatar.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('76', 75, 'hvArISVnDCR', NULL, '82', NULL, NULL, 'en_US', '-', '-', '', '', 'english', 0, 'uploads/default_avatar.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('77', 76, 'akuPSmqwhZQ', NULL, '83', NULL, NULL, 'en_US', '-', '-', '', '', 'english', 0, 'uploads/default_avatar.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('78', 77, 'VHoNJXqwcf', NULL, '84', NULL, NULL, 'en_US', '-', '-', '', '', 'english', 0, 'uploads/default_avatar.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('79', 78, 'DwOkFqZGu', NULL, '85', NULL, NULL, 'en_US', '-', '-', '', '', 'english', 0, 'uploads/default_avatar.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('80', 79, 'RhecnOMkImd', NULL, '86', NULL, NULL, 'en_US', '-', '-', '', '', 'english', 0, 'uploads/default_avatar.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('81', 80, 'qXMNFoEbBnRDUg', NULL, '87', NULL, NULL, 'en_US', '-', '-', '', '', 'english', 0, 'uploads/default_avatar.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('82', 81, 'RarjcuJpws', NULL, '88', NULL, NULL, 'en_US', '-', '-', '', '', 'english', 0, 'uploads/default_avatar.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');


#
# TABLE STRUCTURE FOR: tbl_accounts
#

DROP TABLE IF EXISTS `tbl_accounts`;

CREATE TABLE `tbl_accounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `balance` decimal(18,2) NOT NULL DEFAULT '0.00',
  `permission` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`account_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_activities
#

DROP TABLE IF EXISTS `tbl_activities`;

CREATE TABLE `tbl_activities` (
  `activities_id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_field_id` int(11) DEFAULT NULL,
  `activity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activity_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `icon` varchar(32) COLLATE utf8_unicode_ci DEFAULT 'fa-coffee',
  `link` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value1` text COLLATE utf8_unicode_ci,
  `value2` text COLLATE utf8_unicode_ci,
  `deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`activities_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=614 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (390, 7, 'departments', NULL, 'activity_added_a_department', '2020-01-12 18:43:31', 'fa-coffee', NULL, 'Human Resources', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (391, 7, 'departments', NULL, 'activity_added_a_department', '2020-01-12 18:43:36', 'fa-coffee', NULL, 'Human Resources', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (395, 7, 'departments', 4, 'activity_delete_a_designation', '2020-01-12 18:53:10', 'fa-coffee', NULL, 'Human Resources', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (396, 7, 'departments', NULL, 'activity_added_a_department', '2020-01-12 18:55:36', 'fa-coffee', NULL, 'Sales', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (397, 7, 'departments', NULL, 'activity_added_a_department', '2020-01-12 18:57:33', 'fa-coffee', NULL, 'Finance', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (402, 7, 'invoice', 1, 'activity_invoicedelete_invoice', '2020-01-13 10:34:58', 'fa-shopping-cart', NULL, 'INV-2020-Jan-12-0001', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (403, 7, 'client', 15, 'activity_update_company', '2020-01-13 10:40:26', 'fa-user', NULL, 'WADI DEGLA CLUBS', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (404, 7, 'proposals', 1, 'activity_proposals_created', '2020-01-13 10:49:38', 'fa-shopping-cart', 'admin/proposals/index/proposals_details/1', '[INV]-2020-Jan-13-0001', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (405, 7, 'client', 7, 'activity_deleted_client', '2020-01-13 14:07:18', 'fa-user', NULL, 'نادي البيطاش', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (406, 7, 'client', 7, 'activity_deleted_client', '2020-01-13 14:07:32', 'fa-user', NULL, 'OTG', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (407, 7, 'client', 15, 'activity_added_new_company', '2020-01-13 14:15:21', 'fa-user', NULL, 'WADI DEGLA CLUBS', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (408, 7, 'proposals', 1, 'activity_proposals_updated', '2020-01-13 14:29:05', 'fa-shopping-cart', 'admin/proposals/index/proposals_details/1', '[INV]-2020-Jan-13-0001', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (414, 7, 'settings', 1, 'customer_group_added', '2020-01-16 14:16:00', 'fa-coffee', NULL, 'IMPORTED', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (415, 7, 'settings', 2, 'customer_group_added', '2020-01-16 14:16:21', 'fa-coffee', NULL, 'LOCAL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (419, 7, 'settings', 7, 'activity_update_profile', '2020-01-16 14:35:39', 'fa-coffee', NULL, 'MR. Amr Attaalla (CEO)', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (420, 7, 'user', 11, 'activity_added_new_user', '2020-01-16 14:45:51', 'fa-user', NULL, 'ahmed-almaz', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (421, 7, 'settings', 7, 'activity_save_general_settings', '2020-01-16 14:55:16', 'fa-coffee', NULL, ' Ram For Sport Service\'s', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (422, 7, 'settings', 7, 'activity_save_general_settings', '2020-01-16 14:56:56', 'fa-coffee', NULL, ' Ram For Sport Services', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (423, 11, 'settings', 11, 'activity_update_profile', '2020-01-22 03:03:42', 'fa-coffee', NULL, 'Ahmed Almaz', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (424, 11, 'settings', 1, 'activity_added_a_lead_source', '2020-01-22 03:09:10', 'fa-coffee', NULL, 'Facebook ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (425, 11, 'settings', 1, 'activity_added_a_lead_status', '2020-01-22 03:19:54', 'fa-coffee', NULL, 'hesitant', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (426, 11, 'leads', 1, 'activity_save_leads', '2020-01-22 03:20:03', 'fa-rocket', 'admin/leads/leads_details/1', 'Project Owner', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (427, 11, 'settings', 3, 'customer_group_added', '2020-01-22 03:29:19', 'fa-coffee', NULL, 'Ram equipment ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (428, 11, 'items', 1, 'activity_save_items', '2020-01-22 03:31:17', 'fa-circle-o', NULL, 'سلم قفز', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (429, 11, 'settings', 11, 'activity_update_profile', '2020-01-22 03:39:34', 'fa-coffee', NULL, 'Ahmed Almaz ( Managing Director )', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (430, 11, 'settings', 11, 'activity_update_profile', '2020-01-22 03:39:35', 'fa-coffee', NULL, 'Ahmed Almaz ( Managing Director )', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (431, 7, 'leads', 53, 'activity_convert_to_client', '2020-02-10 13:51:37', 'fa-rocket', 'admin/leads/leads_details/1', 'Project Owner', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (432, 11, 'leads', 2, 'activity_save_leads', '2020-02-11 10:40:32', 'fa-rocket', 'admin/leads/leads_details/2', 'mr', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (433, 11, 'settings', 2, 'activity_added_a_lead_status', '2020-02-11 10:47:02', 'fa-coffee', NULL, 'Phone Call2', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (434, 11, 'settings', 2, 'activity_added_a_lead_status', '2020-02-11 10:47:19', 'fa-coffee', NULL, 'Phone Call', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (435, 11, 'settings', 3, 'activity_added_a_lead_status', '2020-02-11 10:47:55', 'fa-coffee', NULL, 'Call Later', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (436, 11, 'leads', 2, 'activity_new_leads_comment', '2020-02-11 10:55:18', 'fa-rocket', 'admin/leads/leads_details/2/4', 'الله يسامحك يا سامح حسبني الله و نعم الوكيل', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (437, 11, 'proposals', 2, 'activity_proposals_created', '2020-02-11 11:05:37', 'fa-shopping-cart', 'admin/proposals/index/proposals_details/2', '[INV]-2020-Feb-11-0002', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (438, 11, 'proposals', 1, 'convert_to_invoice_from_proposal', '2020-02-11 11:14:32', 'fa-shopping-cart', 'admin/proposals/index/proposals_details/2', 'INV-2020-Feb-11-0001', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (439, 11, 'settings', 1, 'activity_added_a_payment_method', '2020-02-11 11:17:04', 'fa-coffee', NULL, 'Cash', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (440, 11, 'invoice', 1, 'activity_new_payment', '2020-02-11 11:22:12', 'fa-shopping-cart', 'admin/invoice/manage_invoice/invoice_details/1', '$ 3.000,00', 'INV-2020-Feb-11-0001', 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (441, 11, 'invoice', 1, 'activity_new_payment', '2020-02-11 11:23:52', 'fa-shopping-cart', 'admin/invoice/manage_invoice/invoice_details/1', '$ 1.000,00', 'INV-2020-Feb-11-0001', 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (442, 11, 'settings', 2, 'customer_group_added', '2020-02-14 16:02:10', 'fa-coffee', NULL, 'floor mats', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (443, 11, 'items', 2, 'activity_save_items', '2020-02-14 16:05:25', 'fa-circle-o', NULL, 'ارضيات فوم 18 ملي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (444, 11, 'items', 3, 'activity_save_items', '2020-02-14 16:06:37', 'fa-circle-o', NULL, 'ارضيات فوم 20 ملي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (445, 11, 'items', 2, 'activity_update_items', '2020-02-14 16:07:30', 'fa-circle-o', NULL, 'ارضيات فوم 18 ملي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (446, 11, 'items', 3, 'activity_update_items', '2020-02-14 16:07:59', 'fa-circle-o', NULL, 'ارضيات فوم 20 ملي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (447, 11, 'items', 4, 'activity_save_items', '2020-02-14 16:09:24', 'fa-circle-o', NULL, 'ارضيات فوم 25 ملي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (448, 11, 'items', 5, 'activity_save_items', '2020-02-14 16:10:27', 'fa-circle-o', NULL, 'ارضيات فوم 30 ملي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (449, 11, 'items', 6, 'activity_save_items', '2020-02-14 16:11:52', 'fa-circle-o', NULL, 'ارضيات لباد', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (450, 11, 'items', 7, 'activity_save_items', '2020-02-14 16:18:47', 'fa-circle-o', NULL, 'بيم قانوني', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (492, 7, 'settings', 7, 'activity_save_general_settings', '2020-02-25 19:50:52', 'fa-coffee', NULL, ' Ram For Sports Services', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (493, 7, 'settings', 7, 'activity_save_general_settings', '2020-02-25 19:52:06', 'fa-coffee', NULL, ' Ram For Sports Services', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (494, 7, 'items', 7, 'activity_update_items', '2020-02-25 19:58:04', 'fa-circle-o', NULL, 'بيم قانوني', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (495, 7, 'leads', 3, 'activity_save_leads', '2020-02-25 20:34:19', 'fa-rocket', 'admin/leads/leads_details/3', 'mohaad', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (496, 7, 'leads', 77, 'activity_convert_to_client', '2020-02-25 20:35:03', 'fa-rocket', 'admin/leads/leads_details/3', 'mohaad', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (497, 7, 'client', 7, 'activity_deleted_client', '2020-02-25 20:36:57', 'fa-user', NULL, 'JROMVeXoEIpUr', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (498, 7, 'leads', 2, 'activity_leads_deleted', '2020-02-27 08:28:07', 'fa-rocket', NULL, 'mr', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (499, 7, 'leads', 2, 'activity_leads_deleted', '2020-02-27 08:28:43', 'fa-rocket', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (500, 7, 'proposals', 1, 'activity_delete_proposals', '2020-02-27 08:29:10', 'fa-shopping-cart', 'admin/proposals/index/proposals_details/1', 'delete_proposals', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (501, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:29:51', 'fa-user', NULL, 'LfMaeSvJ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (502, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:30:01', 'fa-user', NULL, 'jaynwCbXFEcdDGH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (503, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:30:09', 'fa-user', NULL, 'FzLZYIUbknD', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (504, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:30:17', 'fa-user', NULL, 'mohaad', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (505, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:30:26', 'fa-user', NULL, 'ogcRKCePw', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (506, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:30:34', 'fa-user', NULL, 'TYAFxPro', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (507, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:30:42', 'fa-user', NULL, 'qpCesTBLSmrQDiwO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (508, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:30:50', 'fa-user', NULL, 'KPBpEJgFMrCamOGw', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (509, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:30:58', 'fa-user', NULL, 'sTmxqNDJGX', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (510, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:31:05', 'fa-user', NULL, 'IMBtjRZqYfpV', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (511, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:31:19', 'fa-user', NULL, 'TpmhfcrMOLdRkD', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (512, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:31:19', 'fa-user', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (513, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:31:31', 'fa-user', NULL, 'WmDgsPxVjUyZML', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (514, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:31:38', 'fa-user', NULL, 'zRDQGWcjNiHOeP', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (515, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:31:46', 'fa-user', NULL, 'AQEhdsOBifaPDZtc', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (516, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:31:52', 'fa-user', NULL, 'CdMDysIAoiKJwgE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (517, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:31:59', 'fa-user', NULL, 'mjITMBvfAiZP', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (518, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:31:59', 'fa-user', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (519, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:32:07', 'fa-user', NULL, 'YscXrxnw', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (520, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:32:15', 'fa-user', NULL, 'lsxKZBGYMSf', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (521, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:32:21', 'fa-user', NULL, 'ioYjIwquCySKgB', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (522, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:32:28', 'fa-user', NULL, 'JomlsBuevR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (523, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:32:38', 'fa-user', NULL, 'QLadetBHwJXuv', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (524, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:32:48', 'fa-user', NULL, 'RubniJhHvrlXyG', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (525, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:32:48', 'fa-user', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (526, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:33:40', 'fa-user', NULL, 'xAwjhKVYoZ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (527, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:33:48', 'fa-user', NULL, 'IEARuqDZ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (528, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:33:56', 'fa-user', NULL, 'cRTDNBOUkusYg', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (529, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:34:03', 'fa-user', NULL, 'ali', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (530, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:34:10', 'fa-user', NULL, 'eWQIqayXnupHzVU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (531, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:34:18', 'fa-user', NULL, 'Project Owner', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (532, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:34:26', 'fa-user', NULL, 'aWqbGrxjYntg', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (533, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:34:34', 'fa-user', NULL, 'WRXhEKAqTSDmYLMi', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (534, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:34:41', 'fa-user', NULL, 'bzJAHcyRWvP', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (535, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:34:49', 'fa-user', NULL, 'fODyYRkXWFbdqjI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (536, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:02', 'fa-user', NULL, 'nimgjYAcVoOSWLZ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (537, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:12', 'fa-user', NULL, 'mnJeqQayPxdTwOt', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (538, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:19', 'fa-user', NULL, 'qKAmQRedo', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (539, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:19', 'fa-user', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (540, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:25', 'fa-user', NULL, 'NypctobVYuzqhAHa', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (541, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:32', 'fa-user', NULL, 'ztWgqMeLaCbQm', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (542, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:33', 'fa-user', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (543, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:40', 'fa-user', NULL, 'ZpLlhcBDqoXea', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (544, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:40', 'fa-user', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (545, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:48', 'fa-user', NULL, 'UQRyoZTMt', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (546, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:48', 'fa-user', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (547, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:56', 'fa-user', NULL, 'oUDuNRQmrs', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (548, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:35:57', 'fa-user', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (549, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:36:04', 'fa-user', NULL, 'AOnyUJrKawx', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (550, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:36:11', 'fa-user', NULL, 'ivqKTjVtNXcw', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (551, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:36:19', 'fa-user', NULL, 'fQlCVzNcr', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (552, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:36:26', 'fa-user', NULL, 'onvijbkuXhFErLyc', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (553, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:36:33', 'fa-user', NULL, 'PSTeLRNyAgGapKd', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (554, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:36:39', 'fa-user', NULL, 'bawLXGuzQenkVNlt', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (555, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:36:51', 'fa-user', NULL, 'uvULNASQDOE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (556, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:36:58', 'fa-user', NULL, 'YSizvnUyB', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (557, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:37:04', 'fa-user', NULL, 'InWBKxrJywehqC', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (558, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:37:12', 'fa-user', NULL, 'NaJSxnIimlpOfTDY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (559, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:37:12', 'fa-user', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (560, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:37:20', 'fa-user', NULL, 'fgmhkzLxIvEAy', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (561, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:37:27', 'fa-user', NULL, 'MLyaNkenlrYF', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (562, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:37:27', 'fa-user', NULL, NULL, NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (563, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:37:34', 'fa-user', NULL, 'EGWzPaALqtgNon', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (564, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:37:40', 'fa-user', NULL, 'BjRCfpbJiEPYevQq', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (565, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:37:46', 'fa-user', NULL, 'VFoPGdwQaC', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (566, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:37:54', 'fa-user', NULL, 'QqtkmBpJdovGSDT', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (567, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:38:02', 'fa-user', NULL, 'qiszbuWhDUKoAr', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (568, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:38:08', 'fa-user', NULL, 'ZpPmhBDvFsjae', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (569, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:38:14', 'fa-user', NULL, 'ilaMRVOUkTSpDyzH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (570, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:38:23', 'fa-user', NULL, 'PpUGvriajQARtsoK', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (571, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:38:29', 'fa-user', NULL, 'tQTErbsF', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (572, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:38:35', 'fa-user', NULL, 'NmwXMqGxtrCfB', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (573, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:38:43', 'fa-user', NULL, 'SfFXPRaOmUx', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (574, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:38:51', 'fa-user', NULL, 'ram', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (575, 7, 'client', 7, 'activity_deleted_client', '2020-02-27 08:39:00', 'fa-user', NULL, 'WADI DEGLA CLUBS', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (576, 7, 'account', 1, 'activity_delete_account', '2020-02-27 08:43:10', 'fa-circle-o', NULL, 'Salaries', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (577, 7, 'leads', 4, 'activity_save_leads', '2020-02-27 16:14:03', 'fa-rocket', 'admin/leads/leads_details/4', 'DINA WAGEEH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (578, 7, 'items', 8, 'activity_save_items', '2020-03-03 11:38:04', 'fa-circle-o', NULL, 'بيم تدريب', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (579, 7, 'items', 9, 'activity_save_items', '2020-03-04 11:16:04', 'fa-circle-o', NULL, 'بيم ارضي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (580, 7, 'items', 9, 'activity_update_items', '2020-03-04 11:17:57', 'fa-circle-o', NULL, 'بيم ارضي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (581, 7, 'items', 10, 'activity_save_items', '2020-03-04 11:24:46', 'fa-circle-o', NULL, 'مشايه ارضي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (582, 7, 'items', 11, 'activity_save_items', '2020-03-04 11:41:35', 'fa-circle-o', NULL, 'بيم ارضي 2', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (583, 7, 'items', 12, 'activity_save_items', '2020-03-04 11:43:40', 'fa-circle-o', NULL, 'عش غراب عادي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (584, 7, 'items', 13, 'activity_save_items', '2020-03-04 11:44:50', 'fa-circle-o', NULL, 'عش غراب بحلقتين', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (585, 7, 'items', 14, 'activity_save_items', '2020-03-04 11:46:09', 'fa-circle-o', NULL, 'حلق قانوني', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (586, 7, 'items', 15, 'activity_save_items', '2020-03-04 11:47:03', 'fa-circle-o', NULL, 'حلق ناشئين', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (587, 7, 'items', 16, 'activity_save_items', '2020-03-04 11:47:48', 'fa-circle-o', NULL, 'متوازي ناشئين', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (588, 7, 'items', 17, 'activity_save_items', '2020-03-04 11:48:21', 'fa-circle-o', NULL, 'متوازي ناشئات', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (589, 7, 'items', 18, 'activity_save_items', '2020-03-04 11:48:52', 'fa-circle-o', NULL, 'عقله ناشئين', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (590, 7, 'items', 19, 'activity_save_items', '2020-03-04 11:49:54', 'fa-circle-o', NULL, 'حصان قفزقانوني1', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (591, 7, 'items', 20, 'activity_save_items', '2020-03-04 11:50:28', 'fa-circle-o', NULL, 'حصان قفز فوم', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (592, 7, 'items', 21, 'activity_save_items', '2020-03-04 11:57:16', 'fa-circle-o', NULL, 'ميني ترامبولين', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (593, 7, 'items', 22, 'activity_save_items', '2020-03-04 12:06:02', 'fa-circle-o', NULL, 'ميني ترامبولين2', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (594, 7, 'items', 23, 'activity_save_items', '2020-03-04 12:20:11', 'fa-circle-o', NULL, 'متوازي رجال قانوني', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (595, 7, 'items', 24, 'activity_save_items', '2020-03-04 13:37:55', 'fa-circle-o', NULL, ' 1عقله متحركه', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (596, 7, 'items', 25, 'activity_save_items', '2020-03-04 13:39:22', 'fa-circle-o', NULL, 'عقله متحركه 2', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (597, 7, 'items', 26, 'activity_save_items', '2020-03-04 13:41:00', 'fa-circle-o', NULL, 'عقله متحركه 3', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (598, 7, 'items', 27, 'activity_save_items', '2020-03-04 13:43:02', 'fa-circle-o', NULL, ' 1متوازي بنات قانوني', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (599, 7, 'items', 27, 'activity_update_items', '2020-03-04 13:44:03', 'fa-circle-o', NULL, ' 1متوازي بنات قانوني', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (600, 7, 'items', 28, 'activity_save_items', '2020-03-04 13:47:01', 'fa-circle-o', NULL, 'متوازي بنات قانوني 2', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (601, 7, 'items', 29, 'activity_save_items', '2020-03-04 13:49:44', 'fa-circle-o', NULL, 'مشليه ارضي 2', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (602, 7, 'items', 30, 'activity_save_items', '2020-03-04 13:51:26', 'fa-circle-o', NULL, 'مشايه ارضي 3', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (603, 7, 'items', 31, 'activity_save_items', '2020-03-04 13:53:42', 'fa-circle-o', NULL, 'عقله حائط مفرد', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (604, 7, 'items', 32, 'activity_save_items', '2020-03-04 13:55:05', 'fa-circle-o', NULL, 'مقعد سويدي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (605, 7, 'items', 33, 'activity_save_items', '2020-03-04 13:55:51', 'fa-circle-o', NULL, 'جهاز ترددي', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (606, 7, 'items', 34, 'activity_save_items', '2020-03-04 13:57:53', 'fa-circle-o', NULL, 'عوامه حلق', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (607, 7, 'items', 35, 'activity_save_items', '2020-03-04 14:44:17', 'fa-circle-o', NULL, 'صندوق مقسم', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (608, 7, 'leads', 5, 'activity_save_leads', '2020-03-08 16:23:15', 'fa-rocket', 'admin/leads/leads_details/5', 'ALAM EL RYADA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (609, 7, 'leads', 4, 'activity_update_leads', '2020-03-08 16:24:21', 'fa-rocket', 'admin/leads/leads_details/4', 'DINA WAGEEH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (610, 7, 'leads', 6, 'activity_save_leads', '2020-03-08 16:26:22', 'fa-rocket', 'admin/leads/leads_details/6', 'IMAN SOBHY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (611, 7, 'leads', 7, 'activity_save_leads', '2020-03-08 16:28:03', 'fa-rocket', 'admin/leads/leads_details/7', 'MOHAMED KESHK', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (612, 7, 'leads', 8, 'activity_save_leads', '2020-03-08 16:30:03', 'fa-rocket', 'admin/leads/leads_details/8', 'MOHAMED ABD ALLAH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (613, 7, 'leads', 9, 'activity_save_leads', '2020-03-08 16:32:40', 'fa-rocket', 'admin/leads/leads_details/9', 'SHOOTING CLUB KHATAMYA', NULL, 0);


#
# TABLE STRUCTURE FOR: tbl_advance_salary
#

DROP TABLE IF EXISTS `tbl_advance_salary`;

CREATE TABLE `tbl_advance_salary` (
  `advance_salary_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `advance_amount` varchar(200) NOT NULL,
  `deduct_month` varchar(30) DEFAULT NULL,
  `reason` text,
  `request_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0 =pending,1=accpect , 2 = reject and 3 = paid',
  `approve_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`advance_salary_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_allowed_ip
#

DROP TABLE IF EXISTS `tbl_allowed_ip`;

CREATE TABLE `tbl_allowed_ip` (
  `allowed_ip_id` int(11) NOT NULL AUTO_INCREMENT,
  `allowed_ip` varchar(100) NOT NULL,
  `status` enum('active','reject','pending') DEFAULT 'pending',
  PRIMARY KEY (`allowed_ip_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_announcements
#

DROP TABLE IF EXISTS `tbl_announcements`;

CREATE TABLE `tbl_announcements` (
  `announcements_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('published','unpublished') NOT NULL DEFAULT 'unpublished' COMMENT '0 = unpublished, 1 = published',
  `view_status` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1=Read 2=Unread',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `all_client` varchar(20) DEFAULT NULL,
  `attachment` text,
  PRIMARY KEY (`announcements_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_assign_item
#

DROP TABLE IF EXISTS `tbl_assign_item`;

CREATE TABLE `tbl_assign_item` (
  `assign_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `assign_inventory` int(5) NOT NULL,
  `assign_date` date NOT NULL,
  PRIMARY KEY (`assign_item_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_attendance
#

DROP TABLE IF EXISTS `tbl_attendance`;

CREATE TABLE `tbl_attendance` (
  `attendance_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `leave_application_id` int(11) DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `attendance_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'status 0=absent 1=present 3 = onleave',
  `clocking_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`attendance_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (1, 7, 0, '2020-01-13', '2020-01-13', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (2, 1, 0, '2020-01-16', '2020-01-16', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (3, 7, 0, '2020-01-16', '2020-02-25', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (4, 11, 0, '2020-01-22', NULL, 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (5, 7, 0, '2020-01-28', '2020-01-28', 0, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (6, 8, 0, '2020-01-28', '2020-01-28', 0, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (7, 10, 0, '2020-01-28', '2020-01-28', 0, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (8, 11, 0, '2020-01-28', '2020-01-28', 0, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (9, 7, 0, '2020-01-29', '2020-01-29', 0, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (10, 8, 0, '2020-01-29', '2020-01-29', 0, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (11, 10, 0, '2020-01-29', '2020-01-29', 0, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (12, 11, 0, '2020-01-29', '2020-01-29', 0, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (13, 7, 0, '2020-03-16', '2020-03-16', 0, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (14, 10, 0, '2020-03-16', '2020-03-16', 0, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (15, 11, 0, '2020-03-16', '2020-03-16', 0, 0);


#
# TABLE STRUCTURE FOR: tbl_bug
#

DROP TABLE IF EXISTS `tbl_bug`;

CREATE TABLE `tbl_bug` (
  `bug_id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_no` varchar(50) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `opportunities_id` int(11) DEFAULT NULL,
  `task_id` int(11) NOT NULL DEFAULT '0',
  `bug_title` varchar(200) NOT NULL,
  `bug_description` text NOT NULL,
  `bug_status` varchar(30) DEFAULT NULL,
  `notes` text NOT NULL,
  `priority` varchar(20) NOT NULL,
  `severity` varchar(20) DEFAULT NULL,
  `reproducibility` text,
  `reporter` int(11) DEFAULT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `permission` text,
  `client_visible` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`bug_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_calls
#

DROP TABLE IF EXISTS `tbl_calls`;

CREATE TABLE `tbl_calls` (
  `calls_id` int(11) NOT NULL AUTO_INCREMENT,
  `leads_id` int(11) DEFAULT NULL,
  `opportunities_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` varchar(20) CHARACTER SET latin1 NOT NULL,
  `call_summary` varchar(200) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`calls_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_checklists
#

DROP TABLE IF EXISTS `tbl_checklists`;

CREATE TABLE `tbl_checklists` (
  `checklist_id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(32) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `description` text,
  `finished` int(11) DEFAULT '0',
  `create_datetime` datetime DEFAULT NULL,
  `added_from` int(11) DEFAULT NULL,
  `finished_from` int(11) DEFAULT NULL,
  `list_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`checklist_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_client
#

DROP TABLE IF EXISTS `tbl_client`;

CREATE TABLE `tbl_client` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `primary_contact` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short_note` text COLLATE utf8_unicode_ci,
  `website` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `currency` varchar(32) COLLATE utf8_unicode_ci DEFAULT 'USD',
  `skype_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vat` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hosting_company` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hostname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` text COLLATE utf8_unicode_ci,
  `username` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `client_status` tinyint(1) NOT NULL COMMENT '1 = person and 2 = company',
  `profile_photo` text COLLATE utf8_unicode_ci,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `leads_id` int(11) NOT NULL,
  `latitude` text COLLATE utf8_unicode_ci,
  `longitude` text COLLATE utf8_unicode_ci,
  `customer_group_id` int(11) DEFAULT NULL,
  `active` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `sms_notification` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`) VALUES (81, 0, 'uAiMhYKoFwtmc', 'jemmerson21@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'USD', NULL, NULL, NULL, NULL, 'english', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2020-02-29 21:28:58', 0, NULL, NULL, NULL, '', NULL);
INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`) VALUES (82, 0, 'hvArISVnDCR', 'emlen_joy@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'USD', NULL, NULL, NULL, NULL, 'english', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2020-03-03 05:42:33', 0, NULL, NULL, NULL, '', NULL);
INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`) VALUES (83, 0, 'akuPSmqwhZQ', 'peteranthony2847@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'USD', NULL, NULL, NULL, NULL, 'english', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2020-03-07 08:56:08', 0, NULL, NULL, NULL, '', NULL);
INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`) VALUES (84, 0, 'VHoNJXqwcf', 'tonnie.dick@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'USD', NULL, NULL, NULL, NULL, 'english', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2020-03-09 17:17:23', 0, NULL, NULL, NULL, '', NULL);
INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`) VALUES (85, 0, 'DwOkFqZGu', 'johnbryan5576@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'USD', NULL, NULL, NULL, NULL, 'english', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2020-03-12 02:58:37', 0, NULL, NULL, NULL, '', NULL);
INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`) VALUES (86, 0, 'RhecnOMkImd', 'gardy_g@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'USD', NULL, NULL, NULL, NULL, 'english', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2020-03-12 13:19:45', 0, NULL, NULL, NULL, '', NULL);
INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`) VALUES (87, 0, 'qXMNFoEbBnRDUg', 'llloyd57@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'USD', NULL, NULL, NULL, NULL, 'english', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2020-03-15 00:49:51', 0, NULL, NULL, NULL, '', NULL);
INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`) VALUES (88, 0, 'RarjcuJpws', 'eugenio.mcvae@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'USD', NULL, NULL, NULL, NULL, 'english', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2020-03-15 10:36:05', 0, NULL, NULL, NULL, '', NULL);


#
# TABLE STRUCTURE FOR: tbl_client_menu
#

DROP TABLE IF EXISTS `tbl_client_menu`;

CREATE TABLE `tbl_client_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(20) DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  `icon` varchar(50) NOT NULL,
  `parent` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sort` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`menu_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (1, 'projects', 'client/projects', 'fa fa-folder-open-o', 0, '2017-04-19 08:18:26', 3, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (2, 'bugs', 'client/bugs', 'fa fa-bug', 0, '2017-04-19 08:18:39', 4, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (3, 'invoices', 'client/invoice/manage_invoice', 'fa fa-shopping-cart', 0, '2017-04-19 08:18:42', 5, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (4, 'estimates', 'client/estimates', 'fa fa-tachometer', 0, '2017-04-19 08:18:45', 6, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (5, 'payments', 'client/invoice/all_payments', 'fa fa-money', 0, '2017-04-19 08:18:48', 7, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (6, 'tickets', 'client/tickets', 'fa fa-ticket', 0, '2017-06-11 22:11:21', 8, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (7, 'quotations', 'client/quotations', 'fa fa-paste', 0, '2017-04-19 08:18:56', 9, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (8, 'users', 'client/user/user_list', 'fa fa-users', 0, '2017-04-19 08:18:59', 10, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (9, 'settings', 'client/settings', 'fa fa-cogs', 0, '2017-04-19 08:19:03', 11, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (12, 'answered', 'client/tickets/answered', 'fa fa-circle-o', 6, '2017-04-19 08:12:34', 1, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (17, 'dashboard', 'client/dashboard', 'icon-speedometer', 0, '2017-04-19 08:17:21', 1, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (18, 'mailbox', 'client/mailbox', 'fa fa-envelope', 0, '2017-04-19 08:17:21', 2, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (19, 'private_chat', 'chat/conversations', 'fa fa-envelope', 0, '2017-12-09 11:03:43', 12, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (20, 'filemanager', 'client/filemanager', 'fa fa-file', 0, '2017-06-02 20:08:23', 2, 1);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (21, 'proposals', 'client/proposals', 'fa fa-leaf', 0, '2017-07-20 19:21:08', 7, 1);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (22, 'knowledgebase', 'knowledgebase', 'fa fa-question-circle', 0, '2017-11-08 17:04:12', 12, 1);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (23, 'proposals', 'client/proposals', 'fa fa-leaf', 0, '2017-07-21 18:21:08', 7, 1);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (24, 'knowledgebase', 'knowledgebase', 'fa fa-question-circle', 0, '2020-01-12 14:08:44', 12, 1);


#
# TABLE STRUCTURE FOR: tbl_client_role
#

DROP TABLE IF EXISTS `tbl_client_role`;

CREATE TABLE `tbl_client_role` (
  `client_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`client_role_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=877 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (13, 2, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (14, 2, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (15, 2, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (16, 2, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (17, 2, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (18, 2, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (19, 2, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (20, 2, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (21, 2, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (22, 2, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (23, 2, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (24, 2, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (25, 9, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (26, 9, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (27, 9, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (28, 9, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (29, 9, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (30, 9, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (31, 9, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (32, 9, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (33, 9, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (34, 9, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (35, 9, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (36, 9, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (781, 74, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (782, 74, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (783, 74, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (784, 74, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (785, 74, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (786, 74, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (787, 74, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (788, 74, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (789, 74, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (790, 74, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (791, 74, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (792, 74, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (793, 75, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (794, 75, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (795, 75, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (796, 75, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (797, 75, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (798, 75, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (799, 75, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (800, 75, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (801, 75, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (802, 75, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (803, 75, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (804, 75, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (805, 76, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (806, 76, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (807, 76, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (808, 76, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (809, 76, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (810, 76, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (811, 76, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (812, 76, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (813, 76, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (814, 76, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (815, 76, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (816, 76, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (817, 77, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (818, 77, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (819, 77, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (820, 77, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (821, 77, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (822, 77, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (823, 77, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (824, 77, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (825, 77, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (826, 77, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (827, 77, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (828, 77, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (829, 78, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (830, 78, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (831, 78, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (832, 78, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (833, 78, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (834, 78, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (835, 78, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (836, 78, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (837, 78, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (838, 78, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (839, 78, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (840, 78, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (841, 79, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (842, 79, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (843, 79, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (844, 79, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (845, 79, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (846, 79, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (847, 79, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (848, 79, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (849, 79, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (850, 79, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (851, 79, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (852, 79, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (853, 80, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (854, 80, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (855, 80, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (856, 80, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (857, 80, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (858, 80, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (859, 80, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (860, 80, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (861, 80, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (862, 80, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (863, 80, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (864, 80, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (865, 81, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (866, 81, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (867, 81, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (868, 81, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (869, 81, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (870, 81, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (871, 81, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (872, 81, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (873, 81, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (874, 81, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (875, 81, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (876, 81, 22);


#
# TABLE STRUCTURE FOR: tbl_clock
#

DROP TABLE IF EXISTS `tbl_clock`;

CREATE TABLE `tbl_clock` (
  `clock_id` int(11) NOT NULL AUTO_INCREMENT,
  `attendance_id` int(11) NOT NULL,
  `clockin_time` time DEFAULT NULL,
  `clockout_time` time DEFAULT NULL,
  `comments` text,
  `clocking_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1= clockin_time',
  `ip_address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`clock_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`) VALUES (1, 1, '07:48:54', '07:49:01', NULL, 0, '156.204.14.110');
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`) VALUES (2, 2, '01:41:43', '02:08:49', NULL, 0, '156.213.109.122');
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`) VALUES (3, 3, '01:41:45', '08:39:56', NULL, 0, '156.213.109.122');
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`) VALUES (4, 4, '02:50:37', NULL, NULL, 1, '196.139.12.19');


#
# TABLE STRUCTURE FOR: tbl_clock_history
#

DROP TABLE IF EXISTS `tbl_clock_history`;

CREATE TABLE `tbl_clock_history` (
  `clock_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `clock_id` int(11) NOT NULL,
  `clockin_edit` time NOT NULL,
  `clockout_edit` time DEFAULT NULL,
  `reason` varchar(300) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=pending and 2 = accept  3= reject',
  `notify_me` tinyint(4) NOT NULL DEFAULT '1',
  `view_status` tinyint(4) NOT NULL DEFAULT '2',
  `request_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`clock_history_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_config
#

DROP TABLE IF EXISTS `tbl_config`;

CREATE TABLE `tbl_config` (
  `config_key` varchar(255) NOT NULL,
  `value` text,
  PRIMARY KEY (`config_key`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('2checkout_private_key', 'CE6B7C6E-CDC4-404A-80D7-08F40CC0C65D');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('2checkout_publishable_key', 'D188F8DC-3B8A-408E-A479-15A54113C461');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('2checkout_seller_id', '901386312');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('2checkout_status', 'deactive');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('absent_color', 'rgba(247,23,36,0.92)');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('absent_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('accounting_snapshot', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('active_background', '#1c7086');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('active_color', '#c1c1c1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('active_cronjob', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('active_custom_color', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('active_pre_loader', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('advance_salary', 'true');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('advance_salary_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aim_api_login_id', '7F6eJh7uFyD');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aim_authorize_live ', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aim_authorize_status', 'deactive');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aim_authorize_transaction_key', '64uhZ93mqH6c3MWf');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allowed_files', 'gif|png|jpeg|jpg|pdf|doc|txt|docx|xls|zip|rar|xls|mp4|ico|xlsx|pptx');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_apply_job_from_login', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_client_project', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_client_registration', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_customer_edit_amount', 'No');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_multiple_client_in_project', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_sub_tasks', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('amount_to_words_lowercase', 'No');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('announcements_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('api_signature', 'AZxbwZ9bPVPFFf7hCCNemacLJwlCAqoMULHXAenCuJAwtzfjGbkbaIhV');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aside-collapsed', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aside-float', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('attendance_report', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('authorize', 'login id');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('authorize_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('authorize_transaction_key', 'transfer key');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('automatic_database_backup', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('automatic_email_on_recur', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('auto_check_for_new_notifications', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('auto_close_ticket', '72');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('award_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('bank_cash', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('bitcoin_address', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('bitcoin_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('body_background', 'rgba(229,252,252,0.81)');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_default_account', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_live_or_sandbox', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_merchant_id', '9m2qzhrptx7wyccy');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_private_key', 'aa804bc269d4a9c8d8170ab8aed353b3');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_public_key', '62grv2dnvfpg599v');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('bugs_color', '#1f3d1c');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('bugs_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('build', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('ccavenue_access_code', 'AVEB75FA40AM89BEMA');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('ccavenue_enable_test_mode', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('ccavenue_key', '201F5203749670E18D664192B594B74E');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('ccavenue_merchant_id', '161761');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('ccavenue_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('client_default_menu', 'a:1:{s:19:\"client_default_menu\";a:12:{i:0;s:2:\"17\";i:1;s:2:\"18\";i:2;s:2:\"20\";i:3;s:1:\"1\";i:4;s:1:\"2\";i:5;s:1:\"3\";i:6;s:1:\"4\";i:7;s:1:\"5\";i:8;s:2:\"21\";i:9;s:1:\"6\";i:10;s:1:\"7\";i:11;s:2:\"22\";}}');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_address', '2 El-Obour Buildings, Salah Salem Heliopolis');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_city', 'cairo');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_country', 'Egypt');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_domain', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_email', 'info@ram-egy.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_legal_name', ' Ram For Sports Services');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_logo', 'uploads/default_logo.png');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_name', ' Ram For Sports Services');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_phone', '01226487462 - 01068888391');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_phone_2', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_vat', '728-153-386');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_zip_code', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_additional_flag', '/novalidate-cert');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_host', 'mail.coderitems.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_imap', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_imap_or_pop', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_mailbox', 'INBOX');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_password', '1c896e7d0fcbf64bb0921dd4bec18c947d34a5397472bb13b9f9ed95e4fd10dea45f365dde644233b2eef83f34e67cfd2fcc29b99c2835b89e8ecde5cdf233081hQfQaY72VtMiijV4wlVI6nmPwdsrMgJHALC3GCDw8E=');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_pop3', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_port', '993');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_ssl', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_username', 'support@coderitems.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('contact_person', 'Amr Attaalla');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('contract_expiration_reminder', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('copyright_name', 'Uniquecoder');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('copyright_url', 'https://codecanyon.net/user/unique_coder');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('country', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('cron_key', '34WI2L12L87I1A65M90M9A42N41D08A26I');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('currency_position', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('date_format', '%d-%m-%Y');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('date_php_format', 'd-m-Y');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('date_picker_format', 'dd-mm-yyyy');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('decimal_separator', '2');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_account', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_currency', 'EGP');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_currency_symbol', '$');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_department', '2');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_language', 'english');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_leads_source', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_lead_permission', 'all');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_lead_status', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_priority', 'ok');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_status', 'closed');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_tax', 'N;');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_terms', 'Thank you for <span style=\"font-weight: bold;\">your</span> busasiness. Please process this invoice within the due date.');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('delete_mail_after_import', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('demo_mode', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('deposit_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('desktop_notifications', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('developer', 'ig63Yd/+yuA8127gEyTz9TY4pnoeKq8dtocVP44+BJvtlRp8Vqcetwjk51dhSB6Rx8aVIKOPfUmNyKGWK7C/gg==');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('display_estimate_badge', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('display_invoice_badge', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('email_account_details', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('email_estimate_message', 'Hi {CLIENT}<br>Thanks for your business inquiry. <br>The estimate EST {REF} is attached with this email. <br>Estimate Overview:<br>Estimate # : EST {REF}<br>Amount: {CURRENCY} {AMOUNT}<br> You can view the estimate online at:<br>{LINK}<br>Best Regards,<br>{COMPANY}');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('email_invoice_message', 'Hello {CLIENT}<br>Here is the invoice of {CURRENCY} {AMOUNT}<br>You can view the invoice online at:<br>{LINK}<br>Best Regards,<br>{COMPANY}');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('email_staff_tickets', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('enable_languages', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('encryption', 'ssl');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_color', 'rgba(160,29,171,1)');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_footer', '<span style=\"font-weight: bold; line-height: 21.4px; text-align: right;\">Estimate&nbsp;</span>was created on a computer and is valid without the signature and seal');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_language', 'en');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_number_format', '[INV]-[yyyy]-[mm]-[dd]-[number]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_prefix', 'EST');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_start_no', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_state', 'block');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_terms', 'Hey Looking forward to doing business with you.');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('expense_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('favicon', 'uploads/default_logo.png');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('file_max_size', '80000');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('for_invoice', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('for_leads', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('for_tickets', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('gcal_api_key', 'AIzaSyBXcmmcboEyAgtoUtXjKXe4TfpsnEtoUDQ');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('gcal_id', 'kla83orf1u7hrj6p0u5gdmpji4@group.calendar.google.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('goal_tracking_color', '#537015');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('goal_tracking_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('google_api_key', 'AIzaSyDH0Cn1U4RGzExl3IySE9X_ZlXKpyxj2Z4');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('gst_state', 'AN');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('holiday_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('imap_search', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('imap_search_for_leads', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('imap_search_for_tickets', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('increment_estimate_number', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('increment_invoice_number', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('increment_proposal_number', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('installed', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoices_due_after', '5');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_color', '#53b567');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_footer', 'Invoice was created on a computer and is valid without the signature and seal');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_language', 'en');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_logo', 'uploads/thumnail.png');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_number_format', '[INV]-[yyyy]-[mm]-[dd]-[number]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_prefix', 'INV');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_start_no', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_state', 'block');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_view', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('item_total_qty_alert', 'No');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('job_circular_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('language', 'english');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('languages', 'spanish');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_autobackup', '1580234420');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_check', '1436363002');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_cronjob_run', '1584363617');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_postmaster_run', '1532751856');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_seen_activities', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_tickets_postmaster_run', '1532750363');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('layout-boxed', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('layout-fixed', 'layout-fixed');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('layout-h', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('leads_color', '#783131');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('leads_keyword', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('leads_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('leave_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('locale', 'ar_EG');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('login_background', 'uploads/ce2f4431288385_564a2fe33c51c.jpg');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('login_bg', 'bg-login.jpg');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('login_position', 'left');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('logofile', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('logo_or_icon', 'logo');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('mark_attendance_from_login', 'Yes');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('max_file_size', '5000');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('milestone_color', '#a86495');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('milestone_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('mollie_api_key', 'test_tkjFqFF6fP92FDSwBDHpeCzBRMBQBD');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('mollie_partner_id', '3106644');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('mollie_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('money_format', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('navbar_logo_background', 'rgba(104,155,162,0.95)');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notified_user', '[\"1\"]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_bug_assignment', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_bug_comments', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_bug_status', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_message_received', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_project_assignments', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_project_comments', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_project_files', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_task_assignments', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_ticket_reopened', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('office_hours', '8');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('office_time', 'same_time');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('only_allowed_ip_can_clock', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('on_leave_color', '#bd1a10');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('on_leave_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('opportunities_color', '#349685');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('opportunities_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('overtime_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payments_color', '#7f21c9');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payments_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_api_password', 'e64448f3fd988dda8ad7e0b1ba21a14c3e59a959008623d9c8bcfca8ca8f73677a82bc6d14075614ea192a98fa0494259859dd0e229ff831c1cdd7751f440cb0cS8v4CPtSoiC4rDwMliNLKtf35DXaZih8pZ7W6mRM9UJg9jYeKg0wwsnFA5Kqywv');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_api_username', 'billing_api1.itsolidity.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_cancel_url', 'paypal/cancel');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_email', 'billing@coderitems.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_ipn_url', 'paypal/t_ipn/ipn');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_live', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_success_url', 'paypal/success');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payslip_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payumoney_enable_test_mode', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payumoney_key', 'etzFvcmV');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payumoney_salt', 'Q3AbuWZ05e');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payumoney_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('pdf_engine', 'invoicr');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('performance_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('postmark_api_key', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('postmark_from_address', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('project_color', '#e61755');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('project_details_view', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('project_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('project_prefix', 'PRO');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('proposal_footer', '<table class=\"items\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" xss=\"removed\">\n         <tbody>\n          <tr>\n            <td>Trade License <span>Number : </span></td>\n            <td>127595</td>\n            <td xss=\"removed\"><span>127595</span></td>\n            <td xss=\"removed\"><span>:رقم السجل </span>التجاري</td>\n         </tr>\n\n<td><span>Address:</span></td>\n\n           <td colspan=\"0\"><span>Villa 10 - Block 11 -  9th District - Nasr City</span></td>\n\n           <td xss=\"removed\"><span>قطعة 10 - بلوك 11 - المنطقة التاسعة - مدينة نصر </span></td>\n\n           <td xss=\"removed\"><span>:العنوان</span></td>\n\n\n         </tr>\n\n\n         <tr xss=\"removed\">\n\n           <td colspan=\"3\"><br></td>\n<td xss=\"removed\"></td>\n</tr>\n\n\n         <tr>\n\n          <td colspan=\"4\"><span>ADDRESS: 13 Khaled Ebn El Waleed St. - Sheraton  Buildings, Heliopolis, Cairo, Egypt</span></td>\n\n        </tr>\n\n\n          <tr>\n\n          <td colspan=\"4\"><span>If you have any inquiry concerning this proposal, please  send an email to: <font class=\"font5\">sales@onetecgroup.com</font></span></td>\n\n         </tr>\n\n\n         <tr>\n\n          <td colspan=\"2\" xss=\"removed\"><span>RECEIVED BY:</span></td>\n\n          <td xss=\"removed\"><span>SIGNATURE:</span></td>\n\n         </tr>\n\n\n         <tr>\n\n          <td colspan=\"2\" xss=\"removed\"><span>DATE:</span></td>\n\n          <td xss=\"removed\"><span>STAMP:</span></td>\n\n          </tr>\n\n\n         <tr>\n\n          <td colspan=\"4\" xss=\"removed\"><span>THANK YOU FOR YOUR  BUSINESS!</span></td>\n\n         </tr>\n\n\n        </tbody>\n\n        </table>');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('proposal_number_format', '[PRO]-[yyyy]-[mm]-[dd]-[number]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('proposal_prefix', 'PRO-');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('proposal_start_no', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('proposal_terms', 'Hey Looking forward to doing business with you.');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('protocol', 'mail');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('purchase_code', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('purchase_notes', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('purchase_number_format', '[PUR]-[yyyy]-[mm]-[dd]-[number]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('purchase_prefix', 'PUR');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('purchase_start_no', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('pusher_app_id', '401479');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('pusher_app_key', '4cf88668659dc9c987c3');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('pusher_app_secret', '6fce183b214d17c20dd5');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('pusher_cluster', 'ap2');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('qty_calculation_from_items', 'Yes');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('realtime_notification', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('recaptcha_secret_key', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('recaptcha_site_key', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('recurring_invoice', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('reminder_message', 'Hello {CLIENT}<br>This is a friendly reminder to pay your invoice of {CURRENCY} {AMOUNT}<br>You can view the invoice online at:<br>{LINK}<br>Best Regards,<br>{COMPANY}');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('reset_key', '34WI2L12L87I1A65M90M9A42N41D08A26I');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('return_stock_number_format', '[PUR]-[yyyy]-[mm]-[dd]-[number]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('return_stock_prefix', 'R');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('return_stock_start_no', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('rows_per_table', '25');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('RTL', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('security_token', '5027133599');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('send_email_when_recur', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('settings', 'theme');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show-scrollbar', 'show-scrollbar');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_estimate_tax', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_invoice_tax', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_item_tax', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_login_image', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_only_logo', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_proposal_tax', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_active_background', '#0f778e');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_active_color', '#b3b8cb');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_background', 'rgba(2,53,60,0.95)');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_color', '#fffafa');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_theme', 'bg-info-dark');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('site_appleicon', 'logo.png');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('site_author', 'William M.');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('site_desc', 'Ultimate Project Manager CRM Pro is a Web based PHP application for Freelancers - buy it on Codecanyon');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('site_favicon', 'logo.png');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('site_icon', 'fa-flask');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('smtp_encryption', 'tls');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('smtp_host', 'mail.exclusivehosting.net');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('smtp_pass', 'ZjY3M09xeUQ5UUcxNzg1K3lreVg2UT09');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('smtp_port', '25');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('smtp_user', 'info@ram-egy.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('stripe_private_key', 'sk_test_g7PUZTcwwFnxdlHrWSOicHfu');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('stripe_public_key', 'pk_test_x9as1c9jBDpODI7IbC7D0MEB');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('stripe_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('submenu_open_background', '#227f85');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('system_font', 'roboto_condensed');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('tables_pagination_limit', '50');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('tasks_color', '#0239c7');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('tasks_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('task_details_view', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('thousand_separator', ',');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('tickets_keyword', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('timezone', 'Africa/Cairo');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('time_format', 'H:i');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('top_bar_background', '#1f9494');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('top_bar_color', '#d9d9d9');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('training_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('two_checkout_live ', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('unread_email', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('use_gravatar', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('use_postmark', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('valid_license', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('version', '1.4.2');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('webmaster_email', 'support@example.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('website_name', 'OTG');


#
# TABLE STRUCTURE FOR: tbl_contract_type
#

DROP TABLE IF EXISTS `tbl_contract_type`;

CREATE TABLE `tbl_contract_type` (
  `contract_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_type` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(500) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`contract_type_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_countries
#

DROP TABLE IF EXISTS `tbl_countries`;

CREATE TABLE `tbl_countries` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `value` varchar(250) CHARACTER SET latin1 NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_countries` (`id`, `value`) VALUES (1, 'Afghanistan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (2, 'Aringland Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (3, 'Albania');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (4, 'Algeria');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (5, 'American Samoa');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (6, 'Andorra');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (7, 'Angola');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (8, 'Anguilla');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (9, 'Antarctica');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (10, 'Antigua and Barbuda');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (11, 'Argentina');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (12, 'Armenia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (13, 'Aruba');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (14, 'Australia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (15, 'Austria');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (16, 'Azerbaijan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (17, 'Bahamas');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (18, 'Bahrain');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (19, 'Bangladesh');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (20, 'Barbados');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (21, 'Belarus');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (22, 'Belgium');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (23, 'Belize');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (24, 'Benin');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (25, 'Bermuda');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (26, 'Bhutan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (27, 'Bolivia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (28, 'Bosnia and Herzegovina');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (29, 'Botswana');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (30, 'Bouvet Island');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (31, 'Brazil');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (32, 'British Indian Ocean territory');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (33, 'Brunei Darussalam');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (34, 'Bulgaria');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (35, 'Burkina Faso');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (36, 'Burundi');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (37, 'Cambodia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (38, 'Cameroon');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (39, 'Canada');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (40, 'Cape Verde');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (41, 'Cayman Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (42, 'Central African Republic');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (43, 'Chad');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (44, 'Chile');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (45, 'China');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (46, 'Christmas Island');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (47, 'Cocos (Keeling) Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (48, 'Colombia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (49, 'Comoros');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (50, 'Congo');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (51, 'Congo');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (52, ' Democratic Republic');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (53, 'Cook Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (54, 'Costa Rica');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (55, 'Ivory Coast (Ivory Coast)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (56, 'Croatia (Hrvatska)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (57, 'Cuba');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (58, 'Cyprus');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (59, 'Czech Republic');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (60, 'Denmark');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (61, 'Djibouti');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (62, 'Dominica');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (63, 'Dominican Republic');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (64, 'East Timor');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (65, 'Ecuador');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (66, 'Egypt');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (67, 'El Salvador');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (68, 'Equatorial Guinea');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (69, 'Eritrea');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (70, 'Estonia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (71, 'Ethiopia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (72, 'Falkland Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (73, 'Faroe Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (74, 'Fiji');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (75, 'Finland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (76, 'France');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (77, 'French Guiana');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (78, 'French Polynesia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (79, 'French Southern Territories');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (80, 'Gabon');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (81, 'Gambia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (82, 'Georgia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (83, 'Germany');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (84, 'Ghana');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (85, 'Gibraltar');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (86, 'Greece');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (87, 'Greenland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (88, 'Grenada');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (89, 'Guadeloupe');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (90, 'Guam');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (91, 'Guatemala');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (92, 'Guinea');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (93, 'Guinea-Bissau');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (94, 'Guyana');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (95, 'Haiti');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (96, 'Heard and McDonald Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (97, 'Honduras');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (98, 'Hong Kong');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (99, 'Hungary');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (100, 'Iceland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (101, 'India');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (102, 'Indonesia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (103, 'Iran');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (104, 'Iraq');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (105, 'Ireland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (106, 'Israel');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (107, 'Italy');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (108, 'Jamaica');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (109, 'Japan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (110, 'Jordan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (111, 'Kazakhstan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (112, 'Kenya');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (113, 'Kiribati');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (114, 'Korea (north)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (115, 'Korea (south)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (116, 'Kuwait');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (117, 'Kyrgyzstan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (118, 'Lao People\'s Democratic Republic');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (119, 'Latvia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (120, 'Lebanon');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (121, 'Lesotho');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (122, 'Liberia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (123, 'Libyan Arab Jamahiriya');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (124, 'Liechtenstein');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (125, 'Lithuania');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (126, 'Luxembourg');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (127, 'Macao');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (128, 'Macedonia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (129, 'Madagascar');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (130, 'Malawi');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (131, 'Malaysia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (132, 'Maldives');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (133, 'Mali');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (134, 'Malta');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (135, 'Marshall Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (136, 'Martinique');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (137, 'Mauritania');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (138, 'Mauritius');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (139, 'Mayotte');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (140, 'Mexico');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (141, 'Micronesia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (142, 'Moldova');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (143, 'Monaco');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (144, 'Mongolia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (145, 'Montserrat');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (146, 'Morocco');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (147, 'Mozambique');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (148, 'Myanmar');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (149, 'Namibia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (150, 'Nauru');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (151, 'Nepal');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (152, 'Netherlands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (153, 'Netherlands Antilles');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (154, 'New Caledonia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (155, 'New Zealand');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (156, 'Nicaragua');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (157, 'Niger');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (158, 'Nigeria');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (159, 'Niue');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (160, 'Norfolk Island');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (161, 'Northern Mariana Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (162, 'Norway');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (163, 'Oman');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (164, 'Pakistan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (165, 'Palau');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (166, 'Palestinian Territories');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (167, 'Panama');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (168, 'Papua New Guinea');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (169, 'Paraguay');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (170, 'Peru');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (171, 'Philippines');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (172, 'Pitcairn');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (173, 'Poland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (174, 'Portugal');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (175, 'Puerto Rico');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (176, 'Qatar');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (177, 'Runion');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (178, 'Romania');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (179, 'Russian Federation');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (180, 'Rwanda');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (181, 'Saint Helena');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (182, 'Saint Kitts and Nevis');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (183, 'Saint Lucia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (184, 'Saint Pierre and Miquelon');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (185, 'Saint Vincent and the Grenadines');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (186, 'Samoa');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (187, 'San Marino');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (188, 'Sao Tome and Principe');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (189, 'Saudi Arabia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (190, 'Senegal');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (191, 'Serbia and Montenegro');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (192, 'Seychelles');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (193, 'Sierra Leone');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (194, 'Singapore');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (195, 'Slovakia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (196, 'Slovenia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (197, 'Solomon Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (198, 'Somalia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (199, 'South Africa');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (200, 'South Georgia and the South Sandwich Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (201, 'Spain');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (202, 'Sri Lanka');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (203, 'Sudan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (204, 'Suriname');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (205, 'Svalbard and Jan Mayen Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (206, 'Swaziland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (207, 'Sweden');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (208, 'Switzerland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (209, 'Syria');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (210, 'Taiwan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (211, 'Tajikistan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (212, 'Tanzania');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (213, 'Thailand');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (214, 'Togo');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (215, 'Tokelau');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (216, 'Tonga');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (217, 'Trinidad and Tobago');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (218, 'Tunisia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (219, 'Turkey');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (220, 'Turkmenistan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (221, 'Turks and Caicos Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (222, 'Tuvalu');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (223, 'Uganda');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (224, 'Ukraine');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (225, 'United Arab Emirates');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (226, 'United Kingdom');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (227, 'United States of America');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (228, 'Uruguay');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (229, 'Uzbekistan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (230, 'Vanuatu');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (231, 'Vatican City');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (232, 'Venezuela');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (233, 'Vietnam');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (234, 'Virgin Islands (British)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (235, 'Virgin Islands (US)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (236, 'Wallis and Futuna Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (237, 'Western Sahara');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (238, 'Yemen');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (239, 'Zaire');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (240, 'Zambia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (241, 'Zimbabwe');


#
# TABLE STRUCTURE FOR: tbl_currencies
#

DROP TABLE IF EXISTS `tbl_currencies`;

CREATE TABLE `tbl_currencies` (
  `code` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symbol` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `xrate` decimal(12,5) DEFAULT NULL,
  PRIMARY KEY (`code`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('AUD', 'Australian Dollar', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('BAN', 'Bangladesh', 'BDT', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('BRL', 'Brazilian Real', 'R$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('CAD', 'Canadian Dollar', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('CHF', 'Swiss Franc', 'Fr', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('CLP', 'Chilean Peso', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('CNY', 'Chinese Yuan', 'Â¥', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('CZK', 'Czech Koruna', 'KÄ', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('DKK', 'Danish Krone', 'kr', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('EGP', 'Egyptian Pounds', 'EGP', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('EUR', 'Euro', 'â‚¬', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('GBP', 'British Pound', 'Â£', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('HKD', 'Hong Kong Dollar', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('HUF', 'Hungarian Forint', 'Ft', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('IDR', 'Indonesian Rupiah', 'Rp', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('ILS', 'Israeli New Shekel', 'â‚ª', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('INR', 'Indian Rupee', 'à¤°', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('JPY', 'Japanese Yen', 'Â¥', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('KRW', 'Korean Won', 'â‚©', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('MXN', 'Mexican Peso', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('MYR', 'Malaysian Ringgit', 'RM', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('NOK', 'Norwegian Krone', 'kr', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('NZD', 'New Zealand Dollar', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('PHP', 'Philippine Peso', 'â‚±', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('PKR', 'Pakistan Rupee', 'PKR', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('PLN', 'Polish Zloty', 'zl', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('RUB', 'Russian Ruble', ' RUB', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('SEK', 'Swedish Krona', 'kr', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('SGD', 'Singapore Dollar', 'S$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('THB', 'Thai Baht', 'à¸¿', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('TRY', 'Turkish Lira', ' TRY', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('TWD', 'Taiwan Dollar', 'NT$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('USD', 'US Dollar', '$', '1.00000');
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('VEF', 'Bol?var Fuerte', 'Bs.', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('ZAR', 'South African Rand', 'R', NULL);


#
# TABLE STRUCTURE FOR: tbl_custom_field
#

DROP TABLE IF EXISTS `tbl_custom_field`;

CREATE TABLE `tbl_custom_field` (
  `custom_field_id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) DEFAULT NULL,
  `field_label` varchar(100) NOT NULL,
  `default_value` text,
  `help_text` varchar(200) NOT NULL,
  `field_type` enum('text','textarea','dropdown','date','checkbox','numeric','url','email') NOT NULL,
  `required` varchar(5) NOT NULL DEFAULT 'false',
  `status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `show_on_table` varchar(5) DEFAULT NULL,
  `visible_for_admin` varchar(5) DEFAULT NULL,
  `show_on_details` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`custom_field_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_customer_group
#

DROP TABLE IF EXISTS `tbl_customer_group`;

CREATE TABLE `tbl_customer_group` (
  `customer_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) DEFAULT NULL COMMENT 'customer group,item group',
  `customer_group` varchar(200) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`customer_group_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_customer_group` (`customer_group_id`, `type`, `customer_group`, `description`) VALUES (1, 'items', 'Taishan', '');
INSERT INTO `tbl_customer_group` (`customer_group_id`, `type`, `customer_group`, `description`) VALUES (2, 'items', 'floor mats', '');
INSERT INTO `tbl_customer_group` (`customer_group_id`, `type`, `customer_group`, `description`) VALUES (3, 'items', 'Ram equipment ', NULL);


#
# TABLE STRUCTURE FOR: tbl_dashboard
#

DROP TABLE IF EXISTS `tbl_dashboard`;

CREATE TABLE `tbl_dashboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 NOT NULL,
  `col` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `order_no` int(2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `report` tinyint(1) NOT NULL DEFAULT '0',
  `for_staff` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `pcasa_ram` */ ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (1, 'income_expenses_report', 'col-sm-4', 1, 1, 1, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (2, 'invoice_payment_report', 'col-sm-4', 2, 1, 1, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (3, 'ticket_tasks_report', 'col-sm-4', 3, 1, 1, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (5, 'goal_report', 'col-md-12 ', 18, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (6, 'overdue_report', 'col-md-12', 21, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (11, 'my_project', 'col-md-6', 32, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (12, 'my_tasks', 'col-md-6', 35, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (14, 'announcements', 'col-md-6', 38, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (15, 'payments_report', 'col-md-6', 47, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (16, 'income_expense', 'col-md-6', 9, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (17, 'income_report', 'col-md-6', 50, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (18, 'expense_report', 'col-md-6', 44, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (19, 'recently_paid_invoices', 'col-md-6', 29, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (20, 'recent_activities', 'col-md-6', 26, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (21, 'finance_overview', 'col-sm-12', 1, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (22, 'todo_list', 'col-md-6', 40, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (23, 'paid_amount', 'col-md-3', 2, 1, 2, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (24, 'due_amount', 'col-md-3', 4, 1, 2, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (25, 'invoice_amount', 'col-md-3', 1, 1, 2, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (26, 'paid_percentage', 'col-md-3', 3, 1, 2, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (27, 'recently_paid_invoices', 'col-sm-6', 2, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (28, 'payments', 'col-sm-6', 1, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (29, 'recent_invoice', 'col-sm-6', 3, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (30, 'recent_projects', 'col-sm-6', 4, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (31, 'recent_emails', 'col-sm-4', 5, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (32, 'recent_activities', 'col-sm-4', 6, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (33, 'announcements', 'col-sm-4', 7, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (34, 'my_calendar', 'col-sm-6', 15, 1, 0, 1);


#
# TABLE STRUCTURE FOR: tbl_days
#

DROP TABLE IF EXISTS `tbl_days`;

CREATE TABLE `tbl_days` (
  `day_id` int(5) NOT NULL AUTO_INCREMENT,
  `day` varchar(100) NOT NULL,
  PRIMARY KEY (`day_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (1, 'Saturday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (2, 'Sunday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (3, 'Monday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (4, 'Tuesday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (5, 'Wednesday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (6, 'Thursday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (7, 'Friday');


#
# TABLE STRUCTURE FOR: tbl_departments
#

DROP TABLE IF EXISTS `tbl_departments`;

CREATE TABLE `tbl_departments` (
  `departments_id` int(10) NOT NULL AUTO_INCREMENT,
  `deptname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `department_head_id` int(11) DEFAULT NULL COMMENT 'department_head_id == user_id',
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `encryption` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `host` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `mailbox` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `unread_email` tinyint(1) NOT NULL DEFAULT '0',
  `delete_mail_after_import` tinyint(1) NOT NULL DEFAULT '0',
  `last_postmaster_run` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`departments_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_departments` (`departments_id`, `deptname`, `department_head_id`, `email`, `encryption`, `host`, `username`, `password`, `mailbox`, `unread_email`, `delete_mail_after_import`, `last_postmaster_run`) VALUES (2, 'Board Members', 11, NULL, '', '', '', '', '', 0, 0, NULL);
INSERT INTO `tbl_departments` (`departments_id`, `deptname`, `department_head_id`, `email`, `encryption`, `host`, `username`, `password`, `mailbox`, `unread_email`, `delete_mail_after_import`, `last_postmaster_run`) VALUES (3, 'Human Resources', NULL, NULL, '', '', '', '', '', 0, 0, NULL);
INSERT INTO `tbl_departments` (`departments_id`, `deptname`, `department_head_id`, `email`, `encryption`, `host`, `username`, `password`, `mailbox`, `unread_email`, `delete_mail_after_import`, `last_postmaster_run`) VALUES (4, 'Sales', NULL, NULL, '', '', '', '', '', 0, 0, NULL);
INSERT INTO `tbl_departments` (`departments_id`, `deptname`, `department_head_id`, `email`, `encryption`, `host`, `username`, `password`, `mailbox`, `unread_email`, `delete_mail_after_import`, `last_postmaster_run`) VALUES (5, 'Finance', NULL, NULL, '', '', '', '', '', 0, 0, NULL);
INSERT INTO `tbl_departments` (`departments_id`, `deptname`, `department_head_id`, `email`, `encryption`, `host`, `username`, `password`, `mailbox`, `unread_email`, `delete_mail_after_import`, `last_postmaster_run`) VALUES (6, 'Construction', 10, NULL, '', '', '', '', '', 0, 0, NULL);


#
# TABLE STRUCTURE FOR: tbl_designations
#

DROP TABLE IF EXISTS `tbl_designations`;

CREATE TABLE `tbl_designations` (
  `designations_id` int(5) NOT NULL AUTO_INCREMENT,
  `departments_id` int(11) NOT NULL,
  `designations` varchar(100) NOT NULL,
  `permission` text,
  PRIMARY KEY (`designations_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (2, 2, 'Board Members', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (3, 3, 'Human Resources', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (5, 4, 'Sales', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (6, 5, 'Finance', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (7, 6, 'Construction', NULL);


#
# TABLE STRUCTURE FOR: tbl_discipline
#

DROP TABLE IF EXISTS `tbl_discipline`;

CREATE TABLE `tbl_discipline` (
  `discipline_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `offence_id` int(5) NOT NULL,
  `penalty_id` int(5) NOT NULL,
  `discipline_break_date` varchar(100) NOT NULL,
  `discipline_action_date` varchar(100) NOT NULL,
  `discipline_remarks` varchar(200) NOT NULL,
  `discipline_comments` varchar(200) NOT NULL,
  PRIMARY KEY (`discipline_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_draft
#

DROP TABLE IF EXISTS `tbl_draft`;

CREATE TABLE `tbl_draft` (
  `draft_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `to` text NOT NULL,
  `subject` varchar(300) NOT NULL,
  `message_body` text NOT NULL,
  `attach_file` text,
  `attach_file_path` text,
  `attach_filename` text,
  `message_time` datetime NOT NULL,
  `deleted` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`draft_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_email_templates
#

DROP TABLE IF EXISTS `tbl_email_templates`;

CREATE TABLE `tbl_email_templates` (
  `email_templates_id` int(11) NOT NULL AUTO_INCREMENT,
  `email_group` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template_body` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`email_templates_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (1, 'registration', 'Registration successful', '<div style=\"height: 7px; background-color: #535353;\"></div><div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Welcome to {SITE_NAME}</div><div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\">Thanks for joining {SITE_NAME}. We listed your sign in details below, make sure you keep them safe.<br>To open your {SITE_NAME} homepage, please follow this link:<br><big><b><a href=\"{SITE_URL}\">{SITE_NAME} Account!</a></b></big><br>Link doesn\'t work? Copy the following link to your browser address bar:<br><a href=\"{SITE_URL}\">{SITE_URL}</a><br>Your username: {USERNAME}<br>Your email address: {EMAIL}<br>Your password: {PASSWORD}<br>Have fun!<br>The {SITE_NAME} Team.<br><br></div></div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (2, 'forgot_password', 'Forgot Password', '        <div style=\"height: 7px; background-color: #535353;\"></div><div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">New Password</div><div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\">Forgot your password, huh? No big deal.<br>To create a new password, just follow this link:<br><br><big><b><a href=\"{PASS_KEY_URL}\">Create a new password</a></b></big><br>Link doesn\'t work? Copy the following link to your browser address bar:<br><a href=\"{PASS_KEY_URL}\">{PASS_KEY_URL}</a><br><br><br>You received this email, because it was requested by a <a href=\"{SITE_URL}\">{SITE_NAME}</a> user. <p></p><p>This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same.</p><br>Thank you,<br>The {SITE_NAME} Team</div></div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (3, 'change_email', 'Change Email', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">New email address on {SITE_NAME}</div>\r\n\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\">You have changed your email address for {SITE_NAME}.<br>Follow this link to confirm your new email address:<br><big><b><a href=\"{NEW_EMAIL_KEY_URL}\">Confirm your new email</a></b></big><br>Link doesn\'t work? Copy the following link to your browser address bar:<br><a href=\"{NEW_EMAIL_KEY_URL}\">{NEW_EMAIL_KEY_URL}</a><br><br>Your email address: {NEW_EMAIL}<br><br>You received this email, because it was requested by a <a href=\"{SITE_URL}\">{SITE_NAME}</a> user. If you have received this by mistake, please DO NOT click the confirmation link, and simply delete this email. After a short time, the request will be removed from the system.<br>Thank you,<br>The {SITE_NAME} Team</div>\r\n\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (4, 'activate_account', 'Activate Account', '<p>Welcome to {SITE_NAME}!</p>\r\n\r\n<p>Thanks for joining {SITE_NAME}. We listed your sign in details below, make sure you keep them safe.</p>\r\n\r\n<p>To verify your email address, please follow this link:<br />\r\n<big><strong><a href=\"{ACTIVATE_URL}\">Finish your registration...</a></strong></big><br />\r\nLink doesn&#39;t work? Copy the following link to your browser address bar:<br />\r\n<a href=\"{ACTIVATE_URL}\">{ACTIVATE_URL}</a></p>\r\n\r\n<p><br />\r\n<br />\r\nPlease verify your email within {ACTIVATION_PERIOD} hours, otherwise your registration will become invalid and you will have to register again.<br />\r\n<br />\r\n<br />\r\nYour username: {USERNAME}<br />\r\nYour email address: {EMAIL}<br />\r\nYour password: {PASSWORD}<br />\r\n<br />\r\nHave fun!<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (5, 'reset_password', 'Reset Password', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">New password on {SITE_NAME}</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>You have changed your password.<br>Please, keep it in your records so you don\'t forget it.<br></p>\r\nYour username: {USERNAME}<br>Your email address: {EMAIL}<br>Your new password: {NEW_PASSWORD}<br><br>Thank you,<br>The {SITE_NAME} Team</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (6, 'bug_assigned', 'New Bug Assigned', '<p>Hi there,</p>\r\n\r\n<p>A new bug &nbsp;{BUG_TITLE} &nbsp;has been assigned to you by {ASSIGNED_BY}.</p>\r\n\r\n<p>You can view this bug by logging in to the portal using the link below.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{BUG_URL}\">View Bug</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (7, 'bug_updated', 'Bug status changed', '<p>Hi there,</p>\r\n\r\n<p>Bug {BUG_TITLE} has been marked as {STATUS} by {MARKED_BY}.</p>\r\n\r\n<p>You can view this bug by logging in to the portal using the link below.</p>\r\n\r\n<p><big><strong><a href=\"{BUG_URL}\">View Bug</a></strong></big><br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (8, 'bug_comments', 'New Bug Comment Received', '<p>Hi there,</p>\r\n\r\n<p>A new comment has been posted by {POSTED_BY} to bug {BUG_TITLE}.</p>\r\n\r\n<p>You can view the comment using the link below.</p>\r\n\r\n<p><em>{COMMENT_MESSAGE}</em></p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{COMMENT_URL}\">View Comment</a></strong></big><br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (9, 'bug_attachment', 'New bug attachment', '<p>Hi there,</p>\r\n\r\n<p>A new attachment&nbsp;has been uploaded by {UPLOADED_BY} to issue {BUG_TITLE}.</p>\r\n\r\n<p>You can view the bug using the link below.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{BUG_URL}\">View Bug</a></strong></big></p>\r\n\r\n<p><br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (10, 'bug_reported', 'New bug Reported', '<p>Hi there,</p>\r\n\r\n<p>A new bug ({BUG_TITLE}) has been reported by {ADDED_BY}.</p>\r\n\r\n<p>You can view the Bug using the Dashboard Page.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{BUG_URL}\">View Bug</a></strong></big></p>\r\n\r\n<p><br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (13, 'refund_confirmation', 'Refund Confirmation', '<p>Refund Confirmation</p>\r\n\r\n<p>Hello {CLIENT}</p>\r\n\r\n<p>This is confirmation that a refund has been processed for Invoice&nbsp; of {CURRENCY} {AMOUNT}&nbsp;sent on {INVOICE_DATE}.<br />\r\nYou can view the invoice online at:<br />\r\n<big><strong><a href=\"{INVOICE_LINK}\">View Invoice</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (14, 'payment_confirmation', 'Payment Confirmation', '<p>Payment Confirmation</p>\r\n\r\n<p>Hello {CLIENT}</p>\r\n\r\n<p>This is a payment receipt for your invoice of {CURRENCY} {AMOUNT}&nbsp;sent on {INVOICE_DATE}.<br />\r\nYou can view the invoice online at:<br />\r\n<big><strong><a href=\"{INVOICE_LINK}\">View Invoice</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (15, 'payment_email', 'Payment Received', '<div style=\"height: 7px; background-color: #535353;\"></div>\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Payment Received</div>\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>Dear Customer</p>\n<p>We have received your payment of {INVOICE_CURRENCY} {PAID_AMOUNT}. </p>\n<p>Thank you for your Payment and business. We look forward to working with you again.</p>\n--------------------------<br>Regards<br>The {SITE_NAME} Team</div>\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (16, 'invoice_overdue_email', 'Invoice Overdue Notice', '<p>Invoice Overdue</p>\r\n\r\n<p>INVOICE {REF}</p>\r\n\r\n<p><strong>Hello {CLIENT}</strong></p>\r\n\r\n<p>This is the notice that your invoice overdue.&nbsp;The invoice {CURRENCY} {AMOUNT}. and Due Date: {DUE_DATE}</p>\r\n\r\n<p>You can view the invoice online at:<br />\r\n<big><strong><a href=\"{INVOICE_LINK}\">View Invoice</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (17, 'invoice_message', 'New Invoice', '<div style=\"height: 7px; background-color: #535353;\"></div><div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">INVOICE {REF}</div><div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><span class=\"style1\"><span style=\"font-weight:bold;\">Hello {CLIENT}</span></span><br><br>Here is the invoice of {CURRENCY} {AMOUNT}.<br><br>You can view the invoice online at:<br><big><b><a href=\"{INVOICE_LINK}\">View Invoice</a></b></big><br><br>Best Regards<br><br>The {SITE_NAME} Team</div></div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (18, 'invoice_reminder', 'Invoice Reminder', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Invoice Reminder</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>Hello {CLIENT}</p>\r\n<br><p>This is a friendly reminder to pay your invoice of {CURRENCY} {AMOUNT}<br>You can view the invoice online at:<br><big><b><a href=\"{INVOICE_LINK}\">View Invoice</a></b></big><br><br>Best Regards,<br>The {SITE_NAME} Team</p>\r\n</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (19, 'message_received', 'Message Received', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Message Received</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>Hi {RECIPIENT},</p>\r\n<p>You have received a message from {SENDER}. </p>\r\n------------------------------------------------------------------<br><blockquote>\r\n{MESSAGE}</blockquote>\r\n<big><b><a href=\"{SITE_URL}\">Go to Account</a></b></big><br><br>Regards<br>The {SITE_NAME} Team</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (20, 'estimate_email', 'New Estimate', '<p>Estimate {ESTIMATE_REF}</p>\r\n\r\n<p>Hi {CLIENT}</p>\r\n\r\n<p>Thanks for your business inquiry.</p>\r\n\r\n<p>The estimate {ESTIMATE_REF} is attached with this email.<br />\r\nEstimate Overview:<br />\r\nEstimate # : {ESTIMATE_REF}<br />\r\nAmount: {CURRENCY} {AMOUNT}<br />\r\n<br />\r\nYou can view the estimate online at:<br />\r\n<big><strong><a href=\"{ESTIMATE_LINK}\">View Estimate</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (21, 'ticket_staff_email', 'New Ticket [TICKET_CODE]', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">New Ticket</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>Ticket #{TICKET_CODE} has been created by the client.</p>\r\n<p>You may view the ticket by clicking on the following link <br><br>  Client Email : {REPORTER_EMAIL}<br><br> <big><b><a href=\"{TICKET_LINK}\">View Ticket</a></b></big> <br><br>Regards<br><br>{SITE_NAME}</p>\r\n</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (22, 'ticket_client_email', 'Ticket [TICKET_CODE] Opened', '<p>Ticket Opened</p>\r\n\r\n<p>Hello {CLIENT_EMAIL},</p>\r\n\r\n<p>Your ticket has been opened with us.<br />\r\n<br />\r\nTicket # {TICKET_CODE}<br />\r\nStatus : Open<br />\r\n<br />\r\nClick on the below link to see the ticket details and post additional comments.<br />\r\n<br />\r\n<big><strong><a href=\"{TICKET_LINK}\">View Ticket</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (23, 'ticket_reply_email', 'Ticket [TICKET_CODE] Response', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Ticket Response</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>A new response has been added to Ticket #{TICKET_CODE}<br><br> Ticket : #{TICKET_CODE} <br>Status : {TICKET_STATUS} <br><br></p>\r\nTo see the response and post additional comments, click on the link below.<br><br>         <big><b><a href=\"{TICKET_LINK}\">View Reply</a> </b></big><br><br>          Note: Do not reply to this email as this email is not monitored.<br><br>     Regards<br>The {SITE_NAME} Team<br></div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (24, 'ticket_closed_email', 'Ticket [TICKET_CODE] Closed', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Ticket Closed</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\">Hi {REPORTER_EMAIL}<br><br>Ticket #{TICKET_CODE} has been closed by {STAFF_USERNAME} <br><br>          Ticket : #{TICKET_CODE} <br>     Status : {TICKET_STATUS}<br><br>Replies : {NO_OF_REPLIES}<br><br>          To see the responses or open the ticket, click on the link below.<br><br>          <big><b><a href=\"{TICKET_LINK}\">View Ticket</a></b></big> <br><br>          Note: Do not reply to this email as this email is not monitored.<br><br>    Regards<br>The {SITE_NAME} Team</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (26, 'task_updated', 'Task updated', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Task updated</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>Hi there,</p>\r\n<p>{TASK_NAME} in {PROJECT_TITLE} has been updated by {ASSIGNED_BY}.</p>\r\n<p>You can view this project by logging in to the portal using the link below.</p>\r\n-----------------------------------<br><big><b><a href=\"{PROJECT_URL}\">View Project</a></b></big><br><br>Regards<br>The {SITE_NAME} Team</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (27, 'quotations_form', 'Your Quotation Request', '<p>QUOTATION</p>\r\n\r\n<p><strong>Hello {CLIENT}</strong><br />\r\n&nbsp;</p>\r\n\r\n<p>Thank you for you for filling in our Quotation Request Form.<br />\r\n<br />\r\nPlease find below are our quotation:</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table cellpadding=\"8\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Quotation Date</td>\r\n			<td><strong>{DATE}</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Our Quotation</td>\r\n			<td><strong>{CURRENCY} {AMOUNT}</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Addtitional Comments</td>\r\n			<td><strong>{NOTES}</strong></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><br />\r\nYou can view the estimate online at:<br />\r\n<big><strong><a href=\"{QUOTATION LINK}\">View Quotation</a></strong></big></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\nThank you and we look forward to working with you.<br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (28, 'client_notification', 'New project created', '<p>Hello, <strong>{CLIENT_NAME}</strong>,<br />\r\nwe have created a new project with your account.<br />\r\n<br />\r\nProject name : <strong>{PROJECT_NAME}</strong><br />\r\nYou can login to see the status of your project by using this link:<br />\r\n<big><a href=\"{PROJECT_LINK}\"><strong>View Project</strong></a></big></p>\r\n\r\n<p><br />\r\nBest Regards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (29, 'assigned_project', 'Assigned Project', '<p>Hi There,</p>\r\n\r\n<p>A<strong> {PROJECT_NAME}</strong> has been assigned by <strong>{ASSIGNED_BY} </strong>to you.You can view this project by logging in to the portal using the link below:<br />\r\n<big><a href=\"{PROJECT_URL}\"><strong>View Project</strong></a></big><br />\r\n<br />\r\nBest Regards<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (30, 'complete_projects', 'Project Completed', '<p>Hi <strong>{CLIENT_NAME}</strong>,</p>\r\n\r\n<p>Project : <strong>{PROJECT_NAME}</strong> &nbsp;has been completed.<br />\r\nYou can view the project by logging into your portal Account:<br />\r\n<big><a href=\"{PROJECT_LINK}\"><strong>View Project</strong></a></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (31, 'project_comments', 'New Project Comment Received', '<p>Hi There,</p>\r\n\r\n<p>A new comment has been posted by <strong>{POSTED_BY}</strong> to project <strong>{PROJECT_NAME}</strong>.</p>\r\n\r\n<p>You can view the comment using the link below:<br />\r\n<big><a href=\"{COMMENT_URL}\"><strong>View Project</strong></a></big><br />\r\n<br />\r\n<em>{COMMENT_MESSAGE}</em><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (32, 'project_attachment', 'New Project  Attachment', '<p>Hi There,</p>\r\n\r\n<p>A new file has been uploaded by <strong>{UPLOADED_BY}</strong> to project <strong>{PROJECT_NAME}</strong>.<br />\r\nYou can view the Project using the link below:<br />\r\n<big><a href=\"{PROJECT_URL}\"><strong>View Project</strong></a></big><br />\r\n<br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (33, 'responsible_milestone', 'Responsible for a Milestone', '<p>Hi There,</p>\r\n\r\n<p>You are a responsible&nbsp;for a project milestone&nbsp;<strong>{MILESTONE_NAME}</strong>&nbsp; assigned to you by <strong>{ASSIGNED_BY}</strong> in project <strong>{PROJECT_NAME}</strong>.</p>\r\n\r\n<p>You can view this Milestone&nbsp;by logging in to the portal using the link below:<br />\r\n<big><strong><a href=\"{PROJECT_URL}\">View Project</a></strong></big><br />\r\n<br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (34, 'task_assigned', 'Task assigned', '<p>Hi there,</p>\r\n\r\n<p>A new task <strong>{TASK_NAME}</strong> &nbsp;has been assigned to you by <strong>{ASSIGNED_BY}</strong>.</p>\r\n\r\n<p>You can view this task by logging in to the portal using the link below.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{TASK_URL}\">View Task</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (35, 'tasks_comments', 'New Task Comment Received', '<p>Hi There,</p>\r\n\r\n<p>A new comment has been posted by <strong>{POSTED_BY}</strong> to <strong>{TASK_NAME}</strong>.</p>\r\n\r\n<p>You can view the comment using the link below:<br />\r\n<big><strong><a href=\"{COMMENT_URL}\">View Comment</a></strong></big><br />\r\n<br />\r\n<em>{COMMENT_MESSAGE}</em><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (36, 'tasks_attachment', 'New Tasks Attachment', '<p>Hi There,</p>\r\n\r\n<p>A new file has been uploaded by <strong>{UPLOADED_BY} </strong>to Task <strong>{TASK_NAME}</strong>.<br />\r\nYou can view the Task&nbsp;using the link below:</p>\r\n\r\n<p><br />\r\n<big><a href=\"{TASK_URL}\"><strong>View Task</strong></a></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (37, 'tasks_updated', 'Task updated', '<p>Hi there,</p>\r\n\r\n<p><strong>{TASK_NAME}</strong> has been updated by <strong>{ASSIGNED_BY}</strong>.</p>\r\n\r\n<p>You can view this Task by logging in to the portal using the link below.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{TASK_URL}\">View Task</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (38, 'goal_not_achieve', 'Not Achieve Goal', '<p><strong>Unfortunately!</strong> We failed to achieve goal!</p>\r\n\r\n<p><strong>Here is a Goal Details</strong></p>\r\n\r\n<p>Goal Type :&nbsp;<strong>{Goal_Type}</strong><br />\r\nTarget Achievement:&nbsp;<strong>{achievement}</strong><br />\r\nTotal Achievement:&nbsp;<strong>{total_achievement}</strong><br />\r\nStart Date:&nbsp;<strong>{start_date}</strong><br />\r\nEnd Date:&nbsp;<strong>{End_date}</strong><br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (39, 'goal_achieve', 'Achieve Goal', '<p><strong>Congratulation!</strong> We achieved new goal.</p>\r\n\r\n<p><strong>Here is a Goal Details</strong></p>\r\n\r\n<p>Goal Type :<strong>{Goal_Type}</strong><br />\r\nTarget Achievement:<strong>{achievement}</strong><br />\r\nTotal Achievement:<strong>{total_achievement}</strong><br />\r\nStart Date:<strong>{start_date}</strong><br />\r\nEnd Date:<strong>{End_date}</strong><br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (40, 'leave_request_email', 'A Leave Request from you', '<p>Hi there,</p>\r\n\r\n<p><strong>{NAME}</strong> &nbsp;Want to leave from you.</p>\r\n\r\n<p>You can view this leave request by logging in to the portal using the link below<br />\r\n<big><strong><a href=\"{APPLICATION_LINK}\">View Application</a></strong></big><br />\r\n<br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (41, 'leave_approve_email', 'Your leave request has been approved', '<h1>Your leave request has been approved</h1>\r\n\r\n<p><strong>Congratulations!</strong> Your leave request from <strong>{START_DATE}</strong> to <strong>{END_DATE}</strong> has been approved by your company management.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (42, 'leave_reject_email', 'Your leave request has been Rejected', '<h1>Your leave request has been Rejected</h1>\r\n\r\n<p><strong>Unfortunately !</strong>&nbsp;Your leave request from&nbsp;<strong>{START_DATE}</strong>&nbsp;to&nbsp;<strong>{END_DATE}</strong>&nbsp;has been Rejected by your company management.</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (43, 'overtime_request_email', 'Overtime Request', '<p>Hi there,</p>\r\n\r\n<p><strong>{NAME}</strong>&nbsp;&nbsp;to do an overtime.<br />\r\n<br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (44, 'overtime_approved_email', 'Your overtime request has been approved', '<h1>Your leave request has been approved</h1>\r\n\r\n<p><strong>Congratulations!</strong>&nbsp;Your overtime&nbsp;request at&nbsp;<strong>{DATE}</strong>&nbsp;and&nbsp;<strong>{HOUR}</strong>&nbsp;has been approved by your company management.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (45, 'overtime_reject_email', 'Your Overtime request has been Rejected', '<h1>Your leave request has been Rejected</h1>\r\n\r\n<p><strong>Unfortunately&nbsp;!</strong>&nbsp;Your overtime&nbsp;request at&nbsp;<strong>{DATE}</strong>&nbsp;and&nbsp;<strong>{HOUR}</strong>&nbsp;has been Rejected by your company management.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (46, 'wellcome_email', 'Welcome Email ', '<p>Hello <strong>{NAME}</strong>,</p>\r\n\r\n<p>Welcome to <strong>{COMPANY_NAME}</strong> .Thanks for joining <strong>{COMPANY_NAME}</strong>.</p>\r\n\r\n<p>We just wanted to say welcome.</p>\r\n\r\n<p>Please contact us if you need any help.</p>\r\n\r\n<p>Click here to view your profile: <strong>{COMPANY_URL}</strong></p>\r\n\r\n<p><br />\r\nHave fun!<br />\r\nThe <strong>{COMPANY_NAME}</strong> Team.</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (47, 'payslip_generated_email', 'Payslip generated', '<p>Hello&nbsp;<strong>{NAME}</strong>,</p>\r\n\r\n<p>Your payslip generated for the month <strong>{MONTH_YEAR} .</strong></p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (48, 'advance_salary_email', 'Advance Salary Reqeust', '<p>Hi there,</p>\r\n\r\n<p><strong>{NAME}</strong>&nbsp;&nbsp;Want to Advance Salary from you.</p>\r\n\r\n<p>You can view this Advance Salary by logging in to the portal using the link below.<br />\r\n<br />\r\n<big><strong><a href=\"{LINK}\">View Advance Salary</a></strong></big><br />\r\n<br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (49, 'advance_salary_approve_email', 'Your advance salary request has been approved', '<h1>Your advance salary request has been approved</h1>\r\n\r\n<p><strong>Congratulations!</strong>&nbsp;Your advance salary&nbsp;requested &nbsp;<strong>{AMOUNT}</strong>&nbsp;has been approved by your company management.</p>\r\n\r\n<p>This advance amount will deduct the next <strong>{DEDUCT_MOTNH}</strong> .</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (50, 'advance_salary_reject_email', 'Your advance salary request has been Rejected', '<h1>Your advance salary request has been Rejected</h1>\r\n\r\n<p><strong>Unfortunately !</strong>&nbsp;Your advance salary requested&nbsp;<strong>{AMOUNT}</strong>&nbsp;has been Rejected by your company management.</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (51, 'award_email', 'Award Received', '<p>Hello&nbsp;<strong>{NAME}</strong>,</p>\r\n\r\n<p>You have been&nbsp;awarded <strong>{AWARD_NAME} </strong>for this<strong> {MONTH} .</strong></p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (52, 'new_job_application_email', 'New job application submitted', '<p>Hi there,</p>\r\n\r\n<p>&nbsp;<strong>{NAME}&nbsp;</strong>has submitted the job application</p>\r\n\r\n<p>Please find below are job application Details:</p>\r\n\r\n<table cellpadding=\"8\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Job Title</td>\r\n			<td><strong>{JOB_TITLE}</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Email</td>\r\n			<td><strong>{EMAIL}</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Mobile</td>\r\n			<td><strong>{MOBILE}</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Cover Latter</td>\r\n			<td><strong>{COVER_LETTER}</strong></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><br />\r\nYou can view the Job Application online at:<br />\r\n<br />\r\n<big><strong><a href=\"{LINK}\">View Job Application</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (53, 'new_notice_published', 'New Notice published', '<p>Hello&nbsp;<strong>{NAME}</strong>,</p>\r\n\r\n<p>New Notice Published&nbsp;<strong>{TITLE}</strong></p>\r\n\r\n<p><br />\r\nYou can view the Notice online at:<br />\r\n<br />\r\n<big><strong><a href=\"{LINK}\">View Notice</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (54, 'new_training_email', 'Training  Assigned ', '<p>Hi there,</p>\r\n\r\n<p>A new Training  &nbsp;<strong>{TRAINING_NAME}</strong>&nbsp;&nbsp;has been assigned to you by&nbsp;<strong>{ASSIGNED_BY}</strong>.</p>\r\n\r\n<p>You can view this Training  by logging in to the portal using the link below.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{LINK}\">View Training</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (55, 'performance_appraisal_email', 'New Performance Appraisal', '');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (56, 'expense_request_email', 'A New Expense Request have been Recieved', '<p>Hi there,</p>\r\n\r\n<p><strong>{NAME}</strong> &nbsp;Create a New Expense The Amount is <strong>{AMOUNT}</strong></p>\r\n\r\n<p>You can view this expense by logging in to the portal using the link below.<br />\r\n<br />\r\n<big><strong><a href=\"{URL}\">View Expense</a></strong></big><br />\r\n<br />\r\n<br />\r\nRegards,<br />\r\n<br />\r\nThe <strong>{SITE_NAME}</strong> Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (57, 'expense_approved_email', 'Expense Approved', '<p>Dear&nbsp;<strong>{NAME} ,</strong></p>\r\n\r\n<h1>Your Expense request has been approved</h1>\r\n\r\n<p><strong>Congratulations!</strong>&nbsp;Your Expense request from&nbsp;<strong>{AMOUNT}</strong>&nbsp;has been approved by your company management.</p>\r\n\r\n<p>Please Contact&nbsp;with our Accountant for collect the amount.</p>\r\n\r\n<p><br />\r\nRegards,<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (58, 'expense_paid_email', 'Expense have been Paid', '<p>Hi there,</p>\r\n\r\n<p>The&nbsp;<strong>{NAME}</strong>&nbsp;expense&nbsp;<strong>{AMOUNT}&nbsp;</strong>has been paid by <strong>{PAID_BY}.</strong></p>\r\n\r\n<p>You can view this expense by logging in to the portal using the link below.<br />\r\n<br />\r\n<big><strong><a href=\"{URL}\">View Expense</a></strong></big><br />\r\n<br />\r\n<br />\r\nRegards,<br />\r\n<br />\r\nThe&nbsp;<strong>{SITE_NAME}</strong>&nbsp;Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (59, 'auto_close_ticket', 'Ticket Auto Closed', '<p>Ticket Closed</p>\r\n\r\n<p>Hello <strong>{REPORTER_EMAIL}</strong>,</p>\r\n\r\n<p>Ticket&nbsp;<strong>{SUBJECT}</strong>&nbsp;has been auto closed due to inactivity.&nbsp;<br />\r\n<br />\r\nTicket # <strong>{TICKET_CODE}</strong><br />\r\nStatus : &nbsp;<strong>{TICKET_STATUS}</strong><br />\r\n<br />\r\nTo see the responses or open the ticket, click on the link below:ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹<br />\r\n<br />\r\n<big><strong><a href=\"{TICKET_LINK}\">View Ticket</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe <strong>{SITE_NAME}</strong> Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (60, 'proposal_email', 'New Proposal', '<p>Proposal <strong>{PROPOSAL_REF}</strong></p> <p>Hi <strong>{CLIENT}</strong></p> <p>Thanks for your business inquiry.</p> <p>The Proposal <strong>{PROPOSAL_REF} </strong>is attached with this email.<br /> Proposal&nbsp;Overview:<br /> Proposal&nbsp;# :<strong> {PROPOSAL_REF}</strong><br /> Amount: <strong>{CURRENCY} {AMOUNT}</strong><br /> <br /> You can view the estimate online at:<br /> <big><strong><a href=\"{PROPOSAL_LINK}\">View Proposal</a></strong></big><br /> <br /> Best Regards,<br /> The <strong>{SITE_NAME}</strong> Team</p> ');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (61, 'project_overdue_email', 'Project Overdue Notice', '<p>Project Overdue</p>\r\n\r\n<p><strong>Hello {CLIENT}</strong></p>\r\n\r\n<p>This is the notice that your project overdue.&nbsp;<br />\r\n<br />\r\nProject name : <strong>{PROJECT_NAME}</strong><br />\r\nDue date : <strong>{DUE_DATE}</strong><br />\r\nYou can login to see the status of your project by using this link:<br />\r\n<big><a href=\"{PROJECT_LINK}\"><strong>View Project</strong></a></big></p>\r\n\r\n<p><br />\r\nBest Regards<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (62, 'estimate_overdue_email', 'Estimate Overdue Notice', '<p>Estimate {ESTIMATE_REF}</p>\r\n\r\n<p>Hi {CLIENT}</p>\r\n\r\n<p>This is the notice that your Estimate&nbsp;overdue.&nbsp;ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â¹<br />\r\n<br />\r\nEstimate Overview:<br />\r\nEstimate # : {ESTIMATE_REF}<br />\r\nAmount: {DUE_DATE}<br />\r\nAmount: {CURRENCY} {AMOUNT}<br />\r\n<br />\r\nYou can view the estimate online at:<br />\r\n<big><strong><a href=\"{ESTIMATE_LINK}\">View Estimate</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (63, 'proposal_overdue_email', 'New Estimate', '<p>Proposal&nbsp;<strong>{PROPOSAL_REF}</strong></p>\r\n\r\n<p>Hi&nbsp;<strong>{CLIENT}</strong></p>\r\n\r\n<p>This is the notice that your Proposal&nbsp;overdue.&nbsp;<br />\r\n<br />\r\nProposal&nbsp;Overview:<br />\r\nProposal&nbsp;# :<strong>&nbsp;{PROPOSAL_REF}</strong><br />\r\nDue Date: <strong>{DUE_DATE}</strong>ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â¹<br />\r\nAmount:&nbsp;<strong>{CURRENCY} {AMOUNT}</strong><br />\r\n<br />\r\nYou can view the estimate online at:<br />\r\n<big><strong><a href=\"{PROPOSAL_LINK}\">View Proposal</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe&nbsp;<strong>{SITE_NAME}</strong>&nbsp;Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (64, 'call_for_interview', 'You have an interview offer!!!', '<p>Hello&nbsp;<strong>{NAME}</strong>,</p>\r\n\r\n<p>You have an interview offer for you.please see the details.&nbsp;<br />\r\n<br />\r\n<strong>Job Summary</strong>:<br />\r\nJob Title # :<strong>&nbsp;{JOB_TITLE}</strong><br />\r\nDesignation # :<strong>&nbsp;{DESIGNATION}</strong><br />\r\nInterview Date: <strong>{DATE}</strong></p>\r\n\r\n<p><strong>Postal Address</strong><br />\r\nPO Box 16122 Collins Street West<br />\r\nVictoria 8007 Australia<br />\r\n121 King Street, Melbourne<br />\r\nVictoria 3000 Australia &ndash;&nbsp;<a href=\"https://www.google.com.au/maps/place/Envato/@-37.8173306,144.9534631,17z/data=!3m1!4b1!4m2!3m1!1s0x6ad65d4c2b349649:0xb6899234e561db11\" target=\"_blank\">Map</a></p>\r\n\r\n<p><br />\r\nYou can view the circular details online at:<br />\r\n<big><strong><a href=\"{LINK}\">View Job Circular</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe&nbsp;<strong>{SITE_NAME}</strong>&nbsp;Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (65, 'ticket_reopened_email', 'Ticket [SUBJECT] reopened', '<p>Ticket re-opened</p>\r\n\r\n<p>Hi {RECIPIENT},</p>\r\n\r\n<p>Ticket&nbsp;<strong>{SUBJECT}</strong>&nbsp;was re-opened by&nbsp;<strong>{USER}</strong>.<br />\r\nStatus :&nbsp;Open<br />\r\nClick on the below link to see the ticket details and post replies:&nbsp;<br />\r\n<a href=\"{TICKET_LINK}\"><strong>View Ticket</strong></a><br />\r\n<br />\r\n<br />\r\nBest Regards,<br />\r\n{SITE_NAME}</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (66, 'deposit_email', 'A deposit have been Received', '<p>Hi there,</p> <p>The&nbsp;<strong>{NAME}</strong>&nbsp;of deposit&nbsp;<strong>{AMOUNT}&nbsp;</strong>has been Deposit into <strong>{ACCOUNT}</strong> the new balance is <strong>{BALANCE}</strong></p> <p>You can view this deposit by logging in to the portal using the link below.<br /> <br /> <big><strong><a href=\"{URL}\">View Deposit</a></strong></big><br /> <br /> <br /> Regards,<br /> <br /> The&nbsp;<strong>{SITE_NAME}</strong>&nbsp;Team</p>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (67, 'clock_in_email', 'The {NAME} Just clock in', '<p>Hi there,</p>\r\n\r\n<p>TheÂ <strong>{NAME}</strong> justÂ Clock In by using The IP. The IP is:Â <strong>{IP}</strong> and the time is: Â <strong>{TIME}</strong><strong> </strong></p>\r\n\r\n<p>You can view this attendance by logging in to the portal using the link below.<br>\r\n<br>\r\n<big><strong><a href=\"{URL}\">View Details</a></strong></big><br>\r\n<br>\r\n<br>\r\nRegards,<br>\r\n<br>\r\nTheÂ <strong>{SITE_NAME}</strong>Â Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (68, 'trying_clock_email', 'The {NAME} Trying to clock', '<p>Hi there,</p>\r\n\r\n<p>TheÂ <strong>{NAME} </strong> Trying to clockÂ in by Unknown IP.The IP is: <strong>{IP}</strong> and the time is: <strong>{TIME}</strong></p>\r\n\r\n<p>You can view this IP by logging in to the portal using the link below.<br>\r\n<br>\r\n<big><strong><a href=\"{URL}\">View Details</a></strong></big><br>\r\n<br>\r\n<br>\r\nRegards,<br>\r\n<br>\r\nTheÂ <strong>{SITE_NAME}</strong>Â Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (69, 'clock_out_email', 'The {NAME} Just clock Out', '<p>Hi there,</p>\r\n\r\n<p>TheÂ <strong>{NAME}</strong>Â justÂ Clock Out by using The IP. The IP is:Â <strong>{IP}</strong>Â and the time is: Â <strong>{TIME}</strong></p>\r\n\r\n<p>You can view this attendance by logging in to the portal using the link below.<br>\r\n<br>\r\n<big><strong><a href=\"{URL}\">View Details</a></strong></big><br>\r\n<br>\r\n<br>\r\nRegards,<br>\r\n<br>\r\nTheÂ <strong>{SITE_NAME}</strong>Â Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (70, 'proposal_email', 'New Proposal', '<p>Proposal <strong>{PROPOSAL_REF}</strong></p> <p>Hi <strong>{CLIENT}</strong></p> <p>Thanks for your business inquiry.</p> <p>The Proposal <strong>{PROPOSAL_REF} </strong>is attached with this email.<br /> Proposal&nbsp;Overview:<br /> Proposal&nbsp;# :<strong> {PROPOSAL_REF}</strong><br /> Amount: <strong>{CURRENCY} {AMOUNT}</strong><br /> <br /> You can view the estimate online at:<br /> <big><strong><a href=\"{PROPOSAL_LINK}\">View Proposal</a></strong></big><br /> <br /> Best Regards,<br /> The <strong>{SITE_NAME}</strong> Team</p> ');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (71, 'call_for_interview', 'You have an interview offer!!!', '<p>Hello&nbsp;<strong>{NAME}</strong>,</p> <p>You have an interview offer for you.please see the details.&nbsp;<br /> <br /> <strong>Job Summary</strong>:<br /> Job Title # :<strong>&nbsp;{JOB_TITLE}</strong><br /> Designation # :<strong>&nbsp;{DESIGNATION}</strong><br /> Interview Date: <strong>{DATE}</strong></p> <p><strong>Postal Address</strong><br /> PO Box 16122 Collins Street West<br /> Victoria 8007 Australia<br /> 121 King Street, Melbourne<br /> Victoria 3000 Australia &ndash;&nbsp;<a href=\"https://www.google.com.au/maps/place/Envato/@-37.8173306,144.9534631,17z/data=!3m1!4b1!4m2!3m1!1s0x6ad65d4c2b349649:0xb6899234e561db11\" target=\"_blank\">Map</a></p> <p><br /> You can view the circular details online at:<br /> <big><strong><a href=\"{LINK}\">View Job Circular</a></strong></big><br /> <br /> Best Regards,<br /> The&nbsp;<strong>{SITE_NAME}</strong>&nbsp;Team</p> ');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `email_group`, `subject`, `template_body`) VALUES (72, 'ticket_reopened_email', 'Ticket [SUBJECT] reopened', '<p>Ticket re-opened</p> <p>Hi {RECIPIENT},</p> <p>Ticket&nbsp;<strong>{SUBJECT}</strong>&nbsp;was re-opened by&nbsp;<strong>{USER}</strong>.<br /> Status :&nbsp;Open<br /> Click on the below link to see the ticket details and post replies:&nbsp;<br /> <a href=\"{TICKET_LINK}\"><strong>View Ticket</strong></a><br /> <br /> <br /> Best Regards,<br /> {SITE_NAME}</p> ');


#
# TABLE STRUCTURE FOR: tbl_employee_award
#

DROP TABLE IF EXISTS `tbl_employee_award`;

CREATE TABLE `tbl_employee_award` (
  `employee_award_id` int(11) NOT NULL AUTO_INCREMENT,
  `award_name` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `gift_item` varchar(300) NOT NULL,
  `award_amount` int(5) NOT NULL,
  `award_date` varchar(10) NOT NULL,
  `view_status` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1=Read 2=Unread',
  `given_date` date DEFAULT NULL,
  PRIMARY KEY (`employee_award_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_employee_bank
#

DROP TABLE IF EXISTS `tbl_employee_bank`;

CREATE TABLE `tbl_employee_bank` (
  `employee_bank_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `branch_name` varchar(300) NOT NULL,
  `account_name` varchar(300) NOT NULL,
  `account_number` varchar(300) NOT NULL,
  `routing_number` varchar(50) DEFAULT NULL,
  `type_of_account` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`employee_bank_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_employee_document
#

DROP TABLE IF EXISTS `tbl_employee_document`;

CREATE TABLE `tbl_employee_document` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `resume` text,
  `resume_path` text,
  `resume_filename` text,
  `offer_letter` text,
  `offer_letter_filename` text,
  `offer_letter_path` text,
  `joining_letter` text,
  `joining_letter_filename` text,
  `joining_letter_path` text,
  `contract_paper` text,
  `contract_paper_filename` text,
  `contract_paper_path` text,
  `id_proff` text,
  `id_proff_filename` text,
  `id_proff_path` text,
  `other_document` text,
  PRIMARY KEY (`document_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_employee_payroll
#

DROP TABLE IF EXISTS `tbl_employee_payroll`;

CREATE TABLE `tbl_employee_payroll` (
  `payroll_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `salary_template_id` int(11) DEFAULT NULL,
  `hourly_rate_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`payroll_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_estimate_items
#

DROP TABLE IF EXISTS `tbl_estimate_items`;

CREATE TABLE `tbl_estimate_items` (
  `estimate_items_id` int(11) NOT NULL AUTO_INCREMENT,
  `estimates_id` int(11) NOT NULL,
  `saved_items_id` int(11) DEFAULT '0',
  `item_tax_rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text COLLATE utf8_unicode_ci,
  `item_name` varchar(150) COLLATE utf8_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext COLLATE utf8_unicode_ci,
  `unit_cost` decimal(10,2) DEFAULT '0.00',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `item_tax_total` decimal(10,2) DEFAULT '0.00',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hsn_code` text COLLATE utf8_unicode_ci,
  `order` int(11) DEFAULT '0',
  PRIMARY KEY (`estimate_items_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_estimates
#

DROP TABLE IF EXISTS `tbl_estimates`;

CREATE TABLE `tbl_estimates` (
  `estimates_id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT '0',
  `estimate_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estimate_month` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estimate_year` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `due_date` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alert_overdue` tinyint(1) NOT NULL DEFAULT '0',
  `currency` varchar(32) COLLATE utf8_unicode_ci DEFAULT 'USD',
  `discount_percent` int(2) DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `tax` int(11) NOT NULL DEFAULT '0',
  `total_tax` text COLLATE utf8_unicode_ci,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Pending',
  `date_sent` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `est_deleted` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `emailed` enum('Yes','No') COLLATE utf8_unicode_ci DEFAULT 'No',
  `show_client` enum('Yes','No') COLLATE utf8_unicode_ci DEFAULT 'No',
  `invoiced` enum('Yes','No') COLLATE utf8_unicode_ci DEFAULT 'No',
  `invoices_id` int(11) NOT NULL DEFAULT '0',
  `permission` text COLLATE utf8_unicode_ci,
  `client_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `discount_type` enum('before_tax','after_tax') COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT 'sales agent',
  `adjustment` decimal(18,2) NOT NULL DEFAULT '0.00',
  `discount_total` decimal(18,2) NOT NULL DEFAULT '0.00',
  `show_quantity_as` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`estimates_id`),
  UNIQUE KEY `reference_no` (`reference_no`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_expense_category
#

DROP TABLE IF EXISTS `tbl_expense_category`;

CREATE TABLE `tbl_expense_category` (
  `expense_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_category` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`expense_category_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_files
#

DROP TABLE IF EXISTS `tbl_files`;

CREATE TABLE `tbl_files` (
  `files_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `uploaded_by` int(11) NOT NULL,
  `date_posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`files_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_form
#

DROP TABLE IF EXISTS `tbl_form`;

CREATE TABLE `tbl_form` (
  `form_id` int(11) NOT NULL AUTO_INCREMENT,
  `form_name` varchar(100) CHARACTER SET latin1 NOT NULL,
  `tbl_name` varchar(25) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`form_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`) VALUES (1, 'proposal', 'tbl_proposals');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`) VALUES (2, 'client', 'tbl_client');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`) VALUES (3, 'users', 'tbl_account_details');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`) VALUES (4, 'recruitment', 'tbl_job_circular');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`) VALUES (5, 'training', 'tbl_training');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`) VALUES (6, 'announcements', 'tbl_announcements');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`) VALUES (7, 'leave_management', 'tbl_leave_application');


#
# TABLE STRUCTURE FOR: tbl_goal_tracking
#

DROP TABLE IF EXISTS `tbl_goal_tracking`;

CREATE TABLE `tbl_goal_tracking` (
  `goal_tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL,
  `goal_type_id` int(11) NOT NULL,
  `achievement` int(10) NOT NULL,
  `start_date` varchar(20) NOT NULL,
  `end_date` varchar(20) NOT NULL,
  `account_id` int(11) DEFAULT '0',
  `description` mediumtext NOT NULL,
  `notify_goal_achive` varchar(5) DEFAULT NULL,
  `notify_goal_not_achive` varchar(5) DEFAULT NULL,
  `permission` mediumtext,
  `email_send` varchar(5) NOT NULL DEFAULT 'no',
  PRIMARY KEY (`goal_tracking_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_goal_type
#

DROP TABLE IF EXISTS `tbl_goal_type`;

CREATE TABLE `tbl_goal_type` (
  `goal_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) NOT NULL,
  `description` mediumtext NOT NULL,
  `tbl_name` varchar(200) NOT NULL,
  `query` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`goal_type_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_holiday
#

DROP TABLE IF EXISTS `tbl_holiday`;

CREATE TABLE `tbl_holiday` (
  `holiday_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `location` varchar(200) DEFAULT NULL,
  `color` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`holiday_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_hourly_rate
#

DROP TABLE IF EXISTS `tbl_hourly_rate`;

CREATE TABLE `tbl_hourly_rate` (
  `hourly_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `hourly_grade` varchar(200) NOT NULL,
  `hourly_rate` varchar(50) NOT NULL,
  PRIMARY KEY (`hourly_rate_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_inbox
#

DROP TABLE IF EXISTS `tbl_inbox`;

CREATE TABLE `tbl_inbox` (
  `inbox_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `to` varchar(100) NOT NULL,
  `from` varchar(100) NOT NULL,
  `subject` varchar(300) NOT NULL,
  `message_body` text NOT NULL,
  `attach_file` text,
  `attach_file_path` text,
  `attach_filename` text,
  `message_time` datetime NOT NULL,
  `view_status` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1=Read 2=Unread',
  `favourites` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0= no 1=yes',
  `notify_me` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=on 0=off',
  `deleted` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`inbox_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_income_category
#

DROP TABLE IF EXISTS `tbl_income_category`;

CREATE TABLE `tbl_income_category` (
  `income_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `income_category` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`income_category_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_invoices
#

DROP TABLE IF EXISTS `tbl_invoices`;

CREATE TABLE `tbl_invoices` (
  `invoices_id` int(11) NOT NULL AUTO_INCREMENT,
  `recur_start_date` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `recur_end_date` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `reference_no` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `invoice_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invoice_month` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invoice_year` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `due_date` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alert_overdue` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  `tax` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_tax` text COLLATE utf8_unicode_ci,
  `discount_percent` int(2) DEFAULT NULL,
  `recurring` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `recuring_frequency` int(11) NOT NULL DEFAULT '31',
  `recur_frequency` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recur_next_date` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'USD',
  `status` enum('Cancelled','Unpaid','Paid','draft','partially_paid') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Unpaid',
  `archived` int(11) DEFAULT '0',
  `date_sent` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inv_deleted` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `emailed` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `show_client` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Yes',
  `viewed` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `allow_paypal` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Yes',
  `allow_stripe` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Yes',
  `allow_2checkout` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Yes',
  `allow_authorize` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `allow_ccavenue` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `allow_braintree` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `allow_mollie` enum('Yes','No') COLLATE utf8_unicode_ci DEFAULT 'No',
  `allow_payumoney` enum('Yes','No') COLLATE utf8_unicode_ci DEFAULT 'No',
  `allow_razorpay` enum('Yes','No') COLLATE utf8_unicode_ci DEFAULT 'No',
  `permission` text COLLATE utf8_unicode_ci,
  `client_visible` enum('Yes','No') COLLATE utf8_unicode_ci DEFAULT 'No',
  `discount_type` enum('before_tax','after_tax') COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT 'sales agent',
  `adjustment` decimal(18,2) NOT NULL DEFAULT '0.00',
  `discount_total` decimal(18,2) NOT NULL DEFAULT '0.00',
  `show_quantity_as` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`invoices_id`),
  UNIQUE KEY `reference_no` (`reference_no`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_item_history
#

DROP TABLE IF EXISTS `tbl_item_history`;

CREATE TABLE `tbl_item_history` (
  `item_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` int(11) NOT NULL,
  `inventory` int(5) NOT NULL,
  `purchase_date` date NOT NULL,
  PRIMARY KEY (`item_history_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_items
#

DROP TABLE IF EXISTS `tbl_items`;

CREATE TABLE `tbl_items` (
  `items_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoices_id` int(11) NOT NULL,
  `item_tax_rate` decimal(18,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text COLLATE utf8_unicode_ci,
  `item_tax_total` decimal(18,2) NOT NULL DEFAULT '0.00',
  `quantity` decimal(18,2) DEFAULT '0.00',
  `total_cost` decimal(18,2) DEFAULT '0.00',
  `item_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext COLLATE utf8_unicode_ci,
  `unit_cost` decimal(18,2) DEFAULT '0.00',
  `order` int(11) DEFAULT '0',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hsn_code` text COLLATE utf8_unicode_ci,
  `saved_items_id` int(11) DEFAULT '0',
  PRIMARY KEY (`items_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_items` (`items_id`, `invoices_id`, `item_tax_rate`, `item_tax_name`, `item_tax_total`, `quantity`, `total_cost`, `item_name`, `item_desc`, `unit_cost`, `order`, `date_saved`, `unit`, `hsn_code`, `saved_items_id`) VALUES (1, 1, '0.00', NULL, '0.00', '2.00', '6000.00', 'سلم قفز', 'عرض ٦٠ سم\nطول ١٢٠ سم\nارتفاع ٢٠ سم\nعدد المقومات ٣', '3000.00', 0, '2020-02-11 11:14:32', 'Pc', '', 0);


#
# TABLE STRUCTURE FOR: tbl_job_appliactions
#

DROP TABLE IF EXISTS `tbl_job_appliactions`;

CREATE TABLE `tbl_job_appliactions` (
  `job_appliactions_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_circular_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `cover_letter` text NOT NULL,
  `resume` text NOT NULL,
  `application_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=pending 1=accept 2 = reject',
  `apply_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `send_email` varchar(20) DEFAULT NULL,
  `interview_date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`job_appliactions_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_job_circular
#

DROP TABLE IF EXISTS `tbl_job_circular`;

CREATE TABLE `tbl_job_circular` (
  `job_circular_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_title` varchar(200) NOT NULL,
  `designations_id` int(11) NOT NULL,
  `vacancy_no` varchar(50) NOT NULL,
  `posted_date` date NOT NULL,
  `employment_type` enum('contractual','full_time','part_time') NOT NULL DEFAULT 'full_time',
  `experience` varchar(200) DEFAULT NULL,
  `age` varchar(200) DEFAULT NULL,
  `salary_range` varchar(200) DEFAULT NULL,
  `last_date` date NOT NULL,
  `description` text NOT NULL,
  `status` enum('published','unpublished') NOT NULL DEFAULT 'unpublished' COMMENT '1=publish 2=unpublish',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `permission` text,
  PRIMARY KEY (`job_circular_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_kb_category
#

DROP TABLE IF EXISTS `tbl_kb_category`;

CREATE TABLE `tbl_kb_category` (
  `kb_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(200) NOT NULL,
  `description` longtext,
  `type` varchar(50) NOT NULL,
  `sort` int(2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kb_category_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_knowledgebase
#

DROP TABLE IF EXISTS `tbl_knowledgebase`;

CREATE TABLE `tbl_knowledgebase` (
  `kb_id` int(11) NOT NULL AUTO_INCREMENT,
  `kb_category_id` int(11) NOT NULL,
  `title` text,
  `slug` text,
  `description` text,
  `attachments` text,
  `for_all` enum('Yes','No') DEFAULT 'No',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `total_view` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`kb_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_languages
#

DROP TABLE IF EXISTS `tbl_languages`;

CREATE TABLE `tbl_languages` (
  `code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` int(2) DEFAULT '0',
  PRIMARY KEY (`code`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('ar', 'arabic', 'ae', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('cs', 'czech', 'cs', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('da', 'danish', 'dk', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('de', 'german', 'de', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('el', 'greek', 'gr', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('en', 'english', 'us', 1);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('es', 'spanish', 'es', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('fr', 'french', 'fr', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('gu', 'gujarati', 'in', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('hi', 'hindi', 'in', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('id', 'indonesian', 'id', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('it', 'italian', 'it', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('ja', 'japanese', 'jp', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('nl', 'dutch', 'nl', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('no', 'norwegian', 'no', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('pl', 'polish', 'pl', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('pt', 'portuguese', 'pt', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('ro', 'romanian', 'ro', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('ru', 'russian', 'ru', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('tr', 'turkish', 'tr', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('vi', 'vietnamese', 'vn', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('zh', 'chinese', 'cn', 0);


#
# TABLE STRUCTURE FOR: tbl_lead_source
#

DROP TABLE IF EXISTS `tbl_lead_source`;

CREATE TABLE `tbl_lead_source` (
  `lead_source_id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_source` varchar(100) NOT NULL,
  PRIMARY KEY (`lead_source_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_lead_source` (`lead_source_id`, `lead_source`) VALUES (1, 'Facebook ');


#
# TABLE STRUCTURE FOR: tbl_lead_status
#

DROP TABLE IF EXISTS `tbl_lead_status`;

CREATE TABLE `tbl_lead_status` (
  `lead_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_status` varchar(50) NOT NULL,
  `lead_type` varchar(20) DEFAULT NULL,
  `order_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`lead_status_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_lead_status` (`lead_status_id`, `lead_status`, `lead_type`, `order_no`) VALUES (1, 'hesitant', 'open', 1);
INSERT INTO `tbl_lead_status` (`lead_status_id`, `lead_status`, `lead_type`, `order_no`) VALUES (2, 'Phone Call', '', 2);
INSERT INTO `tbl_lead_status` (`lead_status_id`, `lead_status`, `lead_type`, `order_no`) VALUES (3, 'Call Later', '', 3);


#
# TABLE STRUCTURE FOR: tbl_leads
#

DROP TABLE IF EXISTS `tbl_leads`;

CREATE TABLE `tbl_leads` (
  `leads_id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_name` varchar(50) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `organization` varchar(50) NOT NULL,
  `lead_status_id` int(11) DEFAULT NULL,
  `lead_source_id` int(11) DEFAULT NULL,
  `imported_from_email` tinyint(1) DEFAULT '0',
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `company_name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `contact_name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `mobile` varchar(32) NOT NULL,
  `facebook` varchar(32) NOT NULL,
  `notes` text NOT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `skype` varchar(200) NOT NULL,
  `twitter` varchar(100) NOT NULL,
  `permission` text,
  `converted_client_id` int(11) NOT NULL DEFAULT '0',
  `index_no` int(11) DEFAULT '0',
  PRIMARY KEY (`leads_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_leads` (`leads_id`, `lead_name`, `client_id`, `organization`, `lead_status_id`, `lead_source_id`, `imported_from_email`, `email_integration_uid`, `company_name`, `address`, `country`, `state`, `city`, `contact_name`, `title`, `email`, `phone`, `mobile`, `facebook`, `notes`, `created_time`, `skype`, `twitter`, `permission`, `converted_client_id`, `index_no`) VALUES (1, 'Project Owner', NULL, '', 1, 1, 0, NULL, '', '', 'Egypt', 'Zagazeg', 'El-sharkaya', 'Eslam loay', '', 'Eslamloay95@gmail.com', '01064408890', '01207291867', 'https://www.facebook.com/eslamel', '<p> He ask about used equipment </p><p>5 EQUIPMENTS </p>', '2020-01-22 03:20:03', '', '', 'all', 53, 1);
INSERT INTO `tbl_leads` (`leads_id`, `lead_name`, `client_id`, `organization`, `lead_status_id`, `lead_source_id`, `imported_from_email`, `email_integration_uid`, `company_name`, `address`, `country`, `state`, `city`, `contact_name`, `title`, `email`, `phone`, `mobile`, `facebook`, `notes`, `created_time`, `skype`, `twitter`, `permission`, `converted_client_id`, `index_no`) VALUES (3, 'mohaad', NULL, 'raam', 1, 1, 0, NULL, '', '', 'Egypt', '', '', '', '', '', '', '', '', '', '2020-02-25 20:34:19', '', '', 'all', 77, 3);
INSERT INTO `tbl_leads` (`leads_id`, `lead_name`, `client_id`, `organization`, `lead_status_id`, `lead_source_id`, `imported_from_email`, `email_integration_uid`, `company_name`, `address`, `country`, `state`, `city`, `contact_name`, `title`, `email`, `phone`, `mobile`, `facebook`, `notes`, `created_time`, `skype`, `twitter`, `permission`, `converted_client_id`, `index_no`) VALUES (4, 'DINA WAGEEH', NULL, '', 1, 1, 0, NULL, '', '', 'Egypt', '', 'CAIRO', 'DINA WAGEEH', '', '', '01099111201', '01099111201', '', '', '2020-02-27 16:14:03', '', '', '{\"7\":[\"view\"],\"11\":[\"view\"]}', 0, 4);
INSERT INTO `tbl_leads` (`leads_id`, `lead_name`, `client_id`, `organization`, `lead_status_id`, `lead_source_id`, `imported_from_email`, `email_integration_uid`, `company_name`, `address`, `country`, `state`, `city`, `contact_name`, `title`, `email`, `phone`, `mobile`, `facebook`, `notes`, `created_time`, `skype`, `twitter`, `permission`, `converted_client_id`, `index_no`) VALUES (5, 'ALAM EL RYADA', NULL, '', 1, 1, 0, NULL, '', '', 'Egypt', '', 'CAIRO', 'DR. HESHAM EL NADY', '', '', '01223818350', '01001435836', '', '', '2020-03-08 16:23:15', '', '', 'all', 0, 5);
INSERT INTO `tbl_leads` (`leads_id`, `lead_name`, `client_id`, `organization`, `lead_status_id`, `lead_source_id`, `imported_from_email`, `email_integration_uid`, `company_name`, `address`, `country`, `state`, `city`, `contact_name`, `title`, `email`, `phone`, `mobile`, `facebook`, `notes`, `created_time`, `skype`, `twitter`, `permission`, `converted_client_id`, `index_no`) VALUES (6, 'IMAN SOBHY', NULL, '', 1, 1, 0, NULL, '', '', 'Egypt', '', 'DAMANHOUR', 'IMAN SOBHY', '', '', '01002939190', '01002939190', '', '', '2020-03-08 16:26:22', '', '', 'all', 0, 6);
INSERT INTO `tbl_leads` (`leads_id`, `lead_name`, `client_id`, `organization`, `lead_status_id`, `lead_source_id`, `imported_from_email`, `email_integration_uid`, `company_name`, `address`, `country`, `state`, `city`, `contact_name`, `title`, `email`, `phone`, `mobile`, `facebook`, `notes`, `created_time`, `skype`, `twitter`, `permission`, `converted_client_id`, `index_no`) VALUES (7, 'MOHAMED KESHK', NULL, '', 1, 1, 0, NULL, '', '', 'Egypt', '', 'MANSOURA', 'MOHAMED KESHK', '', '', '01063334419', '01063334419', '', '', '2020-03-08 16:28:03', '', '', 'all', 0, 7);
INSERT INTO `tbl_leads` (`leads_id`, `lead_name`, `client_id`, `organization`, `lead_status_id`, `lead_source_id`, `imported_from_email`, `email_integration_uid`, `company_name`, `address`, `country`, `state`, `city`, `contact_name`, `title`, `email`, `phone`, `mobile`, `facebook`, `notes`, `created_time`, `skype`, `twitter`, `permission`, `converted_client_id`, `index_no`) VALUES (8, 'MOHAMED ABD ALLAH', NULL, 'BITASH CLUB', 1, 1, 0, NULL, '', '', 'Egypt', '', '', 'MOHAMED ABD ALLAH', '', '', '01289479756', '01289479756', '', '', '2020-03-08 16:30:03', '', '', 'all', 0, 8);
INSERT INTO `tbl_leads` (`leads_id`, `lead_name`, `client_id`, `organization`, `lead_status_id`, `lead_source_id`, `imported_from_email`, `email_integration_uid`, `company_name`, `address`, `country`, `state`, `city`, `contact_name`, `title`, `email`, `phone`, `mobile`, `facebook`, `notes`, `created_time`, `skype`, `twitter`, `permission`, `converted_client_id`, `index_no`) VALUES (9, 'SHOOTING CLUB KHATAMYA', NULL, 'SHOOTING CLUB KHATAMYA', 1, 1, 0, NULL, '', '', 'Egypt', '', 'CAIRO', 'DR. AHMED FARAG ALLAH', '', '', '01005246119', '01005246119', '', '', '2020-03-08 16:32:40', '', '', 'all', 0, 9);


#
# TABLE STRUCTURE FOR: tbl_leave_application
#

DROP TABLE IF EXISTS `tbl_leave_application`;

CREATE TABLE `tbl_leave_application` (
  `leave_application_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `leave_category_id` int(2) NOT NULL,
  `reason` text NOT NULL,
  `leave_type` enum('single_day','multiple_days','hours') NOT NULL DEFAULT 'single_day',
  `hours` varchar(20) DEFAULT NULL,
  `leave_start_date` date NOT NULL,
  `leave_end_date` date DEFAULT NULL,
  `application_status` int(2) NOT NULL DEFAULT '1' COMMENT '1=pending,2=accepted 3=rejected',
  `view_status` tinyint(1) NOT NULL DEFAULT '2',
  `application_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `attachment` text,
  `comments` text,
  `approve_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`leave_application_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_leave_category
#

DROP TABLE IF EXISTS `tbl_leave_category`;

CREATE TABLE `tbl_leave_category` (
  `leave_category_id` int(2) NOT NULL AUTO_INCREMENT,
  `leave_category` varchar(100) NOT NULL,
  `leave_quota` int(2) NOT NULL,
  PRIMARY KEY (`leave_category_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_locales
#

DROP TABLE IF EXISTS `tbl_locales`;

CREATE TABLE `tbl_locales` (
  `locale` varchar(10) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `name` varchar(250) NOT NULL DEFAULT '',
  `icon` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`locale`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('aa_DJ', 'aa', 'afar', 'Afar (Djibouti)', 'dj');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('aa_ER', 'aa', 'afar', 'Afar (Eritrea)', 'dj');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('aa_ET', 'aa', 'afar', 'Afar (Ethiopia)', 'dj');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('af_ZA', 'af', 'afrikaans', 'Afrikaans (South Africa)', 'za');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('am_ET', 'am', 'amharic', 'Amharic (Ethiopia)', 'et');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('an_ES', 'an', 'aragonese', 'Aragonese (Spain)', 'es');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_AE', 'ar', 'arabic', 'Arabic (United Arab Emirates)', 'es');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_BH', 'ar', 'arabic', 'Arabic (Bahrain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_DZ', 'ar', 'arabic', 'Arabic (Algeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_EG', 'ar', 'arabic', 'Arabic (Egypt)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_IN', 'ar', 'arabic', 'Arabic (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_IQ', 'ar', 'arabic', 'Arabic (Iraq)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_JO', 'ar', 'arabic', 'Arabic (Jordan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_KW', 'ar', 'arabic', 'Arabic (Kuwait)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_LB', 'ar', 'arabic', 'Arabic (Lebanon)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_LY', 'ar', 'arabic', 'Arabic (Libya)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_MA', 'ar', 'arabic', 'Arabic (Morocco)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_OM', 'ar', 'arabic', 'Arabic (Oman)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_QA', 'ar', 'arabic', 'Arabic (Qatar)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_SA', 'ar', 'arabic', 'Arabic (Saudi Arabia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_SD', 'ar', 'arabic', 'Arabic (Sudan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_SY', 'ar', 'arabic', 'Arabic (Syria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_TN', 'ar', 'arabic', 'Arabic (Tunisia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_YE', 'ar', 'arabic', 'Arabic (Yemen)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ast_ES', 'ast', 'asturian', 'Asturian (Spain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('as_IN', 'as', 'assamese', 'Assamese (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('az_AZ', 'az', 'azerbaijani', 'Azerbaijani (Azerbaijan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('az_TR', 'az', 'azerbaijani', 'Azerbaijani (Turkey)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bem_ZM', 'bem', 'bemba', 'Bemba (Zambia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ber_DZ', 'ber', 'berber', 'Berber (Algeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ber_MA', 'ber', 'berber', 'Berber (Morocco)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('be_BY', 'be', 'belarusian', 'Belarusian (Belarus)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bg_BG', 'bg', 'bulgarian', 'Bulgarian (Bulgaria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bn_BD', 'bn', 'bengali', 'Bengali (Bangladesh)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bn_IN', 'bn', 'bengali', 'Bengali (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bo_CN', 'bo', 'tibetan', 'Tibetan (China)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bo_IN', 'bo', 'tibetan', 'Tibetan (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('br_FR', 'br', 'breton', 'Breton (France)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bs_BA', 'bs', 'bosnian', 'Bosnian (Bosnia and Herzegovina)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('byn_ER', 'byn', 'blin', 'Blin (Eritrea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ca_AD', 'ca', 'catalan', 'Catalan (Andorra)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ca_ES', 'ca', 'catalan', 'Catalan (Spain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ca_FR', 'ca', 'catalan', 'Catalan (France)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ca_IT', 'ca', 'catalan', 'Catalan (Italy)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('crh_UA', 'crh', 'crimean turkish', 'Crimean Turkish (Ukraine)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('csb_PL', 'csb', 'kashubian', 'Kashubian (Poland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('cs_CZ', 'cs', 'czech', 'Czech (Czech Republic)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('cv_RU', 'cv', 'chuvash', 'Chuvash (Russia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('cy_GB', 'cy', 'welsh', 'Welsh (United Kingdom)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('da_DK', 'da', 'danish', 'Danish (Denmark)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_AT', 'de', 'german', 'German (Austria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_BE', 'de', 'german', 'German (Belgium)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_CH', 'de', 'german', 'German (Switzerland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_DE', 'de', 'german', 'German (Germany)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_LI', 'de', 'german', 'German (Liechtenstein)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_LU', 'de', 'german', 'German (Luxembourg)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('dv_MV', 'dv', 'divehi', 'Divehi (Maldives)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('dz_BT', 'dz', 'dzongkha', 'Dzongkha (Bhutan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ee_GH', 'ee', 'ewe', 'Ewe (Ghana)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('el_CY', 'el', 'greek', 'Greek (Cyprus)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('el_GR', 'el', 'greek', 'Greek (Greece)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_AG', 'en', 'english', 'English (Antigua and Barbuda)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_AS', 'en', 'english', 'English (American Samoa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_AU', 'en', 'english', 'English (Australia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_BW', 'en', 'english', 'English (Botswana)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_CA', 'en', 'english', 'English (Canada)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_DK', 'en', 'english', 'English (Denmark)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_GB', 'en', 'english', 'English (United Kingdom)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_GU', 'en', 'english', 'English (Guam)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_HK', 'en', 'english', 'English (Hong Kong SAR China)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_IE', 'en', 'english', 'English (Ireland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_IN', 'en', 'english', 'English (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_JM', 'en', 'english', 'English (Jamaica)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_MH', 'en', 'english', 'English (Marshall Islands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_MP', 'en', 'english', 'English (Northern Mariana Islands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_MU', 'en', 'english', 'English (Mauritius)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_NG', 'en', 'english', 'English (Nigeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_NZ', 'en', 'english', 'English (New Zealand)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_PH', 'en', 'english', 'English (Philippines)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_SG', 'en', 'english', 'English (Singapore)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_TT', 'en', 'english', 'English (Trinidad and Tobago)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_US', 'en', 'english', 'English (United States)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_VI', 'en', 'english', 'English (Virgin Islands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_ZA', 'en', 'english', 'English (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_ZM', 'en', 'english', 'English (Zambia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_ZW', 'en', 'english', 'English (Zimbabwe)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('eo', 'eo', 'esperanto', 'Esperanto', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_AR', 'es', 'spanish', 'Spanish (Argentina)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_BO', 'es', 'spanish', 'Spanish (Bolivia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_CL', 'es', 'spanish', 'Spanish (Chile)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_CO', 'es', 'spanish', 'Spanish (Colombia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_CR', 'es', 'spanish', 'Spanish (Costa Rica)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_DO', 'es', 'spanish', 'Spanish (Dominican Republic)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_EC', 'es', 'spanish', 'Spanish (Ecuador)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_ES', 'es', 'spanish', 'Spanish (Spain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_GT', 'es', 'spanish', 'Spanish (Guatemala)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_HN', 'es', 'spanish', 'Spanish (Honduras)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_MX', 'es', 'spanish', 'Spanish (Mexico)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_NI', 'es', 'spanish', 'Spanish (Nicaragua)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_PA', 'es', 'spanish', 'Spanish (Panama)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_PE', 'es', 'spanish', 'Spanish (Peru)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_PR', 'es', 'spanish', 'Spanish (Puerto Rico)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_PY', 'es', 'spanish', 'Spanish (Paraguay)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_SV', 'es', 'spanish', 'Spanish (El Salvador)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_US', 'es', 'spanish', 'Spanish (United States)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_UY', 'es', 'spanish', 'Spanish (Uruguay)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_VE', 'es', 'spanish', 'Spanish (Venezuela)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('et_EE', 'et', 'estonian', 'Estonian (Estonia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('eu_ES', 'eu', 'basque', 'Basque (Spain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('eu_FR', 'eu', 'basque', 'Basque (France)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fa_AF', 'fa', 'persian', 'Persian (Afghanistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fa_IR', 'fa', 'persian', 'Persian (Iran)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ff_SN', 'ff', 'fulah', 'Fulah (Senegal)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fil_PH', 'fil', 'filipino', 'Filipino (Philippines)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fi_FI', 'fi', 'finnish', 'Finnish (Finland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fo_FO', 'fo', 'faroese', 'Faroese (Faroe Islands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_BE', 'fr', 'french', 'French (Belgium)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_BF', 'fr', 'french', 'French (Burkina Faso)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_BI', 'fr', 'french', 'French (Burundi)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_BJ', 'fr', 'french', 'French (Benin)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_CA', 'fr', 'french', 'French (Canada)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_CF', 'fr', 'french', 'French (Central African Republic)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_CG', 'fr', 'french', 'French (Congo)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_CH', 'fr', 'french', 'French (Switzerland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_CM', 'fr', 'french', 'French (Cameroon)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_FR', 'fr', 'french', 'French (France)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_GA', 'fr', 'french', 'French (Gabon)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_GN', 'fr', 'french', 'French (Guinea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_GP', 'fr', 'french', 'French (Guadeloupe)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_GQ', 'fr', 'french', 'French (Equatorial Guinea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_KM', 'fr', 'french', 'French (Comoros)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_LU', 'fr', 'french', 'French (Luxembourg)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_MC', 'fr', 'french', 'French (Monaco)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_MG', 'fr', 'french', 'French (Madagascar)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_ML', 'fr', 'french', 'French (Mali)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_MQ', 'fr', 'french', 'French (Martinique)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_NE', 'fr', 'french', 'French (Niger)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_SN', 'fr', 'french', 'French (Senegal)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_TD', 'fr', 'french', 'French (Chad)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_TG', 'fr', 'french', 'French (Togo)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fur_IT', 'fur', 'friulian', 'Friulian (Italy)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fy_DE', 'fy', 'western frisian', 'Western Frisian (Germany)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fy_NL', 'fy', 'western frisian', 'Western Frisian (Netherlands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ga_IE', 'ga', 'irish', 'Irish (Ireland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gd_GB', 'gd', 'scottish gaelic', 'Scottish Gaelic (United Kingdom)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gez_ER', 'gez', 'geez', 'Geez (Eritrea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gez_ET', 'gez', 'geez', 'Geez (Ethiopia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gl_ES', 'gl', 'galician', 'Galician (Spain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gu_IN', 'gu', 'gujarati', 'Gujarati (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gv_GB', 'gv', 'manx', 'Manx (United Kingdom)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ha_NG', 'ha', 'hausa', 'Hausa (Nigeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('he_IL', 'he', 'hebrew', 'Hebrew (Israel)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('hi_IN', 'hi', 'hindi', 'Hindi (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('hr_HR', 'hr', 'croatian', 'Croatian (Croatia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('hsb_DE', 'hsb', 'upper sorbian', 'Upper Sorbian (Germany)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ht_HT', 'ht', 'haitian', 'Haitian (Haiti)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('hu_HU', 'hu', 'hungarian', 'Hungarian (Hungary)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('hy_AM', 'hy', 'armenian', 'Armenian (Armenia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ia', 'ia', 'interlingua', 'Interlingua', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('id_ID', 'id', 'indonesian', 'Indonesian (Indonesia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ig_NG', 'ig', 'igbo', 'Igbo (Nigeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ik_CA', 'ik', 'inupiaq', 'Inupiaq (Canada)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('is_IS', 'is', 'icelandic', 'Icelandic (Iceland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('it_CH', 'it', 'italian', 'Italian (Switzerland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('it_IT', 'it', 'italian', 'Italian (Italy)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('iu_CA', 'iu', 'inuktitut', 'Inuktitut (Canada)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ja_JP', 'ja', 'japanese', 'Japanese (Japan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ka_GE', 'ka', 'georgian', 'Georgian (Georgia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('kk_KZ', 'kk', 'kazakh', 'Kazakh (Kazakhstan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('kl_GL', 'kl', 'kalaallisut', 'Kalaallisut (Greenland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('km_KH', 'km', 'khmer', 'Khmer (Cambodia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('kn_IN', 'kn', 'kannada', 'Kannada (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('kok_IN', 'kok', 'konkani', 'Konkani (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ko_KR', 'ko', 'korean', 'Korean (South Korea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ks_IN', 'ks', 'kashmiri', 'Kashmiri (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ku_TR', 'ku', 'kurdish', 'Kurdish (Turkey)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('kw_GB', 'kw', 'cornish', 'Cornish (United Kingdom)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ky_KG', 'ky', 'kirghiz', 'Kirghiz (Kyrgyzstan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('lg_UG', 'lg', 'ganda', 'Ganda (Uganda)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('li_BE', 'li', 'limburgish', 'Limburgish (Belgium)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('li_NL', 'li', 'limburgish', 'Limburgish (Netherlands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('lo_LA', 'lo', 'lao', 'Lao (Laos)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('lt_LT', 'lt', 'lithuanian', 'Lithuanian (Lithuania)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('lv_LV', 'lv', 'latvian', 'Latvian (Latvia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mai_IN', 'mai', 'maithili', 'Maithili (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mg_MG', 'mg', 'malagasy', 'Malagasy (Madagascar)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mi_NZ', 'mi', 'maori', 'Maori (New Zealand)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mk_MK', 'mk', 'macedonian', 'Macedonian (Macedonia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ml_IN', 'ml', 'malayalam', 'Malayalam (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mn_MN', 'mn', 'mongolian', 'Mongolian (Mongolia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mr_IN', 'mr', 'marathi', 'Marathi (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ms_BN', 'ms', 'malay', 'Malay (Brunei)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ms_MY', 'ms', 'malay', 'Malay (Malaysia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mt_MT', 'mt', 'maltese', 'Maltese (Malta)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('my_MM', 'my', 'burmese', 'Burmese (Myanmar)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('naq_NA', 'naq', 'namibia', 'Namibia', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nb_NO', 'nb', 'norwegian bokm?l', 'Norwegian Bokm?l (Norway)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nds_DE', 'nds', 'low german', 'Low German (Germany)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nds_NL', 'nds', 'low german', 'Low German (Netherlands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ne_NP', 'ne', 'nepali', 'Nepali (Nepal)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nl_AW', 'nl', 'dutch', 'Dutch (Aruba)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nl_BE', 'nl', 'dutch', 'Dutch (Belgium)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nl_NL', 'nl', 'dutch', 'Dutch (Netherlands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nn_NO', 'nn', 'norwegian nynorsk', 'Norwegian Nynorsk (Norway)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('no_NO', 'no', 'norwegian', 'Norwegian (Norway)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nr_ZA', 'nr', 'south ndebele', 'South Ndebele (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nso_ZA', 'nso', 'northern sotho', 'Northern Sotho (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('oc_FR', 'oc', 'occitan', 'Occitan (France)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('om_ET', 'om', 'oromo', 'Oromo (Ethiopia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('om_KE', 'om', 'oromo', 'Oromo (Kenya)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('or_IN', 'or', 'oriya', 'Oriya (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('os_RU', 'os', 'ossetic', 'Ossetic (Russia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pap_AN', 'pap', 'papiamento', 'Papiamento (Netherlands Antilles)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pa_IN', 'pa', 'punjabi', 'Punjabi (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pa_PK', 'pa', 'punjabi', 'Punjabi (Pakistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pl_PL', 'pl', 'polish', 'Polish (Poland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ps_AF', 'ps', 'pashto', 'Pashto (Afghanistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pt_BR', 'pt', 'portuguese', 'Portuguese (Brazil)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pt_GW', 'pt', 'portuguese', 'Portuguese (Guinea-Bissau)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pt_PT', 'pt', 'portuguese', 'Portuguese (Portugal)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ro_MD', 'ro', 'romanian', 'Romanian (Moldova)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ro_RO', 'ro', 'romanian', 'Romanian (Romania)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ru_RU', 'ru', 'russian', 'Russian (Russia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ru_UA', 'ru', 'russian', 'Russian (Ukraine)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('rw_RW', 'rw', 'kinyarwanda', 'Kinyarwanda (Rwanda)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sa_IN', 'sa', 'sanskrit', 'Sanskrit (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sc_IT', 'sc', 'sardinian', 'Sardinian (Italy)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sd_IN', 'sd', 'sindhi', 'Sindhi (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('seh_MZ', 'seh', 'sena', 'Sena (Mozambique)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('se_NO', 'se', 'northern sami', 'Northern Sami (Norway)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sid_ET', 'sid', 'sidamo', 'Sidamo (Ethiopia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('si_LK', 'si', 'sinhala', 'Sinhala (Sri Lanka)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sk_SK', 'sk', 'slovak', 'Slovak (Slovakia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sl_SI', 'sl', 'slovenian', 'Slovenian (Slovenia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sn_ZW', 'sn', 'shona', 'Shona (Zimbabwe)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('so_DJ', 'so', 'somali', 'Somali (Djibouti)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('so_ET', 'so', 'somali', 'Somali (Ethiopia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('so_KE', 'so', 'somali', 'Somali (Kenya)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('so_SO', 'so', 'somali', 'Somali (Somalia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sq_AL', 'sq', 'albanian', 'Albanian (Albania)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sq_MK', 'sq', 'albanian', 'Albanian (Macedonia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sr_BA', 'sr', 'serbian', 'Serbian (Bosnia and Herzegovina)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sr_ME', 'sr', 'serbian', 'Serbian (Montenegro)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sr_RS', 'sr', 'serbian', 'Serbian (Serbia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ss_ZA', 'ss', 'swati', 'Swati (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('st_ZA', 'st', 'southern sotho', 'Southern Sotho (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sv_FI', 'sv', 'swedish', 'Swedish (Finland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sv_SE', 'sv', 'swedish', 'Swedish (Sweden)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sw_KE', 'sw', 'swahili', 'Swahili (Kenya)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sw_TZ', 'sw', 'swahili', 'Swahili (Tanzania)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ta_IN', 'ta', 'tamil', 'Tamil (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('teo_UG', 'teo', 'teso', 'Teso (Uganda)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('te_IN', 'te', 'telugu', 'Telugu (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tg_TJ', 'tg', 'tajik', 'Tajik (Tajikistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('th_TH', 'th', 'thai', 'Thai (Thailand)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tig_ER', 'tig', 'tigre', 'Tigre (Eritrea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ti_ER', 'ti', 'tigrinya', 'Tigrinya (Eritrea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ti_ET', 'ti', 'tigrinya', 'Tigrinya (Ethiopia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tk_TM', 'tk', 'turkmen', 'Turkmen (Turkmenistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tl_PH', 'tl', 'tagalog', 'Tagalog (Philippines)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tn_ZA', 'tn', 'tswana', 'Tswana (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('to_TO', 'to', 'tongan', 'Tongan (Tonga)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tr_CY', 'tr', 'turkish', 'Turkish (Cyprus)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tr_TR', 'tr', 'turkish', 'Turkish (Turkey)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ts_ZA', 'ts', 'tsonga', 'Tsonga (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tt_RU', 'tt', 'tatar', 'Tatar (Russia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ug_CN', 'ug', 'uighur', 'Uighur (China)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('uk_UA', 'uk', 'ukrainian', 'Ukrainian (Ukraine)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ur_PK', 'ur', 'urdu', 'Urdu (Pakistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('uz_UZ', 'uz', 'uzbek', 'Uzbek (Uzbekistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ve_ZA', 've', 'venda', 'Venda (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('vi_VN', 'vi', 'vietnamese', 'Vietnamese (Vietnam)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('wa_BE', 'wa', 'walloon', 'Walloon (Belgium)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('wo_SN', 'wo', 'wolof', 'Wolof (Senegal)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('xh_ZA', 'xh', 'xhosa', 'Xhosa (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('yi_US', 'yi', 'yiddish', 'Yiddish (United States)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('yo_NG', 'yo', 'yoruba', 'Yoruba (Nigeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('zh_CN', 'zh', 'chinese', 'Chinese (China)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('zh_HK', 'zh', 'chinese', 'Chinese (Hong Kong SAR China)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('zh_SG', 'zh', 'chinese', 'Chinese (Singapore)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('zh_TW', 'zh', 'chinese', 'Chinese (Taiwan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('zu_ZA', 'zu', 'zulu', 'Zulu (South Africa)', NULL);


#
# TABLE STRUCTURE FOR: tbl_menu
#

DROP TABLE IF EXISTS `tbl_menu`;

CREATE TABLE `tbl_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(1) DEFAULT '1' COMMENT '1= active 0=inactive',
  PRIMARY KEY (`menu_id`)
) /*!50100 TABLESPACE `pcasa_pms` */ ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (1, 'dashboard', 'admin/dashboard', 'fa fa-dashboard', 0, 0, '2017-04-22 04:09:36', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (2, 'calendar', 'admin/calendar', 'fa fa-calendar', 0, 9, '2019-12-01 10:51:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (4, 'client', 'admin/client/manage_client', 'fa fa-users', 12, 3, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (5, 'mailbox', 'admin/mailbox', 'fa fa-envelope-o', 0, 11, '2019-12-01 10:51:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (6, 'tickets', 'admin/tickets', 'fa fa-ticket', 158, 3, '2020-02-20 11:36:22', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (12, 'sales', '#', 'fa fa-shopping-cart', 0, 1, '2019-10-14 14:09:50', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (13, 'invoice', 'admin/invoice/manage_invoice', 'fa fa-circle-o', 29, 1, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (14, 'estimates', 'admin/estimates', 'fa fa-circle-o', 12, 2, '2019-10-03 12:05:36', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (15, 'payments_received', 'admin/invoice/all_payments', 'fa fa-circle-o', 29, 9, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (16, 'tax_rates', 'admin/invoice/tax_rates', 'fa fa-circle-o', 29, 10, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (21, 'quotations', '#', 'fa fa-paste', 12, 6, '2019-10-27 16:09:11', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (22, 'quotations_list', 'admin/quotations', 'fa fa-circle-o', 21, 0, '2019-10-27 16:09:08', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (23, 'quotations_form', 'admin/quotations/quotations_form', 'fa fa-circle-o', 21, 1, '2019-10-27 16:09:06', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (24, 'Employee', 'admin/user/user_list', 'fa fa-users', 156, 0, '2019-10-16 13:56:10', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (25, 'settings', 'admin/settings', 'fa fa-cogs', 0, 12, '2020-02-20 11:37:11', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (26, 'database_backup', 'admin/settings/database_backup', 'fa fa-database', 0, 1, '2019-11-19 14:54:41', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (29, 'Finance', '#', 'fa fa-building-o', 0, 3, '2019-10-16 14:03:34', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (30, 'deposit', 'admin/transactions/deposit', 'fa fa-circle-o', 29, 2, '2020-02-25 13:29:59', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (31, 'expense', 'admin/transactions/expense', 'fa fa-circle-o', 29, 3, '2020-02-25 13:29:59', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (32, 'transfer', 'admin/transactions/transfer', 'fa fa-circle-o', 29, 4, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (33, 'transactions_report', 'admin/transactions/transactions_report', 'fa fa-circle-o', 29, 5, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (34, 'balance_sheet', 'admin/transactions/balance_sheet', 'fa fa-circle-o', 29, 7, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (36, 'bank_cash', 'admin/account/manage_account', 'fa fa-money', 29, 8, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (39, 'items', 'admin/items/items_list', 'fa fa-cube', 150, 0, '2019-05-03 21:19:50', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (42, 'report', '#', 'fa fa-bar-chart', 0, 8, '2019-12-01 10:51:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (43, 'account_statement', 'admin/report/account_statement', 'fa fa-circle-o', 146, 0, '2018-01-06 09:35:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (44, 'income_report', 'admin/report/income_report', 'fa fa-circle-o', 146, 2, '2018-01-06 09:35:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (45, 'expense_report', 'admin/report/expense_report', 'fa fa-circle-o', 146, 1, '2018-01-06 09:35:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (46, 'income_expense', 'admin/report/income_expense', 'fa fa-circle-o', 146, 3, '2018-01-06 09:35:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (47, 'date_wise_report', 'admin/report/date_wise_report', 'fa fa-circle-o', 146, 4, '2018-01-06 09:35:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (48, 'all_income', 'admin/report/all_income', 'fa fa-circle-o', 146, 6, '2018-01-06 09:35:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (49, 'all_expense', 'admin/report/all_expense', 'fa fa-circle-o', 146, 7, '2018-01-06 09:35:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (50, 'all_transaction', 'admin/report/all_transaction', 'fa fa-circle-o', 146, 8, '2018-01-06 09:35:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (51, 'recurring_invoice', 'admin/invoice/recurring_invoice', 'fa fa-circle-o', 12, 3, '2019-10-07 13:08:02', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (52, 'transfer_report', 'admin/transactions/transfer_report', 'fa fa-circle-o', 29, 6, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (53, 'report_by_month', 'admin/report/report_by_month', 'fa fa-circle-o', 146, 5, '2018-01-06 09:35:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (54, 'tasks', 'admin/tasks/all_task', 'fa fa-tasks', 158, 1, '2020-02-20 11:36:22', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (55, 'leads', 'admin/leads', 'fa fa-rocket', 12, 1, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (56, 'opportunities', 'admin/opportunities', 'fa fa-filter', 12, 2, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (57, 'projects', 'admin/projects', 'fa fa-folder-open-o', 158, 0, '2020-02-20 11:36:22', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (58, 'bugs', 'admin/bugs', 'fa fa-bug', 158, 2, '2020-02-20 11:36:22', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (59, 'project', '#', 'fa fa-folder-open-o', 42, 1, '2019-10-14 13:50:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (60, 'tasks_report', 'admin/report/tasks_report', 'fa fa-circle-o', 42, 2, '2019-10-14 13:50:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (61, 'bugs_report', 'admin/report/bugs_report', 'fa fa-circle-o', 42, 3, '2019-10-14 13:50:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (62, 'tickets_report', 'admin/report/tickets_report', 'fa fa-circle-o', 42, 4, '2019-10-14 13:50:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (63, 'client_report', 'admin/report/client_report', 'fa fa-circle-o', 42, 5, '2019-10-14 13:50:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (66, 'tasks_assignment', 'admin/report/tasks_assignment', 'fa fa-dot-circle-o', 59, 0, '2016-05-29 11:25:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (67, 'bugs_assignment', 'admin/report/bugs_assignment', 'fa fa-dot-circle-o', 59, 1, '2016-05-29 11:25:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (68, 'project_report', 'admin/report/project_report', 'fa fa-dot-circle-o', 59, 2, '2016-05-29 11:25:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (69, 'goal_tracking', 'admin/goal_tracking', 'fa fa-shield', 158, 4, '2019-10-16 13:58:35', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (70, 'departments', 'admin/departments', 'fa fa-user-secret', 156, 1, '2019-10-16 13:56:00', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (71, 'holiday', 'admin/holiday', 'fa fa-calendar-plus-o', 156, 2, '2019-10-16 13:56:00', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (72, 'leave_management', 'admin/leave_management', 'fa fa-plane', 156, 4, '2019-10-16 13:56:00', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (73, 'utilities', '#', 'fa fa-gift', 0, 3, '2020-02-20 11:37:11', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (74, 'overtime', 'admin/utilities/overtime', 'fa fa-clock-o', 89, 9, '2017-06-09 16:34:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (75, 'office_stock', '#', 'fa fa-codepen', 29, 0, '2019-10-21 12:49:03', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (76, 'stock_category', 'admin/stock/stock_category', 'fa fa-sliders', 75, 0, '2016-05-29 11:20:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (77, 'manage_stock', '#', 'fa fa-archive', 75, 2, '2017-04-25 18:41:10', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (78, 'assign_stock', '#', 'fa fa-align-left', 75, 3, '2017-04-25 18:41:10', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (79, 'stock_report', 'admin/stock/report', 'fa fa-line-chart', 75, 4, '2017-04-24 21:18:25', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (81, 'stock_list', 'admin/stock/stock_list', 'fa fa-stack-exchange', 75, 1, '2017-04-25 18:41:10', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (82, 'assign_stock', 'admin/stock/assign_stock', 'fa fa-align-left', 78, 0, '2016-05-29 11:25:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (83, 'assign_stock_report', 'admin/stock/assign_stock_report', 'fa fa-bar-chart', 78, 1, '2016-05-29 11:25:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (84, 'stock_history', 'admin/stock/stock_history', 'fa fa-file-text-o', 77, 0, '2016-05-29 11:25:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (85, 'performance', '#', 'fa fa-dribbble', 156, 7, '2019-10-16 13:56:00', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (86, 'performance_indicator', 'admin/performance/performance_indicator', 'fa fa-random', 85, 0, '2016-05-29 11:20:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (87, 'performance_report', 'admin/performance/performance_report', 'fa fa-calendar-o', 85, 2, '2016-05-29 11:20:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (88, 'give_appraisal', 'admin/performance/give_performance_appraisal', 'fa fa-plus', 85, 1, '2016-05-29 11:20:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (89, 'payroll', '#', 'fa fa-usd', 0, 2, '2019-10-14 14:09:50', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (90, 'manage_salary_details', 'admin/payroll/manage_salary_details', 'fa fa-usd', 89, 2, '2017-04-22 10:36:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (91, 'employee_salary_list', 'admin/payroll/employee_salary_list', 'fa fa-user-secret', 89, 3, '2017-04-22 10:36:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (92, 'make_payment', 'admin/payroll/make_payment', 'fa fa-tasks', 89, 4, '2017-04-22 10:36:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (93, 'generate_payslip', 'admin/payroll/generate_payslip', 'fa fa-list-ul', 89, 5, '2017-04-22 10:36:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (94, 'salary_template', 'admin/payroll/salary_template', 'fa fa-money', 89, 0, '2017-04-22 10:36:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (95, 'hourly_rate', 'admin/payroll/hourly_rate', 'fa fa-clock-o', 89, 1, '2017-04-22 10:36:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (96, 'payroll_summary', 'admin/payroll/payroll_summary', 'fa fa-camera-retro', 89, 6, '2017-04-22 10:36:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (97, 'provident_fund', 'admin/payroll/provident_fund', 'fa fa-briefcase', 89, 8, '2017-06-09 16:34:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (98, 'advance_salary', 'admin/payroll/advance_salary', 'fa fa-cc-mastercard', 89, 7, '2017-06-09 16:34:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (99, 'employee_award', 'admin/award', 'fa fa-trophy', 156, 5, '2019-10-16 13:56:00', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (100, 'announcements', 'admin/announcements', 'fa fa-bullhorn icon', 159, 0, '2019-10-16 13:52:44', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (101, 'training', 'admin/training', 'fa fa-suitcase', 156, 3, '2019-10-16 13:56:00', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (102, 'job_circular', '#', 'fa fa-globe', 156, 8, '2019-10-16 13:56:00', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (103, 'jobs_posted', 'admin/job_circular/jobs_posted', 'fa fa-ticket', 102, 0, '2016-05-29 11:20:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (104, 'jobs_applications', 'admin/job_circular/jobs_applications', 'fa fa-compass', 102, 1, '2016-05-29 11:20:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (105, 'attendance', '#', 'fa fa-file-text', 156, 6, '2019-10-16 13:56:00', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (106, 'timechange_request', 'admin/attendance/timechange_request', 'fa fa-calendar-o', 105, 1, '2016-05-29 11:20:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (107, 'attendance_report', 'admin/attendance/attendance_report', 'fa fa-file-text', 105, 2, '2016-05-29 11:20:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (108, 'time_history', 'admin/attendance/time_history', 'fa fa-clock-o', 105, 0, '2016-05-29 11:20:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (109, 'pull-down', '', '', 0, 0, '2016-05-30 15:13:20', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (110, 'filemanager', 'admin/filemanager', 'fa fa-file', 0, 10, '2019-12-01 10:51:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (111, 'company_details', 'admin/settings', 'fa fa-fw fa-info-circle', 25, 1, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (112, 'system_settings', 'admin/settings/system', 'fa fa-fw fa-desktop', 25, 2, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (113, 'email_settings', 'admin/settings/email', 'fa fa-fw fa-envelope', 25, 3, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (114, 'email_templates', 'admin/settings/templates', 'fa fa-fw fa-pencil-square', 25, 4, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (115, 'email_integration', 'admin/settings/email_integration', 'fa fa-fw fa-envelope-o', 25, 5, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (116, 'payment_settings', 'admin/settings/payments', 'fa fa-fw fa-dollar', 25, 6, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (117, 'invoice_settings', 'admin/settings/invoice', 'fa fa-fw fa-money', 25, 0, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (118, 'estimate_settings', 'admin/settings/estimate', 'fa fa-fw fa-file-o', 25, 0, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (119, 'tickets_leads_settings', 'admin/settings/tickets', 'fa fa-fw fa-ticket', 25, 0, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (120, 'theme_settings', 'admin/settings/theme', 'fa fa-fw fa-code', 25, 0, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (121, 'working_days', 'admin/settings/working_days', 'fa fa-fw fa-calendar', 25, 0, '2019-11-19 14:53:35', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (122, 'leave_category', 'admin/settings/leave_category', 'fa fa-fw fa-pagelines', 25, 0, '2017-04-24 19:43:41', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (123, 'income_category', 'admin/settings/income_category', 'fa fa-fw fa-certificate', 25, 0, '2017-04-24 19:43:41', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (124, 'expense_category', 'admin/settings/expense_category', 'fa fa-fw fa-tasks', 25, 0, '2017-04-24 19:43:41', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (125, 'customer_group', 'admin/settings/customer_group', 'fa fa-fw fa-users', 25, 0, '2017-04-24 19:43:41', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (126, 'contract_type', 'admin/settings/contract_type', 'fa fa-fw fa-file-o', 25, 0, '2017-04-24 19:43:41', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (127, 'lead_status', 'admin/settings/lead_status', 'fa fa-fw fa-list-ul', 25, 0, '2017-04-24 19:43:41', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (128, 'lead_source', 'admin/settings/lead_source', 'fa fa-fw fa-arrow-down', 25, 0, '2017-04-24 19:43:41', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (129, 'opportunities_state_reason', 'admin/settings/opportunities_state_reason', 'fa fa-fw fa-dot-circle-o', 25, 0, '2017-04-24 19:43:41', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (130, 'custom_field', 'admin/settings/custom_field', 'fa fa-fw fa-star-o', 25, 0, '2017-04-24 19:43:41', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (131, 'payment_method', 'admin/settings/payment_method', 'fa fa-fw fa-money', 25, 0, '2017-04-24 19:43:41', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (132, 'cronjob', 'admin/settings/cronjob', 'fa fa-fw fa-contao', 25, 0, '2017-04-24 19:46:20', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (133, 'menu_allocation', 'admin/settings/menu_allocation', 'fa fa-fw fa fa-compass', 25, 0, '2017-04-24 19:46:20', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (134, 'notification', 'admin/settings/notification', 'fa fa-fw fa-bell-o', 25, 0, '2017-04-24 19:46:20', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (135, 'email_notification', 'admin/settings/email_notification', 'fa fa-fw fa-bell-o', 25, 0, '2017-04-24 19:46:20', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (136, 'database_backup', 'admin/settings/database_backup', 'fa fa-fw fa-database', 25, 0, '2017-04-24 19:46:20', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (137, 'translations', 'admin/settings/translations', 'fa fa-fw fa-language', 25, 0, '2017-04-24 19:46:20', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (138, 'system_update', 'admin/settings/system_update', 'fa fa-fw fa-pencil-square-o', 25, 0, '2019-10-03 10:57:01', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (139, 'private_chat', 'chat/conversations', 'fa fa-envelope', 159, 1, '2019-10-16 13:52:44', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (140, 'proposals', 'admin/proposals', 'fa fa-circle-o', 12, 0, '2019-11-13 13:14:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (141, 'knowledgebase', '#', 'fa fa-question-circle', 159, 2, '2019-10-21 12:49:03', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (142, 'categories', 'admin/knowledgebase/categories', 'fa fa-circle-o', 141, 2, '2018-01-06 09:35:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (143, 'articles', 'admin/knowledgebase/articles', 'fa fa-circle-o', 141, 1, '2018-01-06 09:35:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (144, 'knowledgebase', 'admin/knowledgebase', 'fa fa-circle-o', 141, 0, '2018-01-06 09:35:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (145, 'dashboard_settings', 'admin/settings/dashboard', 'fa fa-fw fa-dashboard', 25, 11, '2017-04-24 19:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (146, 'transactions_reports', '#', 'fa fa-building-o', 42, 0, '2019-10-14 13:50:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (147, 'report', 'admin/report/sales_report', 'fa fa-bar-chart', 12, 4, '2019-11-05 10:09:49', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (148, 'mark_attendance', 'admin/mark_attendance', 'fa fa-file-text', 105, 3, '2019-10-03 10:22:43', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (149, 'allowed_ip', 'admin/settings/allowed_ip', 'fa fa-server', 25, 1, '2018-11-14 12:22:20', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (150, 'materials_and_suppliers', '#', 'icon-layers', 0, 6, '2019-12-01 10:52:15', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (151, 'supplier', 'admin/supplier', 'icon-briefcase', 150, 1, '2019-04-30 20:40:52', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (152, 'purchase', 'admin/purchase', 'icon-handbag', 150, 2, '2019-10-01 12:40:31', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (153, 'return_stock', 'admin/return_stock', 'icon-share-alt', 150, 3, '2019-05-04 18:49:30', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (154, 'purchase_payment', 'admin/purchase/all_payments', 'icon-credit-card', 150, 4, '2019-05-04 16:23:11', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (155, 'purchase_settings', 'admin/settings/purchase', 'fa-fw icon-handbag', 25, 0, '2017-04-25 01:38:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (156, 'HR', '#', 'fa fa-briefcase', 0, 4, '2019-12-01 10:52:15', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (158, 'Project_Management', '#', 'fa fa-codepen', 0, 5, '2019-10-30 10:19:35', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (159, 'Administration', '#', 'fa fa-ban', 0, 7, '2019-10-16 13:58:35', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (160, 'Web Mail', 'https://www.onetecgroup.com/web-mail/', 'fa fa-envelope', 0, 2, '2020-02-20 11:37:11', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (161, 'Marketing', '#', 'fa fa-headphones', 0, 4, '2020-02-20 11:37:11', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (162, 'Bulk E-mail', 'admin/dashboard/marketing', 'fa fa-ban', 161, 0, '2020-02-20 11:36:22', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (163, 'Social Platform', 'admin/dashboard/social_platform', 'fa fa-ban', 161, 1, '2020-02-20 11:36:22', 0);


#
# TABLE STRUCTURE FOR: tbl_mettings
#

DROP TABLE IF EXISTS `tbl_mettings`;

CREATE TABLE `tbl_mettings` (
  `mettings_id` int(11) NOT NULL AUTO_INCREMENT,
  `leads_id` int(11) DEFAULT NULL,
  `opportunities_id` int(11) DEFAULT NULL,
  `meeting_subject` varchar(200) NOT NULL,
  `attendees` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_date` varchar(100) NOT NULL,
  `end_date` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `description` mediumtext NOT NULL,
  PRIMARY KEY (`mettings_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_migrations
#

DROP TABLE IF EXISTS `tbl_migrations`;

CREATE TABLE `tbl_migrations` (
  `version` bigint(20) NOT NULL
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_migrations` (`version`) VALUES ('142');


#
# TABLE STRUCTURE FOR: tbl_milestones
#

DROP TABLE IF EXISTS `tbl_milestones`;

CREATE TABLE `tbl_milestones` (
  `milestones_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `milestone_name` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `start_date` varchar(20) NOT NULL,
  `end_date` varchar(20) NOT NULL,
  `client_visible` text,
  PRIMARY KEY (`milestones_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_notes
#

DROP TABLE IF EXISTS `tbl_notes`;

CREATE TABLE `tbl_notes` (
  `notes_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `is_client` enum('Yes','No') NOT NULL DEFAULT 'No',
  `notes` mediumtext,
  `added_by` int(11) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notes_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_notifications
#

DROP TABLE IF EXISTS `tbl_notifications`;

CREATE TABLE `tbl_notifications` (
  `notifications_id` int(11) NOT NULL AUTO_INCREMENT,
  `read` int(11) NOT NULL DEFAULT '0',
  `read_inline` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `from_user_id` int(11) NOT NULL DEFAULT '0',
  `to_user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(200) DEFAULT NULL,
  `link` text,
  `icon` varchar(200) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`notifications_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (1, 1, 0, '2020-01-12 19:17:45', 'assign_to_you_the_project', 1, 7, 'Ahmed Almaz', 'admin/projects/project_details/1', NULL, 'نادي البيطاش');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (2, 1, 1, '2020-01-12 19:23:50', 'not_task_update', 1, 7, 'Ahmed Almaz', 'admin/tasks/view_task_details/1', NULL, 'Task تجهيز الاعمدة الخارجية');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (3, 1, 1, '2020-01-22 03:20:03', 'not_save_leads', 11, 7, 'Ahmed Almaz', 'admin/leads/leads_details/1', NULL, 'lead Project Owner');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (4, 1, 0, '2020-01-22 03:20:03', 'not_save_leads', 11, 8, 'Ahmed Almaz', 'admin/leads/leads_details/1', NULL, 'lead Project Owner');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (5, 1, 0, '2020-02-10 13:51:37', 'not_lead_converted_to_client', 7, 8, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/1', NULL, 'lead Project Owner Client Project Owner');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (6, 1, 0, '2020-02-10 13:51:37', 'not_lead_converted_to_client', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/1', NULL, 'lead Project Owner Client Project Owner');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (7, 1, 0, '2020-02-11 10:40:32', 'not_save_leads', 11, 7, 'Ahmed Almaz ( Managing Director )', 'admin/leads/leads_details/2', NULL, 'lead mr');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (8, 1, 0, '2020-02-11 10:40:32', 'not_save_leads', 11, 8, 'Ahmed Almaz ( Managing Director )', 'admin/leads/leads_details/2', NULL, 'lead mr');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (9, 1, 0, '2020-02-11 10:55:18', 'not_new_comment', 11, 7, 'Ahmed Almaz ( Managing Director )', 'admin/leads/leads_details/2/4', NULL, 'lead mr');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (10, 1, 0, '2020-02-11 10:55:18', 'not_new_comment', 11, 8, 'Ahmed Almaz ( Managing Director )', 'admin/leads/leads_details/2/4', NULL, 'lead mr');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (11, 1, 1, '2020-02-25 13:52:41', 'not_deposit_saved', 0, 7, NULL, 'admin/transactions/view_details/1', 'building-o', 'Accounts Salaries Amount  50.00');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (12, 0, 0, '2020-02-25 13:52:41', 'not_deposit_saved', 0, 11, NULL, 'admin/transactions/view_details/1', 'building-o', 'Accounts Salaries Amount  50.00');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (13, 1, 1, '2020-02-25 13:59:24', 'not_expense_saved', 0, 7, NULL, 'admin/transactions/view_details/2', 'building-o', 'Accounts: Salaries Amount:  150.00');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (14, 0, 0, '2020-02-25 13:59:24', 'not_expense_saved', 0, 11, NULL, 'admin/transactions/view_details/2', 'building-o', 'Accounts: Salaries Amount:  150.00');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (15, 0, 0, '2020-02-25 20:34:19', 'not_save_leads', 7, 8, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/3', NULL, 'lead mohaad');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (16, 0, 0, '2020-02-25 20:34:19', 'not_save_leads', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/3', NULL, 'lead mohaad');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (17, 0, 0, '2020-02-25 20:35:03', 'not_lead_converted_to_client', 7, 8, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/3', NULL, 'lead mohaad Client mohaad');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (18, 0, 0, '2020-02-25 20:35:03', 'not_lead_converted_to_client', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/3', NULL, 'lead mohaad Client mohaad');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (19, 0, 0, '2020-02-27 08:27:44', 'not_changed_status', 7, 8, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/2', NULL, 'lead mr');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (20, 0, 0, '2020-02-27 08:27:44', 'not_changed_status', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/2', NULL, 'lead mr');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (21, 0, 0, '2020-02-27 16:14:03', 'not_save_leads', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/4', NULL, 'lead DINA WAGEEH');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (22, 0, 0, '2020-03-08 16:23:15', 'not_save_leads', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/5', NULL, 'lead ALAM EL RYADA');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (23, 0, 0, '2020-03-08 16:24:21', 'not_update_leads', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/4', NULL, 'lead DINA WAGEEH');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (24, 0, 0, '2020-03-08 16:26:22', 'not_save_leads', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/6', NULL, 'lead IMAN SOBHY');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (25, 0, 0, '2020-03-08 16:28:03', 'not_save_leads', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/7', NULL, 'lead MOHAMED KESHK');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (26, 0, 0, '2020-03-08 16:30:03', 'not_save_leads', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/8', NULL, 'lead MOHAMED ABD ALLAH');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (27, 0, 0, '2020-03-08 16:32:40', 'not_save_leads', 7, 11, 'MR. Amr Attaalla (CEO)', 'admin/leads/leads_details/9', NULL, 'lead SHOOTING CLUB KHATAMYA');


#
# TABLE STRUCTURE FOR: tbl_offence_category
#

DROP TABLE IF EXISTS `tbl_offence_category`;

CREATE TABLE `tbl_offence_category` (
  `offence_id` int(2) NOT NULL AUTO_INCREMENT,
  `offence_category` varchar(100) NOT NULL,
  PRIMARY KEY (`offence_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_online_payment
#

DROP TABLE IF EXISTS `tbl_online_payment`;

CREATE TABLE `tbl_online_payment` (
  `online_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway_name` varchar(20) CHARACTER SET latin1 NOT NULL,
  `icon` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`online_payment_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`) VALUES (1, 'Mollie', 'ideal_mollie.png');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`) VALUES (2, 'PayUmoney', 'payumoney.jpg');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`) VALUES (3, 'Razorpay', 'razorpay.png');


#
# TABLE STRUCTURE FOR: tbl_opportunities
#

DROP TABLE IF EXISTS `tbl_opportunities`;

CREATE TABLE `tbl_opportunities` (
  `opportunities_id` int(11) NOT NULL AUTO_INCREMENT,
  `opportunity_name` varchar(100) NOT NULL,
  `stages` varchar(20) NOT NULL,
  `probability` varchar(20) NOT NULL,
  `close_date` varchar(20) NOT NULL,
  `opportunities_state_reason_id` int(2) NOT NULL,
  `expected_revenue` decimal(10,2) NOT NULL,
  `new_link` varchar(20) NOT NULL,
  `next_action` varchar(100) NOT NULL,
  `next_action_date` varchar(20) NOT NULL,
  `notes` text,
  `permission` text,
  PRIMARY KEY (`opportunities_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_opportunities_state_reason
#

DROP TABLE IF EXISTS `tbl_opportunities_state_reason`;

CREATE TABLE `tbl_opportunities_state_reason` (
  `opportunities_state_reason_id` int(2) NOT NULL AUTO_INCREMENT,
  `opportunities_state` varchar(20) NOT NULL,
  `opportunities_state_reason` varchar(100) NOT NULL,
  PRIMARY KEY (`opportunities_state_reason_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_outgoing_emails
#

DROP TABLE IF EXISTS `tbl_outgoing_emails`;

CREATE TABLE `tbl_outgoing_emails` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent_to` varchar(64) DEFAULT NULL,
  `sent_from` varchar(64) DEFAULT NULL,
  `subject` text,
  `message` longtext,
  `date_sent` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `delivered` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_overtime
#

DROP TABLE IF EXISTS `tbl_overtime`;

CREATE TABLE `tbl_overtime` (
  `overtime_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `overtime_date` date NOT NULL,
  `overtime_hours` varchar(20) NOT NULL,
  `notes` text,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`overtime_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_payment_methods
#

DROP TABLE IF EXISTS `tbl_payment_methods`;

CREATE TABLE `tbl_payment_methods` (
  `payment_methods_id` int(11) NOT NULL AUTO_INCREMENT,
  `method_name` varchar(64) NOT NULL DEFAULT 'Paypal',
  PRIMARY KEY (`payment_methods_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_payment_methods` (`payment_methods_id`, `method_name`) VALUES (1, 'Cash');


#
# TABLE STRUCTURE FOR: tbl_payments
#

DROP TABLE IF EXISTS `tbl_payments`;

CREATE TABLE `tbl_payments` (
  `payments_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoices_id` int(11) NOT NULL,
  `trans_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_method` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` longtext COLLATE utf8_unicode_ci,
  `currency` varchar(64) COLLATE utf8_unicode_ci DEFAULT 'USD',
  `notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_date` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `month_paid` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year_paid` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paid_by` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `account_id` int(11) NOT NULL DEFAULT '0' COMMENT 'account_id means tracking deposit from which account',
  PRIMARY KEY (`payments_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_penalty_category
#

DROP TABLE IF EXISTS `tbl_penalty_category`;

CREATE TABLE `tbl_penalty_category` (
  `penalty_id` int(2) NOT NULL AUTO_INCREMENT,
  `penalty_type` varchar(100) NOT NULL,
  `fine_amount` int(11) NOT NULL,
  `penalty_days` varchar(10) NOT NULL,
  PRIMARY KEY (`penalty_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_performance_apprisal
#

DROP TABLE IF EXISTS `tbl_performance_apprisal`;

CREATE TABLE `tbl_performance_apprisal` (
  `performance_appraisal_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(2) NOT NULL,
  `general_remarks` text NOT NULL,
  `appraisal_month` varchar(100) NOT NULL,
  `customer_experiece_management` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `marketing` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `management` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `administration` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `presentation_skill` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `quality_of_work` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `efficiency` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `integrity` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `professionalism` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `team_work` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `critical_thinking` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `conflict_management` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `attendance` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `ability_to_meed_deadline` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  PRIMARY KEY (`performance_appraisal_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_performance_indicator
#

DROP TABLE IF EXISTS `tbl_performance_indicator`;

CREATE TABLE `tbl_performance_indicator` (
  `performance_indicator_id` int(5) NOT NULL AUTO_INCREMENT,
  `designations_id` int(2) NOT NULL,
  `customer_experiece_management` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `marketing` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `management` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `administration` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `presentation_skill` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `quality_of_work` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `efficiency` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `integrity` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `professionalism` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `team_work` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `critical_thinking` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `conflict_management` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `attendance` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `ability_to_meed_deadline` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  PRIMARY KEY (`performance_indicator_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_pinaction
#

DROP TABLE IF EXISTS `tbl_pinaction`;

CREATE TABLE `tbl_pinaction` (
  `pinaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `module_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`pinaction_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_priorities
#

DROP TABLE IF EXISTS `tbl_priorities`;

CREATE TABLE `tbl_priorities` (
  `priority` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_priority
#

DROP TABLE IF EXISTS `tbl_priority`;

CREATE TABLE `tbl_priority` (
  `priority_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`priority_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_priority` (`priority_id`, `priority`) VALUES (1, 'High');
INSERT INTO `tbl_priority` (`priority_id`, `priority`) VALUES (2, 'Medium');
INSERT INTO `tbl_priority` (`priority_id`, `priority`) VALUES (3, 'Low');


#
# TABLE STRUCTURE FOR: tbl_private_chat
#

DROP TABLE IF EXISTS `tbl_private_chat`;

CREATE TABLE `tbl_private_chat` (
  `private_chat_id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_title` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`private_chat_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_private_chat` (`private_chat_id`, `chat_title`, `user_id`, `time`) VALUES (1, '', 7, '2020-01-12 18:47:58');


#
# TABLE STRUCTURE FOR: tbl_private_chat_messages
#

DROP TABLE IF EXISTS `tbl_private_chat_messages`;

CREATE TABLE `tbl_private_chat_messages` (
  `private_chat_messages_id` int(11) NOT NULL AUTO_INCREMENT,
  `private_chat_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `message_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`private_chat_messages_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_private_chat_messages` (`private_chat_messages_id`, `private_chat_id`, `user_id`, `message`, `message_time`) VALUES (1, 1, 7, 'hi', '2020-01-12 18:48:03');
INSERT INTO `tbl_private_chat_messages` (`private_chat_messages_id`, `private_chat_id`, `user_id`, `message`, `message_time`) VALUES (2, 1, 7, 'HI', '2020-01-12 18:49:45');
INSERT INTO `tbl_private_chat_messages` (`private_chat_messages_id`, `private_chat_id`, `user_id`, `message`, `message_time`) VALUES (8, 1, 7, 'يفتح الله', '2020-01-16 14:02:34');


#
# TABLE STRUCTURE FOR: tbl_private_chat_users
#

DROP TABLE IF EXISTS `tbl_private_chat_users`;

CREATE TABLE `tbl_private_chat_users` (
  `private_chat_users_id` int(11) NOT NULL AUTO_INCREMENT,
  `private_chat_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `active` int(11) NOT NULL COMMENT '0 == minimize chat,1 == open chat and  2 == close chat ',
  `unread` int(11) NOT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0' COMMENT 'keep last message id',
  PRIMARY KEY (`private_chat_users_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_private_chat_users` (`private_chat_users_id`, `private_chat_id`, `user_id`, `to_user_id`, `active`, `unread`, `title`, `deleted`) VALUES (1, 1, 7, 1, 2, 0, ' <strong>Ahmed Almaz</strong>', 0);


#
# TABLE STRUCTURE FOR: tbl_project
#

DROP TABLE IF EXISTS `tbl_project`;

CREATE TABLE `tbl_project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(100) NOT NULL,
  `client_id` text,
  `progress` varchar(50) NOT NULL,
  `calculate_progress` varchar(50) DEFAULT NULL,
  `start_date` varchar(20) NOT NULL,
  `end_date` varchar(20) NOT NULL,
  `alert_overdue` tinyint(1) NOT NULL DEFAULT '0',
  `project_cost` decimal(18,2) NOT NULL DEFAULT '0.00',
  `demo_url` varchar(100) NOT NULL,
  `project_status` varchar(20) NOT NULL,
  `description` text,
  `notify_client` enum('Yes','No') NOT NULL,
  `timer_status` enum('on','off') DEFAULT NULL,
  `timer_started_by` int(11) DEFAULT NULL,
  `start_time` int(11) DEFAULT NULL,
  `logged_time` int(11) DEFAULT NULL,
  `permission` text,
  `notes` text,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `hourly_rate` varchar(200) DEFAULT NULL,
  `fixed_rate` varchar(200) DEFAULT NULL,
  `project_settings` text,
  `with_tasks` enum('yes','no') NOT NULL DEFAULT 'no',
  `estimate_hours` varchar(50) DEFAULT NULL,
  `billing_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`project_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_project_settings
#

DROP TABLE IF EXISTS `tbl_project_settings`;

CREATE TABLE `tbl_project_settings` (
  `settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `settings` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`settings_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (1, 'show_team_members', 'view team members');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (2, 'show_milestones', 'view project milestones');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (5, 'show_project_tasks', 'view project tasks');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (6, 'show_project_attachments', 'view project attachments');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (7, 'show_timesheets', 'view project timesheets');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (8, 'show_project_bugs', 'view project bugs');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (9, 'show_project_history', 'view project history');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (10, 'show_project_calendar', 'view project calendars');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (11, 'show_project_comments', 'view project comments');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (13, 'show_gantt_chart', 'view Gantt chart');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (14, 'show_project_hours', 'view project hours');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (15, 'comment_on_project_tasks', 'access To comment on project tasks');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (16, 'show_project_tasks_attachments', 'view task attachments');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (20, 'show_tasks_hours', 'show_tasks_hours');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (21, 'show_finance_overview', 'show_finance_overview');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (22, 'show_staff_finance_overview', 'admin and staff can see the price');


#
# TABLE STRUCTURE FOR: tbl_proposals
#

DROP TABLE IF EXISTS `tbl_proposals`;

CREATE TABLE `tbl_proposals` (
  `proposals_id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_id` int(11) DEFAULT '0',
  `proposal_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `proposal_month` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `proposal_year` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `due_date` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alert_overdue` tinyint(1) DEFAULT '0',
  `currency` varchar(32) COLLATE utf8_unicode_ci DEFAULT 'USD',
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  `tax` int(11) NOT NULL DEFAULT '0',
  `total_tax` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'draft',
  `date_sent` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `proposal_deleted` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `emailed` enum('Yes','No') COLLATE utf8_unicode_ci DEFAULT 'No',
  `show_client` enum('Yes','No') COLLATE utf8_unicode_ci DEFAULT 'No',
  `convert` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `convert_module` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `convert_module_id` int(11) DEFAULT '0',
  `converted_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `permission` text COLLATE utf8_unicode_ci,
  `discount_type` enum('before_tax','after_tax') COLLATE utf8_unicode_ci DEFAULT NULL,
  `discount_percent` int(2) NOT NULL DEFAULT '0',
  `discount_total` decimal(18,2) NOT NULL DEFAULT '0.00',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `adjustment` decimal(18,2) NOT NULL DEFAULT '0.00',
  `decrease` decimal(18,2) NOT NULL DEFAULT '0.00',
  `show_quantity_as` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_cmments` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Yes',
  PRIMARY KEY (`proposals_id`),
  UNIQUE KEY `reference_no` (`reference_no`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_proposals_items
#

DROP TABLE IF EXISTS `tbl_proposals_items`;

CREATE TABLE `tbl_proposals_items` (
  `proposals_items_id` int(11) NOT NULL AUTO_INCREMENT,
  `proposals_id` int(11) NOT NULL,
  `saved_items_id` int(11) DEFAULT '0',
  `item_name` varchar(150) COLLATE utf8_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext COLLATE utf8_unicode_ci,
  `quantity` decimal(10,2) DEFAULT '0.00',
  `unit_cost` decimal(10,2) DEFAULT '0.00',
  `item_tax_rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text COLLATE utf8_unicode_ci,
  `item_tax_total` decimal(10,2) DEFAULT '0.00',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order` int(11) DEFAULT '0',
  `unit` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `hsn_code` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`proposals_items_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_purchase_items
#

DROP TABLE IF EXISTS `tbl_purchase_items`;

CREATE TABLE `tbl_purchase_items` (
  `items_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `item_tax_rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text COLLATE utf8_unicode_ci,
  `item_tax_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `item_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext COLLATE utf8_unicode_ci,
  `unit_cost` decimal(10,2) DEFAULT '0.00',
  `order` int(11) DEFAULT '0',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hsn_code` text COLLATE utf8_unicode_ci,
  `saved_items_id` int(11) DEFAULT '0',
  PRIMARY KEY (`items_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_purchase_payments
#

DROP TABLE IF EXISTS `tbl_purchase_payments`;

CREATE TABLE `tbl_purchase_payments` (
  `payments_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `trans_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_method` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` longtext COLLATE utf8_unicode_ci,
  `currency` varchar(64) COLLATE utf8_unicode_ci DEFAULT 'USD',
  `notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `month_paid` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year_paid` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paid_to` int(11) NOT NULL,
  `paid_by` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `account_id` int(11) NOT NULL DEFAULT '0' COMMENT 'account_id means tracking deduct from which account',
  PRIMARY KEY (`payments_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_purchases
#

DROP TABLE IF EXISTS `tbl_purchases`;

CREATE TABLE `tbl_purchases` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `total` decimal(20,2) DEFAULT NULL,
  `update_stock` enum('Yes','No') DEFAULT 'Yes',
  `status` varchar(20) DEFAULT NULL,
  `emailed` enum('Yes','No') DEFAULT NULL,
  `date_sent` varchar(20) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `discount_type` enum('before_tax','after_tax') DEFAULT NULL,
  `discount_percent` decimal(10,2) DEFAULT NULL,
  `adjustment` decimal(18,2) DEFAULT NULL,
  `discount_total` decimal(18,2) DEFAULT NULL,
  `show_quantity_as` varchar(10) DEFAULT NULL,
  `permission` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total_tax` text,
  `tax` decimal(20,2) DEFAULT NULL,
  `notes` text,
  PRIMARY KEY (`purchase_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_quotation_details
#

DROP TABLE IF EXISTS `tbl_quotation_details`;

CREATE TABLE `tbl_quotation_details` (
  `quotation_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `quotations_id` int(11) NOT NULL,
  `quotation_form_data` text,
  `quotation_data` text,
  PRIMARY KEY (`quotation_details_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_quotationforms
#

DROP TABLE IF EXISTS `tbl_quotationforms`;

CREATE TABLE `tbl_quotationforms` (
  `quotationforms_id` int(11) NOT NULL AUTO_INCREMENT,
  `quotationforms_title` varchar(200) NOT NULL,
  `quotationforms_code` text NOT NULL,
  `quotationforms_status` varchar(20) NOT NULL DEFAULT 'enabled' COMMENT 'enabled/disabled',
  `quotations_created_by_id` int(11) NOT NULL,
  `quotationforms_date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`quotationforms_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_quotations
#

DROP TABLE IF EXISTS `tbl_quotations`;

CREATE TABLE `tbl_quotations` (
  `quotations_id` int(11) NOT NULL AUTO_INCREMENT,
  `quotations_form_title` varchar(250) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `quotations_amount` decimal(10,2) DEFAULT NULL,
  `notes` text,
  `reviewer_id` int(11) DEFAULT NULL,
  `reviewed_date` date DEFAULT NULL,
  `quotations_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `quotations_status` varchar(15) DEFAULT 'pending' COMMENT 'completed/pending',
  PRIMARY KEY (`quotations_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_reminders
#

DROP TABLE IF EXISTS `tbl_reminders`;

CREATE TABLE `tbl_reminders` (
  `reminder_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text,
  `date` datetime NOT NULL,
  `notified` enum('Yes','No') NOT NULL DEFAULT 'No',
  `module` varchar(200) NOT NULL,
  `module_id` int(11) NOT NULL,
  `user_id` varchar(40) NOT NULL,
  `notify_by_email` enum('Yes','No') NOT NULL DEFAULT 'No',
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`reminder_id`),
  KEY `rel_id` (`module`),
  KEY `rel_type` (`user_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_return_stock
#

DROP TABLE IF EXISTS `tbl_return_stock`;

CREATE TABLE `tbl_return_stock` (
  `return_stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) DEFAULT NULL,
  `reference_no` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `total` decimal(20,2) DEFAULT NULL,
  `update_stock` enum('Yes','No') CHARACTER SET utf8 DEFAULT 'Yes',
  `status` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `emailed` enum('Yes','No') CHARACTER SET utf8 DEFAULT NULL,
  `date_sent` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `return_stock_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `discount_type` enum('before_tax','after_tax') CHARACTER SET utf8 DEFAULT NULL,
  `discount_percent` decimal(10,2) DEFAULT NULL,
  `adjustment` decimal(18,2) DEFAULT NULL,
  `discount_total` decimal(18,2) DEFAULT NULL,
  `show_quantity_as` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `permission` text CHARACTER SET utf8,
  `created` timestamp NOT NULL DEFAULT '2019-05-04 21:00:00',
  `total_tax` text CHARACTER SET utf8,
  `tax` decimal(20,2) DEFAULT NULL,
  `notes` text CHARACTER SET utf8,
  PRIMARY KEY (`return_stock_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_return_stock_items
#

DROP TABLE IF EXISTS `tbl_return_stock_items`;

CREATE TABLE `tbl_return_stock_items` (
  `items_id` int(11) NOT NULL AUTO_INCREMENT,
  `return_stock_id` int(11) NOT NULL,
  `item_tax_rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `item_tax_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `item_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `unit_cost` decimal(10,2) DEFAULT '0.00',
  `order` int(11) DEFAULT '0',
  `date_saved` timestamp NOT NULL DEFAULT '2019-05-04 21:00:00',
  `unit` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `hsn_code` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `saved_items_id` int(11) DEFAULT '0',
  PRIMARY KEY (`items_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_salary_allowance
#

DROP TABLE IF EXISTS `tbl_salary_allowance`;

CREATE TABLE `tbl_salary_allowance` (
  `salary_allowance_id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_template_id` int(11) NOT NULL,
  `allowance_label` varchar(200) NOT NULL,
  `allowance_value` varchar(200) NOT NULL,
  PRIMARY KEY (`salary_allowance_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_salary_deduction
#

DROP TABLE IF EXISTS `tbl_salary_deduction`;

CREATE TABLE `tbl_salary_deduction` (
  `salary_deduction_id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_template_id` int(11) NOT NULL,
  `deduction_label` varchar(200) NOT NULL,
  `deduction_value` varchar(200) NOT NULL,
  PRIMARY KEY (`salary_deduction_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_salary_payment
#

DROP TABLE IF EXISTS `tbl_salary_payment`;

CREATE TABLE `tbl_salary_payment` (
  `salary_payment_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `payment_month` varchar(20) NOT NULL,
  `fine_deduction` varchar(200) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `comments` text,
  `paid_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deduct_from` int(11) NOT NULL DEFAULT '0' COMMENT 'deduct from means tracking deduct from which account',
  PRIMARY KEY (`salary_payment_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_salary_payment_allowance
#

DROP TABLE IF EXISTS `tbl_salary_payment_allowance`;

CREATE TABLE `tbl_salary_payment_allowance` (
  `salary_payment_allowance_id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_payment_id` int(11) NOT NULL,
  `salary_payment_allowance_label` varchar(200) NOT NULL,
  `salary_payment_allowance_value` varchar(200) NOT NULL,
  PRIMARY KEY (`salary_payment_allowance_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_salary_payment_deduction
#

DROP TABLE IF EXISTS `tbl_salary_payment_deduction`;

CREATE TABLE `tbl_salary_payment_deduction` (
  `salary_payment_deduction` int(11) NOT NULL AUTO_INCREMENT,
  `salary_payment_id` int(11) NOT NULL,
  `salary_payment_deduction_label` varchar(200) NOT NULL,
  `salary_payment_deduction_value` varchar(200) NOT NULL,
  PRIMARY KEY (`salary_payment_deduction`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_salary_payment_details
#

DROP TABLE IF EXISTS `tbl_salary_payment_details`;

CREATE TABLE `tbl_salary_payment_details` (
  `salary_payment_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_payment_id` int(11) NOT NULL,
  `salary_payment_details_label` varchar(200) NOT NULL,
  `salary_payment_details_value` varchar(200) NOT NULL,
  PRIMARY KEY (`salary_payment_details_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_salary_payslip
#

DROP TABLE IF EXISTS `tbl_salary_payslip`;

CREATE TABLE `tbl_salary_payslip` (
  `payslip_id` int(5) NOT NULL AUTO_INCREMENT,
  `payslip_number` varchar(100) DEFAULT NULL,
  `salary_payment_id` int(5) NOT NULL,
  `payslip_generate_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`payslip_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_salary_template
#

DROP TABLE IF EXISTS `tbl_salary_template`;

CREATE TABLE `tbl_salary_template` (
  `salary_template_id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_grade` varchar(200) NOT NULL,
  `basic_salary` varchar(200) NOT NULL,
  `overtime_salary` varchar(100) NOT NULL,
  PRIMARY KEY (`salary_template_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_saved_items
#

DROP TABLE IF EXISTS `tbl_saved_items`;

CREATE TABLE `tbl_saved_items` (
  `saved_items_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT 'Item Name',
  `item_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_desc` longtext COLLATE utf8_unicode_ci,
  `unit_cost` decimal(18,2) DEFAULT '0.00',
  `customer_group_id` int(11) NOT NULL DEFAULT '0',
  `unit_type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tax_rates_id` text COLLATE utf8_unicode_ci,
  `item_tax_rate` decimal(18,2) DEFAULT '0.00',
  `item_tax_total` decimal(18,2) DEFAULT '0.00',
  `quantity` decimal(18,2) DEFAULT '0.00',
  `total_cost` decimal(18,2) DEFAULT '0.00',
  `hsn_code` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`saved_items_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (1, 'سلم قفز', '2147483647', '', 'عرض ٦٠ سم\nطول ١٢٠ سم\nارتفاع ٢٠ سم\nعدد المقومات ٣', '3000.00', 3, 'Pc', '-', '0.00', '0.00', '1.00', '3000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (2, 'ارضيات فوم 18 ملي', '0245jhjg', '', 'طول ١ متر\nعرض ١ متر\nالسمك 18\n ملي\nلون واحد للبلاطة\nدرجة اولي مقاوم البكتريا و الفطريات', '115.00', 2, '', '-', '0.00', '0.00', '1.00', '115.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (3, 'ارضيات فوم 20 ملي', '2147483647', '', 'طول ١ متر\nعرض ١ متر\nالسمك 20 ملي\n٢ لون للبلاطة الواحدة\nدرجة اولي مقاوم البكتريا و الفطريات', '125.00', 2, '', '-', '0.00', '0.00', '1.00', '125.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (4, 'ارضيات فوم 25 ملي', '933383', '', 'طول ١ متر\nعرض ١ متر\nالسمك ٢٥ ملي\n٢ لون للبلاطة الواحدة\nدرجة اولي مقاوم البكتريا و الفطريات', '155.00', 2, '', '-', '0.00', '0.00', '1.00', '155.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (5, 'ارضيات فوم 30 ملي', '555555', '', 'طول ١ متر\nعرض ١ متر\nالسمك 30 ملي\n٢ لون للبلاطة الواحدة\nدرجة اولي مقاوم البكتريا و الفطريات', '170.00', 2, '', '-', '0.00', '0.00', '1.00', '170.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (6, 'ارضيات لباد', '24kjhnmb', '#ad159e', 'متر مربع', '60.00', 0, '', '-', '0.00', '0.00', '1.00', '60.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (7, 'بيم قانوني', 'khghj', '#f05050', 'بيم قانوني بمقايس دولية \nالطول 5 متر\nالعرض من اعلي 10 سم\nالارتفاع من 85 سم الي 125 سم', '6500.00', 3, '', '-', '0.00', '0.00', '1.00', '6500.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (8, 'بيم تدريب', '1233', '#ffffff', 'الطول 5 متر \nالعرض من اعلى 10 سم\nالارتفاع من 65سم الى 85سم', '5500.00', 3, '', '-', '0.00', '0.00', '1.00', '5500.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (9, 'بيم ارضي', '12', '#ffffff', 'الطول 5 متر\nالعرض من اعلى 10 سم\nالارتفاع 5 سم', '4500.00', 3, '', '-', '0.00', '0.00', '1.00', '4500.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (10, 'مشايه ارضي', '45', '#ffffff', 'الطول 10 متر \nالعرض 2 متر \nسوست سهله الفك والتركيب', '52000.00', 3, '', '-', '0.00', '0.00', '1.00', '52000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (11, 'بيم ارضي 2', '34', '#ffffff', 'طول 5 متر \nالعرض من اعلى 10 سم \nالارتفاع 5 سم', '2000.00', 3, '', '-', '0.00', '0.00', '1.00', '2000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (12, 'عش غراب عادي', '22', '#ffffff', 'ارتفاع 45 سم\nعرض القرصه 60 سم', '2800.00', 3, '', '-', '0.00', '0.00', '1.00', '2800.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (13, 'عش غراب بحلقتين', '44', '#ffffff', 'ارتفاع 45 سم\nعرض القرصه 60 سم', '5000.00', 3, '', '-', '0.00', '0.00', '1.00', '5000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (14, 'حلق قانوني', '11', '#ffffff', 'ارتفاع 5.5 متر\n', '22000.00', 3, '', '-', '0.00', '0.00', '1.00', '22000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (15, 'حلق ناشئين', '55', '#ffffff', '', '6500.00', 3, '', '-', '0.00', '0.00', '1.00', '6500.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (16, 'متوازي ناشئين', '66', '#ffffff', '', '6000.00', 3, '', '-', '0.00', '0.00', '1.00', '6000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (17, 'متوازي ناشئات', '77', '#ffffff', '', '6000.00', 3, '', '-', '0.00', '0.00', '1.00', '6000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (18, 'عقله ناشئين', '88', '#ffffff', '', '5500.00', 3, '', '-', '0.00', '0.00', '1.00', '5500.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (19, 'حصان قفزقانوني1', '67', '#ffffff', '', '9000.00', 3, '', '-', '0.00', '0.00', '1.00', '9000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (20, 'حصان قفز فوم', '24', '#ffffff', '', '6000.00', 3, '', '-', '0.00', '0.00', '1.00', '6000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (21, 'ميني ترامبولين', '88', '#ffffff', 'سم120*120سم\nشبكه مصري\nقابل للارتفاع والانخفاض', '3900.00', 3, '', '-', '0.00', '0.00', '1.00', '3900.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (22, 'ميني ترامبولين2', '88', '#ffffff', 'سم120*120سم\nشبكه مستورده', '8000.00', 3, '', '-', '0.00', '0.00', '1.00', '8000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (23, 'متوازي رجال قانوني', '22', '#ffffff', '', '19000.00', 3, '', '-', '0.00', '0.00', '1.00', '19000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (24, ' 1عقله متحركه', '77', '#ffffff', 'بار هارد كروم \nويرات كبس', '8500.00', 3, '', '-', '0.00', '0.00', '1.00', '8500.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (25, 'عقله متحركه 2', '44', '#ffffff', 'بار استنلس ستيل\nويرات كبس', '7500.00', 3, '', '-', '0.00', '0.00', '1.00', '7500.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (26, 'عقله متحركه 3', '11', '#ffffff', 'بار حديد نيكل\nويرات افايز', '6000.00', 3, '', '-', '0.00', '0.00', '1.00', '6000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (27, ' 1متوازي بنات قانوني', '44', '#ffffff', 'بارات خشب  زان مصري\nويرات كبس\n', '13000.00', 3, '', '-', '0.00', '0.00', '1.00', '13000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (28, 'متوازي بنات قانوني 2', '56', '#ffffff', 'بارات مستورده TAISHAN\nويرات كبس', '28000.00', 3, '', '-', '0.00', '0.00', '1.00', '28000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (29, 'مشليه ارضي 2', '65', '#ffffff', 'طول  10متر\nعرض 2 متر \nسوست لحام ', '45000.00', 3, '', '-', '0.00', '0.00', '1.00', '45000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (30, 'مشايه ارضي 3', '544', '#ffffff', 'طول 10 متر\nعرض 2 متر \nفوم', '35000.00', 3, '', '-', '0.00', '0.00', '1.00', '35000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (31, 'عقله حائط مفرد', '87', '#ffffff', 'طول 240 سم\nعرض 1 متر \nبارات خشب زان \nقوائم خشب ابيض', '1650.00', 3, '', '-', '0.00', '0.00', '1.00', '1650.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (32, 'مقعد سويدي', '99', '#ffffff', 'طول 3 متر \nعرض 30 سم', '1650.00', 3, '', '-', '0.00', '0.00', '1.00', '1650.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (33, 'جهاز ترددي', '99', '#ffffff', '', '5000.00', 3, '', '-', '0.00', '0.00', '1.00', '5000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (34, 'عوامه حلق', '44', '#ffffff', '', '5000.00', 3, '', '-', '0.00', '0.00', '1.00', '5000.00', NULL);
INSERT INTO `tbl_saved_items` (`saved_items_id`, `item_name`, `item_code`, `item_color`, `item_desc`, `unit_cost`, `customer_group_id`, `unit_type`, `tax_rates_id`, `item_tax_rate`, `item_tax_total`, `quantity`, `total_cost`, `hsn_code`) VALUES (35, 'صندوق مقسم', '56', '#ffffff', '5 اجزاء', '3800.00', 3, '', '-', '0.00', '0.00', '1.00', '3800.00', NULL);


#
# TABLE STRUCTURE FOR: tbl_sent
#

DROP TABLE IF EXISTS `tbl_sent`;

CREATE TABLE `tbl_sent` (
  `sent_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `to` varchar(100) NOT NULL,
  `subject` varchar(300) NOT NULL,
  `message_body` text NOT NULL,
  `attach_file` text,
  `attach_file_path` text,
  `attach_filename` text,
  `message_time` datetime NOT NULL,
  `deleted` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`sent_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_sessions
#

DROP TABLE IF EXISTS `tbl_sessions`;

CREATE TABLE `tbl_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('070oml24is2oltvpjj33seuv2vk0guvg', '34.244.20.136', 1584353973, '__ci_last_regenerate|i:1584353973;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0jmadmnpci33h1pp69llcdks329e2o6a', '138.229.96.58', 1584300597, '__ci_last_regenerate|i:1584300597;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1045ik97hh2th2njh4jv8ek0tcjheavi', '157.55.39.75', 1583867373, '__ci_last_regenerate|i:1583867373;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1hndh829e962louj2377gcfr0mq2m3nd', '62.210.80.93', 1584018080, '__ci_last_regenerate|i:1584018079;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1icka7tb3fetisn5su6hk19l5k6qi8tu', '69.171.251.31', 1583956842, '__ci_last_regenerate|i:1583956842;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d20tv3p3rubk0vacc8m63clnn2vc0oe', '157.55.39.75', 1583867374, '__ci_last_regenerate|i:1583867374;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2n32ke7vcs7qbcu1bk553o7gfho2om75', '156.213.171.121', 1583825173, '');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2odbhbe8927oip05mflhq5p55klbvf1v', '69.171.251.12', 1584010364, '__ci_last_regenerate|i:1584010364;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2utjplfa6vj6f3biqefhfv27n4g6dkai', '159.65.24.22', 1584008325, '__ci_last_regenerate|i:1584008325;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('30a4avvdi21s7pu6hbkq6l6h6qqkn8ek', '69.171.251.33', 1583958735, '__ci_last_regenerate|i:1583958735;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3rgop39pjohaor5f2pevnifs4rp7f7l4', '156.213.171.121', 1583825168, '');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4h6mee3n6s7n1qlsn0ch4bjj727r8kam', '46.101.122.215', 1584341386, '__ci_last_regenerate|i:1584341384;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4uukeroujnnboae2h8c25idspagknav2', '157.55.39.75', 1583867370, '__ci_last_regenerate|i:1583867370;lang|s:7:\"english\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4vhjahhmt1bc7d780fpcl7lkaufor0mc', '100.38.228.111', 1584360345, '__ci_last_regenerate|i:1584360303;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}lang|s:7:\"english\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5g0q5v0chjqbnsdmqks2c9nlc21c2ir5', '211.23.152.156', 1584011988, '__ci_last_regenerate|i:1584011979;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6pokpcnu747s8o942dehs1jgi6fihm4c', '157.55.39.75', 1583928567, '__ci_last_regenerate|i:1583928566;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6qkl2vsfdpvs9jcm3htu5kcqu0rrdoh1', '157.55.39.75', 1583880600, '__ci_last_regenerate|i:1583880600;menu_active_id|a:2:{i:0;s:1:\"1\";i:1;s:1:\"0\";}url|s:15:\"admin/dashboard\";user_roll|a:142:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 04:09:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-14 14:09:50\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-03 12:05:36\";s:6:\"status\";s:1:\"0\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-10-27 16:09:11\";s:6:\"status\";s:1:\"0\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-27 16:09:08\";s:6:\"status\";s:1:\"0\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-27 16:09:06\";s:6:\"status\";s:1:\"0\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:8:\"Employee\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-16 13:56:10\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-19 14:54:41\";s:6:\"status\";s:1:\"0\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:7:\"Finance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-16 14:03:34\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-25 13:29:59\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-25 13:29:59\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-03 21:19:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-07 13:08:02\";s:6:\"status\";s:1:\"0\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-16 13:58:35\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-21 12:49:03\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-24 21:18:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-14 14:09:50\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-16 13:52:44\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 15:13:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-11-19 14:53:35\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"126\";s:5:\"label\";s:13:\"contract_type\";s:4:\"link\";s:28:\"admin/settings/contract_type\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-03 10:57:01\";s:6:\"status\";s:1:\"2\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-16 13:52:44\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-11-13 13:14:21\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-21 12:49:03\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-03 10:22:43\";s:6:\"status\";s:1:\"1\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-11-14 12:22:20\";s:6:\"status\";s:1:\"2\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:23:\"materials_and_suppliers\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-12-01 10:52:15\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-04-30 20:40:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-01 12:40:31\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-04 18:49:30\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-04 16:23:11\";s:6:\"status\";s:1:\"1\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-25 01:38:46\";s:6:\"status\";s:1:\"2\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:2:\"HR\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-12-01 10:52:15\";s:6:\"status\";s:1:\"1\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"Project_Management\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-30 10:19:35\";s:6:\"status\";s:1:\"1\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:14:\"Administration\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-10-16 13:58:35\";s:6:\"status\";s:1:\"1\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:8:\"Web Mail\";s:4:\"link\";s:37:\"https://www.onetecgroup.com/web-mail/\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"Marketing\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-headphones\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:11:\"Bulk E-mail\";s:4:\"link\";s:25:\"admin/dashboard/marketing\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:3:\"161\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"0\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:15:\"Social Platform\";s:4:\"link\";s:31:\"admin/dashboard/social_platform\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:3:\"161\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"0\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7kda513tc2kck9m773p9kf1bb0nnrror', '104.227.191.132', 1583837732, '__ci_last_regenerate|i:1583837731;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7p48f5c739nnqoc79lsiuvdb0vc1ip0u', '69.171.251.5', 1584245403, '__ci_last_regenerate|i:1584245403;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ugs48vign4lfq9osqjeirqtd4r8mip7', '156.213.171.121', 1583825615, '__ci_last_regenerate|i:1583825242;menu_active_id|a:2:{i:0;s:1:\"1\";i:1;s:1:\"0\";}url|s:15:\"admin/dashboard\";user_roll|a:142:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 04:09:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-14 14:09:50\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-03 12:05:36\";s:6:\"status\";s:1:\"0\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-10-27 16:09:11\";s:6:\"status\";s:1:\"0\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-27 16:09:08\";s:6:\"status\";s:1:\"0\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-27 16:09:06\";s:6:\"status\";s:1:\"0\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:8:\"Employee\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-16 13:56:10\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-19 14:54:41\";s:6:\"status\";s:1:\"0\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:7:\"Finance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-16 14:03:34\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-25 13:29:59\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-25 13:29:59\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-03 21:19:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-07 13:08:02\";s:6:\"status\";s:1:\"0\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-16 13:58:35\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-21 12:49:03\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-24 21:18:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-14 14:09:50\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-16 13:52:44\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 15:13:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-11-19 14:53:35\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"126\";s:5:\"label\";s:13:\"contract_type\";s:4:\"link\";s:28:\"admin/settings/contract_type\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-03 10:57:01\";s:6:\"status\";s:1:\"2\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-16 13:52:44\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-11-13 13:14:21\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-21 12:49:03\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-03 10:22:43\";s:6:\"status\";s:1:\"1\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-11-14 12:22:20\";s:6:\"status\";s:1:\"2\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:23:\"materials_and_suppliers\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-12-01 10:52:15\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-04-30 20:40:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-01 12:40:31\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-04 18:49:30\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-04 16:23:11\";s:6:\"status\";s:1:\"1\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-25 01:38:46\";s:6:\"status\";s:1:\"2\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:2:\"HR\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-12-01 10:52:15\";s:6:\"status\";s:1:\"1\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"Project_Management\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-30 10:19:35\";s:6:\"status\";s:1:\"1\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:14:\"Administration\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-10-16 13:58:35\";s:6:\"status\";s:1:\"1\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:8:\"Web Mail\";s:4:\"link\";s:37:\"https://www.onetecgroup.com/web-mail/\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"Marketing\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-headphones\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:11:\"Bulk E-mail\";s:4:\"link\";s:25:\"admin/dashboard/marketing\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:3:\"161\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"0\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:15:\"Social Platform\";s:4:\"link\";s:31:\"admin/dashboard/social_platform\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:3:\"161\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"0\";}}user_name|s:11:\"amrattaalla\";email|s:15:\"amr@ram-egy.com\";name|s:22:\"MR. Amr Attaalla (CEO)\";photo|s:48:\"uploads/1fc43868-996e-4825-8eec-a8097d6622c5.jpg\";designations_id|s:1:\"2\";user_id|s:1:\"7\";last_login|s:19:\"2020-03-04 14:44:47\";online_time|i:1583825266;loggedin|b:1;user_type|s:1:\"1\";user_flag|i:1;direction|s:3:\"ltr\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9b6s44tc62t3fbkk3ojqb8m87drvqiju', '123.27.95.40', 1584226224, '__ci_last_regenerate|i:1584226186;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9re1dpqrmobovb4uqtj46nn6eqept0qk', '157.55.39.75', 1583916665, '__ci_last_regenerate|i:1583916665;menu_active_id|a:2:{i:0;s:1:\"1\";i:1;s:1:\"0\";}url|s:15:\"admin/dashboard\";user_roll|a:142:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 04:09:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-14 14:09:50\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-03 12:05:36\";s:6:\"status\";s:1:\"0\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-10-27 16:09:11\";s:6:\"status\";s:1:\"0\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-27 16:09:08\";s:6:\"status\";s:1:\"0\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-27 16:09:06\";s:6:\"status\";s:1:\"0\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:8:\"Employee\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-16 13:56:10\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-19 14:54:41\";s:6:\"status\";s:1:\"0\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:7:\"Finance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-16 14:03:34\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-25 13:29:59\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-25 13:29:59\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-03 21:19:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-07 13:08:02\";s:6:\"status\";s:1:\"0\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-16 13:58:35\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-21 12:49:03\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-24 21:18:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-14 14:09:50\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-16 13:52:44\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 15:13:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-11-19 14:53:35\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"126\";s:5:\"label\";s:13:\"contract_type\";s:4:\"link\";s:28:\"admin/settings/contract_type\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-03 10:57:01\";s:6:\"status\";s:1:\"2\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-16 13:52:44\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-11-13 13:14:21\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-21 12:49:03\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-03 10:22:43\";s:6:\"status\";s:1:\"1\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-11-14 12:22:20\";s:6:\"status\";s:1:\"2\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:23:\"materials_and_suppliers\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-12-01 10:52:15\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-04-30 20:40:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-01 12:40:31\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-04 18:49:30\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-04 16:23:11\";s:6:\"status\";s:1:\"1\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-25 01:38:46\";s:6:\"status\";s:1:\"2\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:2:\"HR\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-12-01 10:52:15\";s:6:\"status\";s:1:\"1\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"Project_Management\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-30 10:19:35\";s:6:\"status\";s:1:\"1\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:14:\"Administration\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-10-16 13:58:35\";s:6:\"status\";s:1:\"1\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:8:\"Web Mail\";s:4:\"link\";s:37:\"https://www.onetecgroup.com/web-mail/\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"Marketing\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-headphones\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:11:\"Bulk E-mail\";s:4:\"link\";s:25:\"admin/dashboard/marketing\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:3:\"161\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"0\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:15:\"Social Platform\";s:4:\"link\";s:31:\"admin/dashboard/social_platform\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:3:\"161\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"0\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('as4inr5roq3np53ltelegl800q8qpqkh', '159.65.24.22', 1584008333, '__ci_last_regenerate|i:1584008333;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbpm5c1qj7f1b6u4471b4551e6hjrg85', '157.55.39.75', 1583916664, '__ci_last_regenerate|i:1583916664;lang|s:7:\"english\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bqhgpl96la23b08qlf9jk03gs7jgqajo', '198.50.243.189', 1584137779, '__ci_last_regenerate|i:1584137778;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bv6oe8dpbl414fl3rffc8dbl8h301qcq', '66.249.75.205', 1583901232, '__ci_last_regenerate|i:1583901231;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cdt49ltobkp5n0ivvgj4ksrmlfn1glqg', '173.252.87.27', 1583893377, '__ci_last_regenerate|i:1583893376;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d7teqcn8jvaqhv7c3hu0depv6rktnjdi', '138.229.96.58', 1584300595, '__ci_last_regenerate|i:1584300595;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dg0mc8asmi51p9bofu3o5r747hd8jpp8', '157.55.39.75', 1583880603, '__ci_last_regenerate|i:1583880602;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dnl4r4n9m30u80om1q18cpc7ijhliin4', '173.252.87.37', 1583893381, '__ci_last_regenerate|i:1583893381;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dnr036er6ulcbpc5f60nisa7jrd8sejf', '209.17.97.42', 1583822296, '__ci_last_regenerate|i:1583822295;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('du51thla33o95i2s0p0pl3n8so871s4n', '151.80.39.212', 1584296749, '__ci_last_regenerate|i:1584296748;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fvc7cr1crk75kkvhjmq79pdepd6ii1ir', '157.55.39.75', 1583921374, '__ci_last_regenerate|i:1583921374;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gb5ea3ncujkocskahgvv767u5vh4qemv', '156.213.179.190', 1583842944, '__ci_last_regenerate|i:1583842944;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gus00eoqi0adraj7ajmrju1e51ea57un', '159.65.24.22', 1584008331, '__ci_last_regenerate|i:1584008331;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h0glhq7jd2tedvt435oon8fgh5o19sdc', '69.171.251.34', 1584051750, '__ci_last_regenerate|i:1584051749;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h2i6961hhn42o5creelh5opv4m1t46bo', '157.55.39.75', 1583916666, '__ci_last_regenerate|i:1583916666;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hdikfg4nb3es5uu7hf1cndb1nqlu0m0k', '66.249.75.207', 1583858375, '__ci_last_regenerate|i:1583858373;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hf0mphkcd4dsqhuj01idcfku5jcug1d7', '138.229.96.58', 1584300598, '__ci_last_regenerate|i:1584300597;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hlrt4r9nqt2lpqj6f23spl86l306f0lp', '66.249.75.207', 1583863521, '__ci_last_regenerate|i:1583863521;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i08pc5p8i605m49q6ps7mfepf2qn4ouv', '5.196.87.143', 1584298964, '__ci_last_regenerate|i:1584298964;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i840gipjm4vu9rcminnnourn30tmimei', '159.65.24.22', 1584008327, '__ci_last_regenerate|i:1584008327;lang|s:7:\"english\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ipp6o12chm4lvi7jq567s1esbjl3f2f9', '40.76.79.103', 1584298760, '__ci_last_regenerate|i:1584298760;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j2kn4oafkkodjk336ddis5e41a7ojset', '138.229.96.58', 1584300599, '__ci_last_regenerate|i:1584300599;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j63hna3kupfgrv4mivllneppd3iimvts', '157.55.39.75', 1583916667, '__ci_last_regenerate|i:1583916667;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kmph8muv7oq05hbjdsopq2b2ircm62ac', '5.196.87.143', 1584301070, '__ci_last_regenerate|i:1584301070;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l0qlug63bva44lp8q9g8brge3ui0bg7e', '173.252.127.50', 1583997252, '__ci_last_regenerate|i:1583997251;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l5kidg21od3g04ohg3c2orbaff30b6vn', '156.213.179.190', 1583842944, '__ci_last_regenerate|i:1583842944;menu_active_id|a:3:{i:0;s:2:\"55\";i:1;s:2:\"12\";i:2;s:1:\"0\";}url|s:20:\"admin/leads/leadList\";user_roll|a:142:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 04:09:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-14 14:09:50\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-03 12:05:36\";s:6:\"status\";s:1:\"0\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-10-27 16:09:11\";s:6:\"status\";s:1:\"0\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-27 16:09:08\";s:6:\"status\";s:1:\"0\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-27 16:09:06\";s:6:\"status\";s:1:\"0\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:8:\"Employee\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-16 13:56:10\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-19 14:54:41\";s:6:\"status\";s:1:\"0\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:7:\"Finance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-16 14:03:34\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-25 13:29:59\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-25 13:29:59\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-03 21:19:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-07 13:08:02\";s:6:\"status\";s:1:\"0\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-16 13:58:35\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-21 12:49:03\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-24 21:18:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-14 14:09:50\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-16 13:52:44\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 15:13:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-11-19 14:53:35\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"126\";s:5:\"label\";s:13:\"contract_type\";s:4:\"link\";s:28:\"admin/settings/contract_type\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-03 10:57:01\";s:6:\"status\";s:1:\"2\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-16 13:52:44\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-11-13 13:14:21\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-21 12:49:03\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-03 10:22:43\";s:6:\"status\";s:1:\"1\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-11-14 12:22:20\";s:6:\"status\";s:1:\"2\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:23:\"materials_and_suppliers\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-12-01 10:52:15\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-04-30 20:40:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-01 12:40:31\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-04 18:49:30\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-04 16:23:11\";s:6:\"status\";s:1:\"1\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-25 01:38:46\";s:6:\"status\";s:1:\"2\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:2:\"HR\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-12-01 10:52:15\";s:6:\"status\";s:1:\"1\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"Project_Management\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-30 10:19:35\";s:6:\"status\";s:1:\"1\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:14:\"Administration\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-10-16 13:58:35\";s:6:\"status\";s:1:\"1\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:8:\"Web Mail\";s:4:\"link\";s:37:\"https://www.onetecgroup.com/web-mail/\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"Marketing\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-headphones\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:11:\"Bulk E-mail\";s:4:\"link\";s:25:\"admin/dashboard/marketing\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:3:\"161\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"0\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:15:\"Social Platform\";s:4:\"link\";s:31:\"admin/dashboard/social_platform\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:3:\"161\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"0\";}}user_name|s:11:\"amrattaalla\";email|s:15:\"amr@ram-egy.com\";name|s:22:\"MR. Amr Attaalla (CEO)\";photo|s:48:\"uploads/1fc43868-996e-4825-8eec-a8097d6622c5.jpg\";designations_id|s:1:\"2\";user_id|s:1:\"7\";last_login|s:19:\"2020-03-04 14:44:47\";online_time|i:1583842536;loggedin|b:1;user_type|s:1:\"1\";user_flag|i:1;direction|s:3:\"ltr\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l64sgngf60jn9bklqqm8qpg956j3o95e', '159.65.24.22', 1584008334, '__ci_last_regenerate|i:1584008334;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l9bt2aug85me7cusns75lu5ce9p3alb3', '69.171.251.38', 1583956835, '__ci_last_regenerate|i:1583956834;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lh2d0m1glom7f200kvbvr6qpf275lorj', '157.55.39.75', 1583880600, '__ci_last_regenerate|i:1583880599;lang|s:7:\"english\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lo8g7757jesni0c1pkia6oe1ag9iaf9c', '157.55.39.75', 1583867372, '__ci_last_regenerate|i:1583867372;menu_active_id|a:2:{i:0;s:1:\"1\";i:1;s:1:\"0\";}url|s:15:\"admin/dashboard\";user_roll|a:142:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 04:09:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-14 14:09:50\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-03 12:05:36\";s:6:\"status\";s:1:\"0\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-10-27 16:09:11\";s:6:\"status\";s:1:\"0\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-27 16:09:08\";s:6:\"status\";s:1:\"0\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-27 16:09:06\";s:6:\"status\";s:1:\"0\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:8:\"Employee\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-16 13:56:10\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-19 14:54:41\";s:6:\"status\";s:1:\"0\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:7:\"Finance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-16 14:03:34\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-25 13:29:59\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-25 13:29:59\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-03 21:19:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-07 13:08:02\";s:6:\"status\";s:1:\"0\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-06 09:35:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:3:\"158\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-16 13:58:35\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-21 12:49:03\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-24 21:18:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 18:41:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:25:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-14 14:09:50\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-22 10:36:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-09 16:34:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-16 13:52:44\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"156\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-10-16 13:56:00\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-29 11:20:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 15:13:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2019-12-01 10:51:41\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-11-19 14:53:35\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"126\";s:5:\"label\";s:13:\"contract_type\";s:4:\"link\";s:28:\"admin/settings/contract_type\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:43:41\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-24 19:46:20\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-03 10:57:01\";s:6:\"status\";s:1:\"2\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-10-16 13:52:44\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-11-13 13:14:21\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:3:\"159\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-21 12:49:03\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 09:35:17\";s:6:\"status\";s:1:\"1\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2017-04-24 19:38:46\";s:6:\"status\";s:1:\"2\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-10-14 13:50:41\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-11-05 10:09:49\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-10-03 10:22:43\";s:6:\"status\";s:1:\"1\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-11-14 12:22:20\";s:6:\"status\";s:1:\"2\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:23:\"materials_and_suppliers\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2019-12-01 10:52:15\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-04-30 20:40:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-10-01 12:40:31\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-04 18:49:30\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-04 16:23:11\";s:6:\"status\";s:1:\"1\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-25 01:38:46\";s:6:\"status\";s:1:\"2\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:2:\"HR\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-12-01 10:52:15\";s:6:\"status\";s:1:\"1\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"Project_Management\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2019-10-30 10:19:35\";s:6:\"status\";s:1:\"1\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:14:\"Administration\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2019-10-16 13:58:35\";s:6:\"status\";s:1:\"1\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:8:\"Web Mail\";s:4:\"link\";s:37:\"https://www.onetecgroup.com/web-mail/\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"Marketing\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-headphones\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2020-02-20 11:37:11\";s:6:\"status\";s:1:\"0\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:11:\"Bulk E-mail\";s:4:\"link\";s:25:\"admin/dashboard/marketing\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:3:\"161\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"0\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:15:\"Social Platform\";s:4:\"link\";s:31:\"admin/dashboard/social_platform\";s:4:\"icon\";s:9:\"fa fa-ban\";s:6:\"parent\";s:3:\"161\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2020-02-20 11:36:22\";s:6:\"status\";s:1:\"0\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lvrcefoaedh3umgcdoec23me8noh8n24', '138.229.96.58', 1584300598, '__ci_last_regenerate|i:1584300598;lang|s:7:\"english\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ma5uo8f934na18ph7i8sgdpdu1p1ltmm', '173.252.127.50', 1583997256, '__ci_last_regenerate|i:1583997256;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mcefoj6i4ph0d5mu5ahmp5jacr1pm6k9', '156.213.171.121', 1583825172, '');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mmfg3bv418qcuah0h6ndg2ovk3o81rop', '95.142.124.29', 1583987003, '__ci_last_regenerate|i:1583987001;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('naa4qfd58q90t9hbruh1eu6g2ssrhchc', '69.171.251.8', 1584051753, '__ci_last_regenerate|i:1584051753;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nhkjlt552fbr64u2mjdtoo3r98be5af1', '157.55.39.75', 1583880601, '__ci_last_regenerate|i:1583880601;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nspcrber343e2adke59s14njnm2dqpgh', '66.146.237.99', 1584300582, '__ci_last_regenerate|i:1584300582;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o3bpfpcrrjct2i164q18b5otdessknot', '156.213.171.121', 1583825172, '');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('og769ikjcu87mlv0enahql7l112eq104', '213.159.213.236', 1584146461, '__ci_last_regenerate|i:1584146460;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oj4stu9dr69to35u6bsr652pdb6faitb', '209.17.96.82', 1584216435, '__ci_last_regenerate|i:1584216434;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('okm05ni4i0vpk8f8aei264q0qmlsa8gn', '69.171.251.12', 1584010358, '__ci_last_regenerate|i:1584010358;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p9ig9dip4k6b9519980vb8l92vcqju5a', '159.65.24.22', 1584008330, '__ci_last_regenerate|i:1584008330;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pu386naab8t7tc2n6c95kj795q72peob', '159.65.24.22', 1584008328, '__ci_last_regenerate|i:1584008328;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q1mpttvj4ie4mebi2j1d1a7jjeblb1d7', '69.171.251.37', 1583987491, '__ci_last_regenerate|i:1583987491;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q7sl2qb5c3tr88vk74rebqr7ukm52823', '168.91.36.37', 1584181763, '__ci_last_regenerate|i:1584181743;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}lang|s:7:\"english\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qdqi7d2dhququp121cali6ddmq3mmgks', '138.229.96.58', 1584300585, '__ci_last_regenerate|i:1584300585;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r32h7nlok54km2hhie01fnh3at9g8snj', '113.172.228.209', 1583974722, '__ci_last_regenerate|i:1583974710;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rhe3ca28nnp2ggfaf27van00eetdukr3', '138.229.96.58', 1584300594, '__ci_last_regenerate|i:1584300593;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rpveu1klc4td84f4jjpu4scp0ithhd0t', '180.183.48.223', 1584261370, '__ci_last_regenerate|i:1584261357;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s3q5iiharlu1f0jmtivmuandb18hvp0g', '66.249.75.205', 1583891416, '__ci_last_regenerate|i:1583891415;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sg86sat78rmql6tf1ih305gh407p9bd2', '69.171.251.24', 1584245400, '__ci_last_regenerate|i:1584245398;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('un1enjn1o0dolu7ockritrg7if1cjdnc', '69.171.251.14', 1583987497, '__ci_last_regenerate|i:1583987497;menu_active_id|a:2:{i:0;s:3:\"109\";i:1;s:1:\"0\";}');


#
# TABLE STRUCTURE FOR: tbl_status
#

DROP TABLE IF EXISTS `tbl_status`;

CREATE TABLE `tbl_status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`status_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_status` (`status_id`, `status`) VALUES (1, 'answered');
INSERT INTO `tbl_status` (`status_id`, `status`) VALUES (2, 'closed');
INSERT INTO `tbl_status` (`status_id`, `status`) VALUES (3, 'open');
INSERT INTO `tbl_status` (`status_id`, `status`) VALUES (5, 'in_progress');


#
# TABLE STRUCTURE FOR: tbl_stock
#

DROP TABLE IF EXISTS `tbl_stock`;

CREATE TABLE `tbl_stock` (
  `stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_sub_category_id` int(11) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `total_stock` int(5) DEFAULT NULL,
  PRIMARY KEY (`stock_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_stock_category
#

DROP TABLE IF EXISTS `tbl_stock_category`;

CREATE TABLE `tbl_stock_category` (
  `stock_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_category` varchar(200) NOT NULL,
  PRIMARY KEY (`stock_category_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_stock_sub_category
#

DROP TABLE IF EXISTS `tbl_stock_sub_category`;

CREATE TABLE `tbl_stock_sub_category` (
  `stock_sub_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_category_id` int(11) NOT NULL,
  `stock_sub_category` varchar(200) NOT NULL,
  PRIMARY KEY (`stock_sub_category_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_suppliers
#

DROP TABLE IF EXISTS `tbl_suppliers`;

CREATE TABLE `tbl_suppliers` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` text,
  `permission` text,
  PRIMARY KEY (`supplier_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_task
#

DROP TABLE IF EXISTS `tbl_task`;

CREATE TABLE `tbl_task` (
  `task_id` int(5) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `milestones_id` int(11) DEFAULT NULL,
  `opportunities_id` int(11) DEFAULT NULL,
  `goal_tracking_id` int(11) DEFAULT NULL,
  `sub_task_id` int(11) DEFAULT NULL,
  `task_name` varchar(200) NOT NULL,
  `task_description` text NOT NULL,
  `task_start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `task_created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `task_status` varchar(30) DEFAULT NULL,
  `task_progress` int(2) NOT NULL,
  `calculate_progress` varchar(200) DEFAULT NULL,
  `task_hour` varchar(10) NOT NULL,
  `tasks_notes` text,
  `timer_status` enum('on','off') NOT NULL DEFAULT 'off',
  `timer_started_by` int(11) DEFAULT NULL,
  `start_time` int(11) DEFAULT NULL,
  `logged_time` int(11) NOT NULL DEFAULT '0',
  `leads_id` int(11) DEFAULT NULL,
  `bug_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `permission` text,
  `client_visible` varchar(5) DEFAULT NULL,
  `custom_date` text,
  `hourly_rate` decimal(18,2) DEFAULT '0.00',
  `billable` varchar(20) NOT NULL DEFAULT 'No',
  `index_no` int(10) NOT NULL,
  `milestones_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`task_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_task_attachment
#

DROP TABLE IF EXISTS `tbl_task_attachment`;

CREATE TABLE `tbl_task_attachment` (
  `task_attachment_id` int(5) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `upload_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `leads_id` int(11) DEFAULT NULL,
  `opportunities_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `bug_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`task_attachment_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_task_comment
#

DROP TABLE IF EXISTS `tbl_task_comment`;

CREATE TABLE `tbl_task_comment` (
  `task_comment_id` int(5) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text NOT NULL,
  `comments_attachment` text,
  `comment_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `leads_id` int(11) DEFAULT NULL,
  `opportunities_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `bug_id` int(11) DEFAULT NULL,
  `goal_tracking_id` int(11) DEFAULT NULL,
  `task_attachment_id` int(11) DEFAULT '0',
  `uploaded_files_id` int(11) DEFAULT '0',
  `comments_reply_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`task_comment_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_task_uploaded_files
#

DROP TABLE IF EXISTS `tbl_task_uploaded_files`;

CREATE TABLE `tbl_task_uploaded_files` (
  `uploaded_files_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_attachment_id` int(11) NOT NULL,
  `files` text NOT NULL,
  `uploaded_path` text NOT NULL,
  `file_name` text NOT NULL,
  `size` int(10) NOT NULL,
  `ext` varchar(100) NOT NULL,
  `is_image` int(2) NOT NULL,
  `image_width` int(5) NOT NULL,
  `image_height` int(5) NOT NULL,
  PRIMARY KEY (`uploaded_files_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_tasks_timer
#

DROP TABLE IF EXISTS `tbl_tasks_timer`;

CREATE TABLE `tbl_tasks_timer` (
  `tasks_timer_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `timer_status` enum('on','off') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'off',
  `start_time` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_time` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_timed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reason` text CHARACTER SET utf8,
  `edited_by` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tasks_timer_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_tasks_timer` (`tasks_timer_id`, `task_id`, `user_id`, `timer_status`, `start_time`, `end_time`, `date_timed`, `reason`, `edited_by`, `project_id`) VALUES (1, 0, 1, 'off', '1578823200', '1602478800', '2020-01-12 19:36:41', 'تمجميع جهاز المتوازي طلبية نادي البيطاش', 1, 1);


#
# TABLE STRUCTURE FOR: tbl_tax_rates
#

DROP TABLE IF EXISTS `tbl_tax_rates`;

CREATE TABLE `tbl_tax_rates` (
  `tax_rates_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_rate_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `tax_rate_percent` decimal(10,2) NOT NULL DEFAULT '0.00',
  `permission` text COLLATE utf8_unicode_ci,
  KEY `Index 1` (`tax_rates_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_tax_rates` (`tax_rates_id`, `tax_rate_name`, `tax_rate_percent`, `permission`) VALUES (1, 'without  VAT', '0.00', 'all');
INSERT INTO `tbl_tax_rates` (`tax_rates_id`, `tax_rate_name`, `tax_rate_percent`, `permission`) VALUES (2, 'Egyptian Tax Rate', '14.00', 'all');


#
# TABLE STRUCTURE FOR: tbl_tickets
#

DROP TABLE IF EXISTS `tbl_tickets`;

CREATE TABLE `tbl_tickets` (
  `tickets_id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `ticket_code` varchar(32) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `subject` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text,
  `status` varchar(200) DEFAULT NULL,
  `departments_id` int(11) DEFAULT NULL,
  `reporter` int(10) DEFAULT '0',
  `priority` varchar(50) DEFAULT NULL,
  `upload_file` text,
  `comment` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `permission` text,
  `last_reply` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`tickets_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_tickets_replies
#

DROP TABLE IF EXISTS `tbl_tickets_replies`;

CREATE TABLE `tbl_tickets_replies` (
  `tickets_replies_id` int(10) NOT NULL AUTO_INCREMENT,
  `tickets_id` bigint(10) DEFAULT NULL,
  `ticket_reply_id` int(11) DEFAULT '0',
  `body` text COLLATE utf8_unicode_ci,
  `replier` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `replierid` int(10) DEFAULT NULL,
  `attachment` text COLLATE utf8_unicode_ci,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tickets_replies_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_todo
#

DROP TABLE IF EXISTS `tbl_todo`;

CREATE TABLE `tbl_todo` (
  `todo_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext COLLATE utf8_unicode_ci NOT NULL,
  `user_id` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `due_date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '1= in_progress 2= on hold 3= done',
  `assigned` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL,
  PRIMARY KEY (`todo_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_training
#

DROP TABLE IF EXISTS `tbl_training`;

CREATE TABLE `tbl_training` (
  `training_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `assigned_by` int(11) NOT NULL,
  `training_name` varchar(100) NOT NULL,
  `vendor_name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `finish_date` date NOT NULL,
  `training_cost` varchar(300) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = pending, 1 = started, 2 = completed, 3 = terminated',
  `performance` tinyint(1) DEFAULT '0' COMMENT '0 = not concluded, 1 = satisfactory, 2 = average, 3 = poor, 4 = excellent',
  `remarks` text NOT NULL,
  `upload_file` text,
  `permission` text,
  PRIMARY KEY (`training_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_transactions
#

DROP TABLE IF EXISTS `tbl_transactions`;

CREATE TABLE `tbl_transactions` (
  `transactions_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `account_id` int(11) NOT NULL,
  `invoices_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(200) DEFAULT NULL,
  `type` enum('Income','Expense','Transfer') NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `paid_by` int(11) NOT NULL DEFAULT '0',
  `payment_methods_id` int(11) NOT NULL,
  `reference` varchar(200) NOT NULL,
  `status` enum('Cleared','Uncleared','Reconciled','Void','non_approved','paid') NOT NULL DEFAULT 'non_approved',
  `notes` text NOT NULL,
  `tags` text NOT NULL,
  `tax` decimal(18,2) NOT NULL DEFAULT '0.00',
  `date` date NOT NULL,
  `debit` decimal(18,2) NOT NULL DEFAULT '0.00',
  `credit` decimal(18,2) NOT NULL DEFAULT '0.00',
  `total_balance` decimal(18,2) NOT NULL DEFAULT '0.00',
  `transfer_id` int(11) NOT NULL DEFAULT '0',
  `permission` text,
  `attachement` text,
  `client_visible` enum('Yes','No') NOT NULL DEFAULT 'No',
  `added_by` int(11) NOT NULL DEFAULT '0',
  `paid` int(11) NOT NULL DEFAULT '0',
  `billable` enum('Yes','No') NOT NULL DEFAULT 'No',
  `deposit` text,
  `deposit_2` text,
  `under_55` text,
  PRIMARY KEY (`transactions_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_transfer
#

DROP TABLE IF EXISTS `tbl_transfer`;

CREATE TABLE `tbl_transfer` (
  `transfer_id` int(11) NOT NULL AUTO_INCREMENT,
  `to_account_id` int(11) NOT NULL,
  `from_account_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `payment_methods_id` int(11) NOT NULL,
  `reference` varchar(200) NOT NULL,
  `status` enum('Cleared','Uncleared','Reconciled','Void') NOT NULL DEFAULT 'Cleared',
  `notes` text NOT NULL,
  `date` date NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Transfer',
  `permission` mediumtext,
  `attachement` mediumtext,
  PRIMARY KEY (`transfer_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_uploaded_files
#

DROP TABLE IF EXISTS `tbl_uploaded_files`;

CREATE TABLE `tbl_uploaded_files` (
  `uploaded_files_id` int(11) NOT NULL,
  `files_id` int(11) NOT NULL,
  `files` text NOT NULL,
  `uploaded_path` text NOT NULL,
  `file_name` text NOT NULL,
  `size` int(10) NOT NULL,
  `ext` varchar(100) NOT NULL,
  `is_image` int(2) NOT NULL,
  `image_width` int(5) NOT NULL,
  `image_height` int(5) NOT NULL
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_user_role
#

DROP TABLE IF EXISTS `tbl_user_role`;

CREATE TABLE `tbl_user_role` (
  `user_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `designations_id` int(11) DEFAULT NULL,
  `menu_id` int(11) NOT NULL,
  `view` int(11) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  `edited` int(11) DEFAULT '0',
  `deleted` int(11) DEFAULT '0',
  PRIMARY KEY (`user_role_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=1710 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (403, 4, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (404, 4, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (405, 4, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (406, 4, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (407, 4, 57, 57, 57, 57, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (408, 4, 54, 54, 54, 54, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (409, 4, 58, 58, 58, 58, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (410, 4, 56, 56, 56, 56, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (411, 4, 55, 55, 55, 55, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (412, 4, 150, 150, 150, 150, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (413, 4, 39, 39, 39, 39, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (414, 4, 151, 151, 151, 151, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (415, 4, 152, 152, 152, 152, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (416, 4, 153, 153, 153, 153, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (417, 4, 154, 154, 154, 154, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (418, 4, 12, 12, 12, 12, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (419, 4, 13, 13, 13, 13, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (420, 4, 14, 14, 14, 14, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (421, 4, 51, 51, 51, 51, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (422, 4, 15, 15, 15, 15, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (423, 4, 140, 140, 140, 140, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (424, 4, 16, 16, 16, 16, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (425, 4, 21, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (426, 4, 22, 22, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (427, 4, 23, 23, 23, 23, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (428, 4, 6, 6, 6, 6, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (429, 4, 141, 141, 141, 141, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (430, 4, 144, 144, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (431, 4, 143, 143, 143, 143, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (432, 4, 142, 142, 142, 142, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (433, 4, 29, 29, 29, 29, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (434, 4, 31, 31, 31, 31, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (435, 4, 30, 30, 30, 30, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (436, 4, 32, 32, 32, 32, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (437, 4, 33, 33, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (438, 4, 52, 52, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (439, 4, 34, 34, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (440, 4, 36, 36, 36, 36, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (441, 4, 4, 4, 4, 4, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (442, 4, 70, 70, 70, 70, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (443, 4, 75, 75, 75, 75, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (444, 4, 76, 76, 76, 76, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (445, 4, 81, 81, 81, 81, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (446, 4, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (447, 4, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (448, 4, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (449, 4, 82, 82, 82, 82, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (450, 4, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (451, 4, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (452, 4, 105, 105, 105, 105, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (453, 4, 108, 108, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (454, 4, 106, 106, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (455, 4, 107, 107, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (456, 4, 148, 148, 148, 148, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (457, 4, 102, 102, 102, 102, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (458, 4, 103, 103, 103, 103, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (459, 4, 104, 104, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (460, 4, 89, 89, 89, 89, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (461, 4, 94, 94, 94, 94, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (462, 4, 95, 95, 95, 95, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (463, 4, 90, 90, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (464, 4, 91, 91, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (465, 4, 92, 92, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (466, 4, 93, 93, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (467, 4, 96, 96, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (468, 4, 98, 98, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (469, 4, 97, 97, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (470, 4, 74, 74, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (471, 4, 99, 99, 99, 99, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (472, 4, 85, 85, 85, 85, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (473, 4, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (474, 4, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (475, 4, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (476, 4, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (477, 4, 101, 101, 101, 101, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (478, 4, 100, 100, 100, 100, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (479, 4, 73, 73, 73, 73, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (480, 4, 71, 71, 71, 71, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (481, 4, 69, 69, 69, 69, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (482, 4, 42, 42, 42, 42, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (483, 4, 147, 147, 147, 147, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (484, 4, 146, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (485, 4, 43, 43, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (486, 4, 45, 45, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (487, 4, 44, 44, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (488, 4, 46, 46, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (489, 4, 47, 47, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (490, 4, 53, 53, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (491, 4, 48, 48, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (492, 4, 49, 49, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (493, 4, 50, 50, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (494, 4, 59, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (495, 4, 66, 66, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (496, 4, 67, 67, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (497, 4, 68, 68, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (498, 4, 60, 60, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (499, 4, 61, 61, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (500, 4, 62, 62, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (501, 4, 63, 63, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (502, 4, 24, 24, 24, 24, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (503, 4, 25, 25, 25, 25, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (504, 4, 117, 117, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (505, 4, 118, 118, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (506, 4, 119, 119, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (507, 4, 120, 120, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (508, 4, 121, 121, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (509, 4, 122, 122, 122, 122, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (510, 4, 123, 123, 123, 123, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (511, 4, 124, 124, 124, 124, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (512, 4, 125, 125, 125, 125, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (513, 4, 126, 126, 126, 126, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (514, 4, 127, 127, 127, 127, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (515, 4, 128, 128, 128, 128, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (516, 4, 129, 129, 129, 129, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (517, 4, 130, 130, 130, 130, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (518, 4, 131, 131, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (519, 4, 132, 132, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (520, 4, 133, 133, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (521, 4, 134, 134, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (522, 4, 135, 135, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (523, 4, 136, 136, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (524, 4, 137, 137, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (525, 4, 138, 138, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (526, 4, 155, 155, 155, 155, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (527, 4, 111, 111, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (528, 4, 149, 149, 149, 149, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (529, 4, 112, 112, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (530, 4, 113, 113, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (531, 4, 114, 114, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (532, 4, 115, 115, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (533, 4, 116, 116, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (534, 4, 145, 145, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (535, 4, 26, 26, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (536, 4, 139, 139, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (537, 5, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (538, 5, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (539, 5, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (540, 5, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (541, 5, 57, 57, 57, 57, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (542, 5, 54, 54, 54, 54, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (543, 5, 58, 58, 58, 58, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (544, 5, 56, 56, 56, 56, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (545, 5, 55, 55, 55, 55, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (546, 5, 150, 150, 150, 150, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (547, 5, 39, 39, 39, 39, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (548, 5, 151, 151, 151, 151, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (549, 5, 152, 152, 152, 152, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (550, 5, 153, 153, 153, 153, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (551, 5, 154, 154, 154, 154, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (552, 5, 12, 12, 12, 12, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (553, 5, 13, 13, 13, 13, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (554, 5, 14, 14, 14, 14, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (555, 5, 51, 51, 51, 51, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (556, 5, 15, 15, 15, 15, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (557, 5, 140, 140, 140, 140, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (558, 5, 16, 16, 16, 16, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (559, 5, 21, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (560, 5, 22, 22, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (561, 5, 23, 23, 23, 23, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (562, 5, 6, 6, 6, 6, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (563, 5, 141, 141, 141, 141, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (564, 5, 144, 144, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (565, 5, 143, 143, 143, 143, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (566, 5, 142, 142, 142, 142, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (567, 5, 29, 29, 29, 29, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (568, 5, 31, 31, 31, 31, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (569, 5, 30, 30, 30, 30, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (570, 5, 32, 32, 32, 32, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (571, 5, 33, 33, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (572, 5, 52, 52, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (573, 5, 34, 34, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (574, 5, 36, 36, 36, 36, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (575, 5, 4, 4, 4, 4, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (576, 5, 70, 70, 70, 70, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (577, 5, 75, 75, 75, 75, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (578, 5, 76, 76, 76, 76, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (579, 5, 81, 81, 81, 81, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (580, 5, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (581, 5, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (582, 5, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (583, 5, 82, 82, 82, 82, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (584, 5, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (585, 5, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (586, 5, 105, 105, 105, 105, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (587, 5, 108, 108, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (588, 5, 106, 106, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (589, 5, 107, 107, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (590, 5, 148, 148, 148, 148, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (591, 5, 102, 102, 102, 102, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (592, 5, 103, 103, 103, 103, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (593, 5, 104, 104, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (594, 5, 89, 89, 89, 89, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (595, 5, 94, 94, 94, 94, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (596, 5, 95, 95, 95, 95, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (597, 5, 90, 90, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (598, 5, 91, 91, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (599, 5, 92, 92, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (600, 5, 93, 93, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (601, 5, 96, 96, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (602, 5, 98, 98, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (603, 5, 97, 97, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (604, 5, 74, 74, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (605, 5, 99, 99, 99, 99, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (606, 5, 85, 85, 85, 85, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (607, 5, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (608, 5, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (609, 5, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (610, 5, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (611, 5, 101, 101, 101, 101, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (612, 5, 100, 100, 100, 100, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (613, 5, 73, 73, 73, 73, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (614, 5, 71, 71, 71, 71, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (615, 5, 69, 69, 69, 69, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (616, 5, 42, 42, 42, 42, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (617, 5, 147, 147, 147, 147, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (618, 5, 146, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (619, 5, 43, 43, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (620, 5, 45, 45, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (621, 5, 44, 44, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (622, 5, 46, 46, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (623, 5, 47, 47, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (624, 5, 53, 53, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (625, 5, 48, 48, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (626, 5, 49, 49, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (627, 5, 50, 50, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (628, 5, 59, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (629, 5, 66, 66, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (630, 5, 67, 67, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (631, 5, 68, 68, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (632, 5, 60, 60, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (633, 5, 61, 61, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (634, 5, 62, 62, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (635, 5, 63, 63, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (636, 5, 24, 24, 24, 24, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (637, 5, 25, 25, 25, 25, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (638, 5, 117, 117, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (639, 5, 118, 118, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (640, 5, 119, 119, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (641, 5, 120, 120, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (642, 5, 121, 121, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (643, 5, 122, 122, 122, 122, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (644, 5, 123, 123, 123, 123, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (645, 5, 124, 124, 124, 124, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (646, 5, 125, 125, 125, 125, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (647, 5, 126, 126, 126, 126, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (648, 5, 127, 127, 127, 127, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (649, 5, 128, 128, 128, 128, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (650, 5, 129, 129, 129, 129, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (651, 5, 130, 130, 130, 130, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (652, 5, 131, 131, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (653, 5, 132, 132, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (654, 5, 133, 133, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (655, 5, 134, 134, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (656, 5, 135, 135, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (657, 5, 136, 136, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (658, 5, 137, 137, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (659, 5, 138, 138, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (660, 5, 155, 155, 155, 155, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (661, 5, 111, 111, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (662, 5, 149, 149, 149, 149, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (663, 5, 112, 112, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (664, 5, 113, 113, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (665, 5, 114, 114, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (666, 5, 115, 115, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (667, 5, 116, 116, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (668, 5, 145, 145, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (669, 5, 26, 26, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (670, 5, 139, 139, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (671, 6, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (672, 6, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (673, 6, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (674, 6, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (675, 6, 57, 57, 57, 57, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (676, 6, 54, 54, 54, 54, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (677, 6, 58, 58, 58, 58, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (678, 6, 56, 56, 56, 56, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (679, 6, 55, 55, 55, 55, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (680, 6, 150, 150, 150, 150, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (681, 6, 39, 39, 39, 39, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (682, 6, 151, 151, 151, 151, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (683, 6, 152, 152, 152, 152, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (684, 6, 153, 153, 153, 153, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (685, 6, 154, 154, 154, 154, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (686, 6, 12, 12, 12, 12, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (687, 6, 13, 13, 13, 13, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (688, 6, 14, 14, 14, 14, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (689, 6, 51, 51, 51, 51, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (690, 6, 15, 15, 15, 15, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (691, 6, 140, 140, 140, 140, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (692, 6, 16, 16, 16, 16, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (693, 6, 21, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (694, 6, 22, 22, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (695, 6, 23, 23, 23, 23, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (696, 6, 6, 6, 6, 6, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (697, 6, 141, 141, 141, 141, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (698, 6, 144, 144, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (699, 6, 143, 143, 143, 143, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (700, 6, 142, 142, 142, 142, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (701, 6, 29, 29, 29, 29, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (702, 6, 31, 31, 31, 31, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (703, 6, 30, 30, 30, 30, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (704, 6, 32, 32, 32, 32, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (705, 6, 33, 33, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (706, 6, 52, 52, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (707, 6, 34, 34, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (708, 6, 36, 36, 36, 36, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (709, 6, 4, 4, 4, 4, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (710, 6, 70, 70, 70, 70, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (711, 6, 75, 75, 75, 75, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (712, 6, 76, 76, 76, 76, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (713, 6, 81, 81, 81, 81, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (714, 6, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (715, 6, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (716, 6, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (717, 6, 82, 82, 82, 82, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (718, 6, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (719, 6, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (720, 6, 105, 105, 105, 105, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (721, 6, 108, 108, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (722, 6, 106, 106, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (723, 6, 107, 107, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (724, 6, 148, 148, 148, 148, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (725, 6, 102, 102, 102, 102, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (726, 6, 103, 103, 103, 103, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (727, 6, 104, 104, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (728, 6, 89, 89, 89, 89, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (729, 6, 94, 94, 94, 94, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (730, 6, 95, 95, 95, 95, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (731, 6, 90, 90, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (732, 6, 91, 91, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (733, 6, 92, 92, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (734, 6, 93, 93, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (735, 6, 96, 96, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (736, 6, 98, 98, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (737, 6, 97, 97, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (738, 6, 74, 74, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (739, 6, 99, 99, 99, 99, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (740, 6, 85, 85, 85, 85, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (741, 6, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (742, 6, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (743, 6, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (744, 6, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (745, 6, 101, 101, 101, 101, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (746, 6, 100, 100, 100, 100, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (747, 6, 73, 73, 73, 73, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (748, 6, 71, 71, 71, 71, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (749, 6, 69, 69, 69, 69, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (750, 6, 42, 42, 42, 42, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (751, 6, 147, 147, 147, 147, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (752, 6, 146, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (753, 6, 43, 43, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (754, 6, 45, 45, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (755, 6, 44, 44, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (756, 6, 46, 46, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (757, 6, 47, 47, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (758, 6, 53, 53, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (759, 6, 48, 48, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (760, 6, 49, 49, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (761, 6, 50, 50, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (762, 6, 59, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (763, 6, 66, 66, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (764, 6, 67, 67, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (765, 6, 68, 68, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (766, 6, 60, 60, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (767, 6, 61, 61, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (768, 6, 62, 62, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (769, 6, 63, 63, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (770, 6, 24, 24, 24, 24, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (771, 6, 25, 25, 25, 25, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (772, 6, 117, 117, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (773, 6, 118, 118, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (774, 6, 119, 119, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (775, 6, 120, 120, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (776, 6, 121, 121, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (777, 6, 122, 122, 122, 122, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (778, 6, 123, 123, 123, 123, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (779, 6, 124, 124, 124, 124, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (780, 6, 125, 125, 125, 125, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (781, 6, 126, 126, 126, 126, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (782, 6, 127, 127, 127, 127, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (783, 6, 128, 128, 128, 128, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (784, 6, 129, 129, 129, 129, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (785, 6, 130, 130, 130, 130, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (786, 6, 131, 131, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (787, 6, 132, 132, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (788, 6, 133, 133, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (789, 6, 134, 134, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (790, 6, 135, 135, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (791, 6, 136, 136, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (792, 6, 137, 137, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (793, 6, 138, 138, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (794, 6, 155, 155, 155, 155, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (795, 6, 111, 111, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (796, 6, 149, 149, 149, 149, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (797, 6, 112, 112, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (798, 6, 113, 113, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (799, 6, 114, 114, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (800, 6, 115, 115, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (801, 6, 116, 116, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (802, 6, 145, 145, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (803, 6, 26, 26, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (804, 6, 139, 139, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1341, 3, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1342, 3, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1343, 3, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1344, 3, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1345, 3, 141, 141, 141, 141, 141);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1346, 3, 142, 142, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1347, 3, 144, 144, 144, 144, 144);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1348, 3, 143, 143, 143, 143, 143);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1349, 3, 75, 75, 75, 75, 75);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1350, 3, 76, 76, 76, 76, 76);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1351, 3, 81, 81, 81, 81, 81);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1352, 3, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1353, 3, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1354, 3, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1355, 3, 82, 82, 82, 82, 82);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1356, 3, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1357, 3, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1358, 3, 102, 102, 102, 102, 102);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1359, 3, 103, 103, 103, 103, 103);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1360, 3, 104, 104, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1361, 3, 85, 85, 85, 85, 85);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1362, 3, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1363, 3, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1364, 3, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1365, 3, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1366, 3, 101, 101, 101, 101, 101);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1367, 3, 139, 139, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1368, 4, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1369, 4, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1370, 4, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1371, 4, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1372, 4, 141, 141, 141, 141, 141);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1373, 4, 142, 142, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1374, 4, 144, 144, 144, 144, 144);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1375, 4, 143, 143, 143, 143, 143);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1376, 4, 75, 75, 75, 75, 75);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1377, 4, 76, 76, 76, 76, 76);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1378, 4, 81, 81, 81, 81, 81);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1379, 4, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1380, 4, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1381, 4, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1382, 4, 82, 82, 82, 82, 82);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1383, 4, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1384, 4, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1385, 4, 102, 102, 102, 102, 102);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1386, 4, 103, 103, 103, 103, 103);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1387, 4, 104, 104, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1388, 4, 85, 85, 85, 85, 85);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1389, 4, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1390, 4, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1391, 4, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1392, 4, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1393, 4, 101, 101, 101, 101, 101);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1394, 4, 139, 139, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1497, 2, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1498, 2, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1499, 2, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1500, 2, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1501, 2, 57, 57, 57, 57, 57);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1502, 2, 54, 54, 54, 54, 54);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1503, 2, 58, 58, 58, 58, 58);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1504, 2, 56, 56, 56, 56, 56);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1505, 2, 55, 55, 55, 55, 55);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1506, 2, 150, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1507, 2, 39, 39, 39, 39, 39);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1508, 2, 151, 151, 151, 151, 151);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1509, 2, 152, 152, 152, 152, 152);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1510, 2, 153, 153, 153, 153, 153);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1511, 2, 154, 154, 154, 154, 154);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1512, 2, 12, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1513, 2, 13, 13, 13, 13, 13);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1514, 2, 14, 14, 14, 14, 14);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1515, 2, 51, 51, 51, 51, 51);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1516, 2, 15, 15, 15, 15, 15);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1517, 2, 140, 140, 140, 140, 140);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1518, 2, 16, 16, 16, 16, 16);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1519, 2, 21, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1520, 2, 22, 22, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1521, 2, 23, 23, 23, 23, 23);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1522, 2, 6, 6, 6, 6, 6);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1523, 2, 141, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1524, 2, 142, 142, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1525, 2, 144, 144, 144, 144, 144);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1526, 2, 143, 143, 143, 143, 143);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1527, 2, 29, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1528, 2, 31, 31, 31, 31, 31);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1529, 2, 30, 30, 30, 30, 30);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1530, 2, 32, 32, 32, 32, 32);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1531, 2, 33, 33, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1532, 2, 52, 52, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1533, 2, 34, 34, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1534, 2, 36, 36, 36, 36, 36);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1535, 2, 4, 4, 4, 4, 4);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1536, 2, 70, 70, 70, 70, 70);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1537, 2, 75, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1538, 2, 76, 76, 76, 76, 76);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1539, 2, 81, 81, 81, 81, 81);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1540, 2, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1541, 2, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1542, 2, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1543, 2, 82, 82, 82, 82, 82);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1544, 2, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1545, 2, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1546, 2, 105, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1547, 2, 108, 108, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1548, 2, 106, 106, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1549, 2, 107, 107, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1550, 2, 148, 148, 148, 148, 148);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1551, 2, 102, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1552, 2, 103, 103, 103, 103, 103);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1553, 2, 104, 104, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1554, 2, 89, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1555, 2, 94, 94, 94, 94, 94);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1556, 2, 95, 95, 95, 95, 95);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1557, 2, 90, 90, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1558, 2, 91, 91, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1559, 2, 92, 92, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1560, 2, 93, 93, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1561, 2, 96, 96, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1562, 2, 98, 98, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1563, 2, 97, 97, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1564, 2, 74, 74, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1565, 2, 99, 99, 99, 99, 99);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1566, 2, 85, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1567, 2, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1568, 2, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1569, 2, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1570, 2, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1571, 2, 101, 101, 101, 101, 101);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1572, 2, 100, 100, 100, 100, 100);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1573, 2, 73, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1574, 2, 71, 71, 71, 71, 71);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1575, 2, 69, 69, 69, 69, 69);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1576, 2, 42, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1577, 2, 59, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1578, 2, 66, 66, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1579, 2, 67, 67, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1580, 2, 68, 68, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1581, 2, 146, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1582, 2, 43, 43, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1583, 2, 44, 44, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1584, 2, 45, 45, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1585, 2, 46, 46, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1586, 2, 47, 47, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1587, 2, 48, 48, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1588, 2, 49, 49, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1589, 2, 50, 50, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1590, 2, 53, 53, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1591, 2, 147, 147, 147, 147, 147);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1592, 2, 60, 60, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1593, 2, 61, 61, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1594, 2, 62, 62, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1595, 2, 63, 63, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1596, 2, 24, 24, 24, 24, 24);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1597, 2, 26, 26, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1598, 2, 139, 139, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1599, 5, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1600, 5, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1601, 5, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1602, 5, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1603, 5, 56, 56, 56, 56, 56);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1604, 5, 12, 12, 12, 12, 12);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1605, 5, 13, 13, 13, 13, 13);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1606, 5, 14, 14, 14, 14, 14);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1607, 5, 51, 51, 51, 51, 51);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1608, 5, 15, 15, 15, 15, 15);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1609, 5, 140, 140, 140, 140, 140);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1610, 5, 16, 16, 16, 16, 16);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1611, 5, 21, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1612, 5, 22, 22, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1613, 5, 23, 23, 23, 23, 23);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1614, 5, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1615, 5, 101, 101, 101, 101, 101);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1616, 5, 73, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1617, 5, 71, 71, 71, 71, 71);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1618, 5, 139, 139, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1619, 6, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1620, 6, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1621, 6, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1622, 6, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1623, 6, 12, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1624, 6, 13, 13, 13, 13, 13);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1625, 6, 14, 14, 14, 14, 14);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1626, 6, 51, 51, 51, 51, 51);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1627, 6, 15, 15, 15, 15, 15);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1628, 6, 140, 140, 140, 140, 140);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1629, 6, 16, 16, 16, 16, 16);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1630, 6, 21, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1631, 6, 22, 22, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1632, 6, 23, 23, 23, 23, 23);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1633, 6, 29, 29, 29, 29, 29);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1634, 6, 31, 31, 31, 31, 31);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1635, 6, 30, 30, 30, 30, 30);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1636, 6, 32, 32, 32, 32, 32);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1637, 6, 33, 33, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1638, 6, 52, 52, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1639, 6, 34, 34, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1640, 6, 36, 36, 36, 36, 36);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1641, 6, 89, 89, 89, 89, 89);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1642, 6, 94, 94, 94, 94, 94);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1643, 6, 95, 95, 95, 95, 95);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1644, 6, 90, 90, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1645, 6, 91, 91, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1646, 6, 92, 92, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1647, 6, 93, 93, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1648, 6, 96, 96, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1649, 6, 98, 98, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1650, 6, 97, 97, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1651, 6, 74, 74, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1652, 6, 99, 99, 99, 99, 99);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1661, 7, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1662, 7, 12, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1663, 7, 140, 140, 140, 140, 140);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1664, 7, 29, 29, 29, 29, 29);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1665, 7, 75, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1666, 7, 76, 76, 76, 76, 76);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1667, 7, 81, 81, 81, 81, 81);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1668, 7, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1669, 7, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1670, 7, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1671, 7, 82, 82, 82, 82, 82);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1672, 7, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1673, 7, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1674, 7, 13, 13, 13, 13, 13);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1675, 7, 31, 31, 31, 31, 31);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1676, 7, 30, 30, 30, 30, 30);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1677, 7, 32, 32, 32, 32, 32);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1678, 7, 33, 33, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1679, 7, 52, 52, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1680, 7, 34, 34, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1681, 7, 36, 36, 36, 36, 36);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1682, 7, 15, 15, 15, 15, 15);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1683, 7, 16, 16, 16, 16, 16);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1684, 7, 156, 156, 156, 156, 156);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1685, 7, 24, 24, 24, 24, 24);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1686, 7, 70, 70, 70, 70, 70);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1687, 7, 71, 71, 71, 71, 71);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1688, 7, 101, 101, 101, 101, 101);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1689, 7, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1690, 7, 99, 99, 99, 99, 99);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1691, 7, 105, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1692, 7, 108, 108, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1693, 7, 106, 106, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1694, 7, 107, 107, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1695, 7, 148, 148, 148, 148, 148);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1696, 7, 85, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1697, 7, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1698, 7, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1699, 7, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1700, 7, 102, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1701, 7, 103, 103, 103, 103, 103);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1702, 7, 104, 104, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1703, 7, 158, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1704, 7, 6, 6, 6, 6, 6);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1705, 7, 57, 57, 57, 57, 57);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1706, 7, 54, 54, 54, 54, 54);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1707, 7, 58, 58, 58, 58, 58);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1708, 7, 69, 69, 69, 69, 69);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (1709, 7, 2, 2, 0, 0, 0);


#
# TABLE STRUCTURE FOR: tbl_users
#

DROP TABLE IF EXISTS `tbl_users`;

CREATE TABLE `tbl_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '2',
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(4) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_password_key` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_email_key` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `online_time` int(32) NOT NULL DEFAULT '0' COMMENT '1 = online 0 = offline ',
  `permission` text COLLATE utf8_unicode_ci,
  `active_email` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_email_type` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_encription` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_action` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_host_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_username` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_port` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_additional_flag` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_postmaster_run` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `media_path_slug` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (7, 'amrattaalla', '1f22e22839eb6c7a71446e73c0d5bf259b6288bd6b05597089fbf3f8bd98624fa744343b9d6d25f768efea89c73d3307934b8c6ad56b97eff99ad23732f4948d', 'amr@ram-egy.com', 1, 1, 0, NULL, NULL, NULL, NULL, NULL, '196.158.129.120', '2020-03-10 14:22:24', NULL, '2020-03-10 14:22:24', 1583842545, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (10, 'mta', '2a07105e9843895fe1a77634f424c6f5f0b0c604eb4a372c0be7bbec33b81db52bf82f3f1946a924bb74f438ce0d3dafbbd5e372b8e04ab528047f56c801873d', 'eng.mohamedtharwat06@gmail.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '156.213.109.122', '2020-01-16 14:12:49', NULL, '2020-01-16 14:12:49', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (11, 'ahmed-almaz', '1680a43251ccf939b250af1901aeefbabfa10fd7ee0494b44aabb2a1ae7f76bab6234a7683ac49525a601ca8ab1c74e7a6153514f0763498f9d2afd6d0b2b608', 'info@ram-egy.com', 1, 1, 0, NULL, NULL, NULL, NULL, NULL, '156.213.109.122', NULL, NULL, '2020-02-14 16:18:47', 1581689927, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (74, 'SNVTosRkDcF', '168c398344922de4ea9b0819727b5e30f5a06dd16884ecff9b29d46865aec8bceb3fe147de1b88521485ee7844f595587f4db335aef9056bafbb64d5223ef3b9', 'jemmerson21@yahoo.com', 2, 0, 0, NULL, NULL, NULL, NULL, '1f567a06db444d19b793d0d8d5f2cb16', '0', NULL, '2020-02-29 21:28:58', '2020-02-29 21:28:58', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (75, 'QiLPkZSwAUHq', 'f2ace7889e84f5e1bbfc1f64bcbd7aacffa562b81d7c6156b0e043b9544a2ee528dd017797e2b4f38798b6bb537b93626170e25a2fe9a88b887384233beb6f6d', 'emlen_joy@yahoo.com', 2, 0, 0, NULL, NULL, NULL, NULL, '7f46b5ac7193452e364b70c0553bc7a9', '0', NULL, '2020-03-03 05:42:33', '2020-03-03 05:42:33', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (76, 'dEqniVhQy', '902e7c2c6294a518e2704cb1d4bc3173078290f461c25297ead14334782b2805f34149e984a1404904c0d0c5d08f63776fa5f6fb087172db0d375efc3bc1f7ed', 'peteranthony2847@gmail.com', 2, 0, 0, NULL, NULL, NULL, NULL, '5cbdddb476b191820fdd47d50298de34', '0', NULL, '2020-03-07 08:56:08', '2020-03-07 08:56:08', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (77, 'PDBboRFHn', '9ea3ff1ebfc479e25b29197691692ba9b5f70954260f687a40b173a968800e29e123eab9798088ff8d8449ea3969c530382422c4964d221ab01e1883f9ab403b', 'tonnie.dick@yahoo.com', 2, 0, 0, NULL, NULL, NULL, NULL, 'fd11426b5f61dd9d8fc74a509cc86f27', '0', NULL, '2020-03-09 17:17:23', '2020-03-09 17:17:23', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (78, 'IUaKVQyDW', 'e70acd0022f23a3b177ae17a9c3dcc9921e81f6adde8f1f3b6d581f22277f403daf602bae044241f5e9210d86e4acc31f79b749373d3b61eb21954d751e727f4', 'johnbryan5576@gmail.com', 2, 0, 0, NULL, NULL, NULL, NULL, '8f390a2a2452bad37f900e6dfa2938d7', '0', NULL, '2020-03-12 02:58:37', '2020-03-12 02:58:37', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (79, 'cBLuHGSDy', '67ac53caa5066fe7daaea2e4e2cab4dcf89db80f42c5fca2e039c214e9ae3bb08f8f228b01841f415b6a0c5e4315eaa71cad3bfd4878668d861ff83509934982', 'gardy_g@yahoo.com', 2, 0, 0, NULL, NULL, NULL, NULL, 'fd7c00d9ab41517cf4ab3752fe34ce99', '0', NULL, '2020-03-12 13:19:45', '2020-03-12 13:19:45', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (80, 'MBjQVfDhPsIEaGr', 'c3858b2d0fc32d4c527662c35fcede69422724764f7e80d82ccd74a9f362d7ce04f13facc1ef4b0db0c99f69f0d3c49067bb6990b622d9c473e85651419b2780', 'llloyd57@yahoo.com', 2, 0, 0, NULL, NULL, NULL, NULL, 'de5dc0a18723f59831f2ca3e3aa8bcc0', '0', NULL, '2020-03-15 00:49:51', '2020-03-15 00:49:51', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (81, 'nqQigkhx', 'fa05707c7a273e4d8aab372363ae2f8c6c0f0d7aaad316bd0c89561309fbbd707a85867cbce3aaa8f4ff4b51098d676457c667cb232536330dc9e449634d733d', 'eugenio.mcvae@yahoo.com', 2, 0, 0, NULL, NULL, NULL, NULL, '19bd23e0377dd0c5fd6730490d2072ab', '0', NULL, '2020-03-15 10:36:05', '2020-03-15 10:36:05', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tbl_working_days
#

DROP TABLE IF EXISTS `tbl_working_days`;

CREATE TABLE `tbl_working_days` (
  `working_days_id` int(11) NOT NULL AUTO_INCREMENT,
  `day_id` int(5) NOT NULL,
  `start_hours` varchar(20) NOT NULL,
  `end_hours` varchar(20) NOT NULL,
  `flag` tinyint(1) NOT NULL,
  PRIMARY KEY (`working_days_id`)
) /*!50100 TABLESPACE `pcasa_newpms` */ ENGINE=InnoDB DEFAULT CHARSET=utf8;

